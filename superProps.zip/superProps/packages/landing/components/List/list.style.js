import styled from 'styled-components';

const ListWrapper = styled.div``;

export { ListWrapper };
