module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../node_modules/rc-drawer/assets/index.css":
/*!************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/rc-drawer/assets/index.css ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "../../node_modules/rc-tabs/assets/index.css":
/*!**********************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/rc-tabs/assets/index.css ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "../../node_modules/react-image-gallery/styles/css/image-gallery.css":
/*!**********************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/react-image-gallery/styles/css/image-gallery.css ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Box/index.js":
/*!*********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Box/index.js ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Box\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var BoxWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('div')(_base__WEBPACK_IMPORTED_MODULE_4__["base"], Object(_base__WEBPACK_IMPORTED_MODULE_4__["themed"])('Box'), function (props) {
  return props.flexBox && Object(styled_components__WEBPACK_IMPORTED_MODULE_2__["css"])({
    display: 'flex'
  }, styled_system__WEBPACK_IMPORTED_MODULE_3__["flexWrap"], styled_system__WEBPACK_IMPORTED_MODULE_3__["flexDirection"], styled_system__WEBPACK_IMPORTED_MODULE_3__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_3__["justifyContent"], Object(_base__WEBPACK_IMPORTED_MODULE_4__["themed"])('FlexBox'));
});

var Box = function Box(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ["children"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(BoxWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }), children);
};

/* harmony default export */ __webpack_exports__["default"] = (Box);
Box.propTypes = {
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any.isRequired,

  /** Using this props we can convert our Box Component to a Flex Container or Component */
  flexBox: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  as: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['div', 'article', 'section', 'address', 'header', 'footer', 'nav', 'main']),
  width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontSize: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  color: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  flex: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  order: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  alignSelf: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  display: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  border: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderTop: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderRight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderBottom: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderLeft: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderColor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))])
};
Box.defaultProps = {
  as: 'div'
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Button/button.style.js":
/*!*******************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Button/button.style.js ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _theme_customVariant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../theme/customVariant */ "../../node_modules/reusecore/src/theme/customVariant.js");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  /* button default style */\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  color: ", ";\n  background-color: ", ";\n  min-height: ", "px;\n  min-width: ", "px;\n  border-radius: ", "px;\n  font-family: inherit;\n  font-size: ", "px;\n  font-weight: ", ";\n  text-decoration: none;\n  text-transform: capitalize;\n  padding-top: ", "px;\n  padding-bottom: ", "px;\n  padding-left: ", "px;\n  padding-right: ", "px;\n  border: 0;\n  transition: all 0.3s ease;\n  span.btn-text {\n    padding-left: ", "px;\n    padding-right: ", "px;\n  }\n  span.btn-icon {\n    display: flex;\n    > div {\n      display: flex !important;\n    }\n  }\n\n  &:focus {\n    outline: none;\n  }\n\n  /* Material style goes here */\n  &.is-material {\n    box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 3px 1px -2px rgba(0, 0, 0, 0.12);\n  }\n\n  /* When button on loading stage */\n  &.is-loading {\n    .btn-text {\n      padding-left: ", "px;\n      padding-right: ", "px;\n    }\n  }\n\n  /* Style system support */\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }





var ButtonStyle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button(_templateObject(), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#028489'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('heights.3', '48'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('widths.3', '48'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radius.0', '3'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.4', '16'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.4', '500'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.2', '8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.2', '8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.4', '15'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.4', '15'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.1', '4'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.1', '4'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.2', '8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.2', '8'), styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], _theme_customVariant__WEBPACK_IMPORTED_MODULE_2__["buttonStyle"], _theme_customVariant__WEBPACK_IMPORTED_MODULE_2__["colorStyle"], _theme_customVariant__WEBPACK_IMPORTED_MODULE_2__["sizeStyle"], _base__WEBPACK_IMPORTED_MODULE_3__["base"]); // prop types can also be added from the style functions

ButtonStyle.propTypes = _objectSpread({}, styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_1__["variant"].propTypes);
ButtonStyle.displayName = 'ButtonStyle';
/* harmony default export */ __webpack_exports__["default"] = (ButtonStyle);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Button/index.js":
/*!************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Button/index.js ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./button.style */ "../../node_modules/reusecore/src/elements/Button/button.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Button\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var Button = function Button(_ref) {
  var type = _ref.type,
      title = _ref.title,
      icon = _ref.icon,
      disabled = _ref.disabled,
      iconPosition = _ref.iconPosition,
      onClick = _ref.onClick,
      loader = _ref.loader,
      isMaterial = _ref.isMaterial,
      isLoading = _ref.isLoading,
      className = _ref.className,
      props = _objectWithoutProperties(_ref, ["type", "title", "icon", "disabled", "iconPosition", "onClick", "loader", "isMaterial", "isLoading", "className"]);

  // Add all classs to an array
  var addAllClasses = ['reusecore__button']; // isLoading prop checking

  if (isLoading) {
    addAllClasses.push('is-loading');
  } // isMaterial prop checking


  if (isMaterial) {
    addAllClasses.push('is-material');
  } // className prop checking


  if (className) {
    addAllClasses.push(className);
  } // Checking button loading state


  var buttonIcon = isLoading !== false ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  }, " ", loader) : icon && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "btn-icon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }, icon); // set icon position

  var position = iconPosition || 'right';
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_button_style__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    type: type,
    className: addAllClasses.join(' '),
    icon: icon,
    disabled: disabled,
    "icon-position": position,
    onClick: onClick
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }), position === 'left' && buttonIcon, title && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "btn-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }, title), position === 'right' && buttonIcon);
};

Button.propTypes = {
  /** ClassName of the button */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Add icon */
  type: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['button', 'submit', 'reset']),

  /** Add icon */
  icon: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Add loader */
  loader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Add Material effect */
  isMaterial: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Button Loading state */
  isLoading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Button Loading state */
  loaderColor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** If true button will be disabled */
  disabled: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Adjust your icon and loader position [if you use loader] */
  iconPosition: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['left', 'right']),

  /** Variant change button shape */
  variant: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['textButton', 'outlined', 'fab', 'extendedFab']),

  /** primary || secondary || warning || error  change text and border color.
   *  And primaryWithBg || secondaryWithBg || warningWithBg || errorWithBg change text, border and background color */
  colors: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['primary', 'secondary', 'warning', 'error', 'primaryWithBg', 'secondaryWithBg', 'warningWithBg', 'errorWithBg']),

  /**
   * Gets called when the user clicks on the button
   */
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};
Button.defaultProps = {
  disabled: false,
  isMaterial: false,
  isLoading: false,
  type: 'button'
};
/* harmony default export */ __webpack_exports__["default"] = (Button);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Card/index.js":
/*!**********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Card/index.js ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _theme_customVariant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../theme/customVariant */ "../../node_modules/reusecore/src/theme/customVariant.js");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Card\\index.js";

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var CardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('div')(_base__WEBPACK_IMPORTED_MODULE_5__["base"], styled_system__WEBPACK_IMPORTED_MODULE_3__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_3__["borderColor"], styled_system__WEBPACK_IMPORTED_MODULE_3__["borderRadius"], styled_system__WEBPACK_IMPORTED_MODULE_3__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundImage"], styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundSize"], styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundPosition"], styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundRepeat"], styled_system__WEBPACK_IMPORTED_MODULE_3__["opacity"], _theme_customVariant__WEBPACK_IMPORTED_MODULE_4__["cards"], Object(_base__WEBPACK_IMPORTED_MODULE_5__["themed"])('Card'));

var Card = function Card(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ["children"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(CardWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    },
    __self: this
  }), children);
};

Card.propTypes = _objectSpread({
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any
}, styled_system__WEBPACK_IMPORTED_MODULE_3__["borders"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["borderColor"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["borderRadius"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["boxShadow"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundImage"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundSize"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundPosition"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundRepeat"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["opacity"].propTypes, _theme_customVariant__WEBPACK_IMPORTED_MODULE_4__["cards"].propTypes);
Card.defaultProps = {
  boxShadow: '0px 20px 35px rgba(0, 0, 0, 0.05)'
};
/* harmony default export */ __webpack_exports__["default"] = (Card);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Checkbox/checkbox.style.js":
/*!***********************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Checkbox/checkbox.style.js ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  display: inline-flex;\n  /* Switch label default style */\n  .reusecore__field-label {\n    color: ", ";\n    font-size: ", "px;\n    font-weight: ", ";\n  }\n\n  /* Switch label style when labelPosition on left */\n  &.label_left {\n    label {\n      display: flex;\n      align-items: center;\n      .reusecore__field-label {\n        margin-right: ", "px;\n      }\n    }\n  }\n\n  /* Switch label style when labelPosition on right */\n  &.label_right {\n    label {\n      display: flex;\n      flex-direction: row-reverse;\n      align-items: center;\n\n      .reusecore__field-label {\n        margin-left: ", "px;\n      }\n    }\n  }\n\n  /* Checkbox default style */\n  input[type='checkbox'] {\n    &.checkbox {\n      opacity: 0;\n      position: absolute;\n      margin: 0;\n      z-index: -1;\n      width: 0;\n      height: 0;\n      overflow: hidden;\n      pointer-events: none;\n\n      &:checked + div {\n        border-color: ", ";\n        background-color: ", ";\n        &::after {\n          opacity: 1;\n          visibility: visible;\n          transform: rotate(45deg) scale(1);\n        }\n      }\n    }\n    + div {\n      display: inline-flex;\n      align-items: center;\n      justify-content: center;\n      width: 16px;\n      height: 16px;\n      border-radius: 3px;\n      border: 1px solid ", ";\n      position: relative;\n      transition: all 0.3s ease;\n      &::after {\n        content: '';\n        width: 4px;\n        height: 10px;\n        transform: rotate(45deg) scale(0.8);\n        border-bottom: 2px solid ", ";\n        border-right: 2px solid ", ";\n        position: absolute;\n        top: 0;\n        opacity: 0;\n        visibility: hidden;\n        transition-property: opacity, visibility;\n        transition-duration: 0.3s;\n      }\n    }\n  }\n\n  /* support base component props */\n  ", "\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var CheckBoxStyle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div(_templateObject(), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.textColor', '#484848'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.4', '16'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.4', '500'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.3', '10'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.3', '10'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#028489'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#028489'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.borderColor', '#dadada'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), _base__WEBPACK_IMPORTED_MODULE_2__["base"]); // prop types can also be added from the style functions

CheckBoxStyle.propTypes = {};
CheckBoxStyle.displayName = 'CheckBoxStyle';
/* harmony default export */ __webpack_exports__["default"] = (CheckBoxStyle);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Checkbox/index.js":
/*!**************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Checkbox/index.js ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../hooks */ "../../node_modules/reusecore/src/hooks/index.js");
/* harmony import */ var _checkbox_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./checkbox.style */ "../../node_modules/reusecore/src/elements/Checkbox/checkbox.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Checkbox\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var CheckBox = function CheckBox(_ref) {
  var className = _ref.className,
      isChecked = _ref.isChecked,
      labelText = _ref.labelText,
      value = _ref.value,
      id = _ref.id,
      htmlFor = _ref.htmlFor,
      labelPosition = _ref.labelPosition,
      isMaterial = _ref.isMaterial,
      disabled = _ref.disabled,
      props = _objectWithoutProperties(_ref, ["className", "isChecked", "labelText", "value", "id", "htmlFor", "labelPosition", "isMaterial", "disabled"]);

  // use toggle hooks
  var _useToggle = Object(_hooks__WEBPACK_IMPORTED_MODULE_2__["useToggle"])(isChecked),
      _useToggle2 = _slicedToArray(_useToggle, 2),
      toggleValue = _useToggle2[0],
      toggleHandler = _useToggle2[1]; // Add all classs to an array


  var addAllClasses = ['reusecore__checkbox']; // Add label position class

  if (labelPosition) {
    addAllClasses.push("label_".concat(labelPosition));
  } // isMaterial prop checking


  if (isMaterial) {
    addAllClasses.push('is-material');
  } // className prop checking


  if (className) {
    addAllClasses.push(className);
  } // label control


  var LabelField = labelText && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "reusecore__field-label",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }, labelText);
  var position = labelPosition || 'right';
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_checkbox_style__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    className: addAllClasses.join(' ')
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("label", {
    htmlFor: htmlFor,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }, position === 'left' || position === 'right' ? LabelField : '', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", _extends({
    type: "checkbox",
    className: "checkbox",
    id: id,
    value: value,
    checked: toggleValue,
    onChange: toggleHandler,
    disabled: disabled
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    },
    __self: this
  })));
};

CheckBox.propTypes = {
  /** ClassName of the Checkbox */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** labelText of the checkbox field */
  labelText: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /**
   * Note: id and htmlFor must be same.
   */
  htmlFor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]),

  /** Set checkbox id in number || string */
  id: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]),

  /** value of the checkbox field */
  value: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** labelText of the checkbox field */
  labelPosition: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['right', 'left']),

  /** Checkbox toggle state based on isChecked prop */
  isChecked: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** disabled of the checkbox field */
  disabled: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
};
/** Checkbox default proptype */

CheckBox.defaultProps = {
  isChecked: false,
  labelText: 'Checkbox label',
  labelPosition: 'right',
  disabled: false
};
/* harmony default export */ __webpack_exports__["default"] = (CheckBox);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Drawer/index.js":
/*!************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Drawer/index.js ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rc-drawer */ "rc-drawer");
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rc_drawer__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rc_drawer_assets_index_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rc-drawer/assets/index.css */ "../../node_modules/rc-drawer/assets/index.css");
/* harmony import */ var rc_drawer_assets_index_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rc_drawer_assets_index_css__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Drawer\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var Drawer = function Drawer(_ref) {
  var className = _ref.className,
      children = _ref.children,
      closeButton = _ref.closeButton,
      drawerHandler = _ref.drawerHandler,
      toggleHandler = _ref.toggleHandler,
      open = _ref.open,
      props = _objectWithoutProperties(_ref, ["className", "children", "closeButton", "drawerHandler", "toggleHandler", "open"]);

  // Add all classs to an array
  var addAllClasses = ['reusecore__drawer']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(rc_drawer__WEBPACK_IMPORTED_MODULE_2___default.a, _extends({
    open: open,
    onMaskClick: toggleHandler,
    className: addAllClasses.join(' ')
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "reusecore-drawer__close",
    onClick: toggleHandler,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    __self: this
  }, closeButton), children), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "reusecore-drawer__handler",
    style: {
      display: 'inline-block'
    },
    onClick: toggleHandler,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    },
    __self: this
  }, drawerHandler));
};

Drawer.propTypes = {
  /** ClassName of the Drawer */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Used to render icon, button, text or any elements inside the closeButton prop. */
  closeButton: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** Set drawer width. Default value is 300px. */
  width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Set drawer position left || right || top || bottom. */
  placement: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['left', 'right', 'top', 'bottom']),

  /** drawerHandler could be button, icon, string or any component */
  drawerHandler: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element.isRequired
};
Drawer.defaultProps = {
  width: '300px',
  handler: false,
  level: null
};
/* harmony default export */ __webpack_exports__["default"] = (Drawer);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Heading/index.js":
/*!*************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Heading/index.js ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Heading\\index.js";

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var HeadingWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('p')(_base__WEBPACK_IMPORTED_MODULE_4__["base"], styled_system__WEBPACK_IMPORTED_MODULE_3__["fontFamily"], styled_system__WEBPACK_IMPORTED_MODULE_3__["fontWeight"], styled_system__WEBPACK_IMPORTED_MODULE_3__["textAlign"], styled_system__WEBPACK_IMPORTED_MODULE_3__["lineHeight"], styled_system__WEBPACK_IMPORTED_MODULE_3__["letterSpacing"], Object(_base__WEBPACK_IMPORTED_MODULE_4__["themed"])('Heading'));

var Heading = function Heading(_ref) {
  var content = _ref.content,
      props = _objectWithoutProperties(_ref, ["content"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(HeadingWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }), content);
};

/* harmony default export */ __webpack_exports__["default"] = (Heading);
Heading.propTypes = _objectSpread({
  content: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  as: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']),
  mt: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  mb: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontFamily: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontWeight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  textAlign: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  lineHeight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  letterSpacing: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))])
}, _base__WEBPACK_IMPORTED_MODULE_4__["base"].propTypes);
Heading.defaultProps = {
  as: 'h2',
  mt: 0,
  mb: '1rem',
  fontWeight: 'bold'
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Image/index.js":
/*!***********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Image/index.js ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Image\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var ImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('img')({
  display: 'block',
  maxWidth: '100%',
  height: 'auto'
}, _base__WEBPACK_IMPORTED_MODULE_3__["base"], Object(_base__WEBPACK_IMPORTED_MODULE_3__["themed"])('Image'));

var Image = function Image(_ref) {
  var src = _ref.src,
      alt = _ref.alt,
      props = _objectWithoutProperties(_ref, ["src", "alt"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ImageWrapper, _extends({
    src: src,
    alt: alt
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    },
    __self: this
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (Image);
Image.propTypes = {
  src: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  alt: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired
};
Image.defaultProps = {
  m: 0
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Input/index.js":
/*!***********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Input/index.js ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _input_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./input.style */ "../../node_modules/reusecore/src/elements/Input/input.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Input\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var Input = function Input(_ref) {
  var label = _ref.label,
      value = _ref.value,
      onBlur = _ref.onBlur,
      onFocus = _ref.onFocus,
      onChange = _ref.onChange,
      inputType = _ref.inputType,
      isMaterial = _ref.isMaterial,
      icon = _ref.icon,
      iconPosition = _ref.iconPosition,
      passwordShowHide = _ref.passwordShowHide,
      className = _ref.className,
      props = _objectWithoutProperties(_ref, ["label", "value", "onBlur", "onFocus", "onChange", "inputType", "isMaterial", "icon", "iconPosition", "passwordShowHide", "className"]);

  // use toggle hooks
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    toggle: false,
    focus: false,
    value: ''
  }),
      _useState2 = _slicedToArray(_useState, 2),
      state = _useState2[0],
      setState = _useState2[1]; // toggle function


  var handleToggle = function handleToggle() {
    setState(_objectSpread({}, state, {
      toggle: !state.toggle
    }));
  }; // add focus class


  var handleOnFocus = function handleOnFocus(event) {
    setState(_objectSpread({}, state, {
      focus: true
    }));
    onFocus(event);
  }; // remove focus class


  var handleOnBlur = function handleOnBlur(event) {
    setState(_objectSpread({}, state, {
      focus: false
    }));
    onBlur(event);
  }; // handle input value


  var handleOnChange = function handleOnChange(event) {
    setState(_objectSpread({}, state, {
      value: event.target.value
    }));
    onChange(event.target.value);
  }; // get input focus class


  var getInputFocusClass = function getInputFocusClass() {
    if (state.focus === true || state.value !== '') {
      return 'is-focus';
    } else {
      return '';
    }
  }; // init variable


  var inputElement, htmlFor; // Add all classs to an array

  var addAllClasses = ['reusecore__input']; // Add is-material class

  if (isMaterial) {
    addAllClasses.push('is-material');
  } // Add icon position class if input element has icon


  if (icon && iconPosition) {
    addAllClasses.push("icon-".concat(iconPosition));
  } // Add new class


  if (className) {
    addAllClasses.push(className);
  } // if lable is not empty


  if (label) {
    htmlFor = label.replace(/\s+/g, '_').toLowerCase();
  } // Label position


  var LabelPosition = isMaterial === true ? 'bottom' : 'top'; // Label field

  var LabelField = label && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("label", {
    htmlFor: htmlFor,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 99
    },
    __self: this
  }, label); // Input type check

  switch (inputType) {
    case 'textarea':
      inputElement = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("textarea", _extends({}, props, {
        id: htmlFor,
        name: htmlFor,
        value: state.value,
        onChange: handleOnChange,
        onBlur: handleOnBlur,
        onFocus: handleOnFocus,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 105
        },
        __self: this
      }));
      break;

    case 'password':
      inputElement = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "field-wrapper",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 119
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", _extends({}, props, {
        id: htmlFor,
        name: htmlFor,
        type: state.toggle ? 'password' : 'text',
        value: state.value,
        onChange: handleOnChange,
        onBlur: handleOnBlur,
        onFocus: handleOnFocus,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 120
        },
        __self: this
      })), passwordShowHide && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_input_style__WEBPACK_IMPORTED_MODULE_2__["EyeButton"], {
        onClick: handleToggle,
        className: state.toggle ? 'eye' : 'eye-closed',
        __source: {
          fileName: _jsxFileName,
          lineNumber: 131
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 135
        },
        __self: this
      })));
      break;

    default:
      inputElement = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "field-wrapper",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 144
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", _extends({}, props, {
        id: htmlFor,
        name: htmlFor,
        type: inputType,
        value: state.value,
        onChange: handleOnChange,
        onBlur: handleOnBlur,
        onFocus: handleOnFocus,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 145
        },
        __self: this
      })), icon && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "input-icon",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 155
        },
        __self: this
      }, icon));
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_input_style__WEBPACK_IMPORTED_MODULE_2__["default"], {
    className: "".concat(addAllClasses.join(' '), " ").concat(getInputFocusClass()),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 161
    },
    __self: this
  }, LabelPosition === 'top' && LabelField, inputElement, isMaterial && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "highlight",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 166
    },
    __self: this
  }), LabelPosition === 'bottom' && LabelField);
};
/** Inout prop type checking. */


Input.propTypes = {
  /** className of the Input component. */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Set input label value. */
  label: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** The input value, required for a controlled component. */
  value: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['string', 'number']),

  /** Make default input into material style input. */
  isMaterial: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Password show hide icon button prop [*only for password field]. */
  passwordShowHide: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Set input type of the input element. Default type is text. */
  inputType: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['text', 'email', 'password', 'number', 'textarea']),

  /** Add icon in input field. This prop will not work with password
   * and textarea field.
   */
  icon: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Set input field icon position. Default position is 'left'. */
  iconPosition: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['left', 'right']),

  /**
   * @ignore
   */
  onBlur: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,

  /**
   * @ignore
   */
  onFocus: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,

  /**
   * Callback fired when the value is changed.
   *
   * @param {object} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value`.
   */
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};
/** Inout default type. */

Input.defaultProps = {
  inputType: 'text',
  isMaterial: false,
  iconPosition: 'left',
  onBlur: function onBlur() {},
  onFocus: function onFocus() {},
  onChange: function onChange() {}
};
/* harmony default export */ __webpack_exports__["default"] = (Input);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Input/input.style.js":
/*!*****************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Input/input.style.js ***!
  \*****************************************************************************************************************/
/*! exports provided: EyeButton, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EyeButton", function() { return EyeButton; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
function _templateObject2() {
  var data = _taggedTemplateLiteral(["\n  width: 43px;\n  height: 40px;\n  border: 0;\n  padding: 0;\n  margin: 0;\n  top: 0;\n  right: 0;\n  position: absolute;\n  outline: none;\n  cursor: pointer;\n  box-shadow: none;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background-color: transparent;\n\n  > span {\n    width: 12px;\n    height: 12px;\n    display: block;\n    border: solid 1px ", ";\n    border-radius: 75% 15%;\n    transform: rotate(45deg);\n    position: relative;\n\n    &:before {\n      content: '';\n      display: block;\n      width: 4px;\n      height: 4px;\n      border-radius: 50%;\n      left: 3px;\n      top: 3px;\n      position: absolute;\n      border: solid 1px ", ";\n    }\n  }\n\n  &.eye-closed {\n    > span {\n      &:after {\n        content: '';\n        display: block;\n        width: 1px;\n        height: 20px;\n        left: calc(50% - 1px / 2);\n        top: -4px;\n        position: absolute;\n        background-color: ", ";\n        transform: rotate(-12deg);\n      }\n    }\n  }\n"]);

  _templateObject2 = function _templateObject2() {
    return data;
  };

  return data;
}

function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  position: relative;\n\n  /* Input field wrapper */\n  .field-wrapper {\n    position: relative;\n  }\n\n  /* If input has icon then these styel */\n  &.icon-left,\n  &.icon-right {\n    .field-wrapper {\n      display: flex;\n      align-items: center;\n      > .input-icon {\n        position: absolute;\n        top: 0;\n        bottom: auto;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        width: 34px;\n        height: 40px;\n      }\n    }\n  }\n\n  /* When icon position in left */\n  &.icon-left {\n    .field-wrapper {\n      > .input-icon {\n        left: 0;\n        right: auto;\n      }\n      > input {\n        padding-left: 34px;\n      }\n    }\n  }\n\n  /* When icon position in right */\n  &.icon-right {\n    .field-wrapper {\n      > .input-icon {\n        left: auto;\n        right: 0;\n      }\n      > input {\n        padding-right: 34px;\n      }\n    }\n  }\n\n  /* Label default style */\n  label {\n    display: block;\n    color: ", ";\n    font-size: ", "px;\n    font-weight: ", ";\n    margin-bottom: ", "px;\n    transition: 0.2s ease all;\n  }\n\n  /* Input and textarea default style */\n  textarea,\n  input {\n    font-size: 16px;\n    padding: 11px;\n    display: block;\n    width: 100%;\n    color: ", ";\n    box-shadow: none;\n    border-radius: 4px;\n    box-sizing: border-box;\n    border: 1px solid ", ";\n    transition: border-color 0.2s ease;\n    &:focus {\n      outline: none;\n      border-color: ", ";\n    }\n  }\n\n  textarea {\n    min-height: 150px;\n  }\n\n  /* Input material style */\n  &.is-material {\n    label {\n      position: absolute;\n      left: 0;\n      top: 10px;\n    }\n\n    input,\n    textarea {\n      border-radius: 0;\n      border-top: 0;\n      border-left: 0;\n      border-right: 0;\n      padding-left: 0;\n      padding-right: 0;\n    }\n\n    textarea {\n      min-height: 40px;\n      padding-bottom: 0;\n    }\n\n    .highlight {\n      position: absolute;\n      height: 1px;\n      top: auto;\n      left: 50%;\n      bottom: 0;\n      width: 0;\n      pointer-events: none;\n      transition: all 0.2s ease;\n    }\n\n    /* If input has icon then these styel */\n    &.icon-left,\n    &.icon-right {\n      .field-wrapper {\n        flex-direction: row-reverse;\n        > .input-icon {\n          width: auto;\n        }\n        > input {\n          flex: 1;\n        }\n      }\n    }\n\n    /* When icon position in left */\n    &.icon-left {\n      .field-wrapper {\n        > input {\n          padding-left: 20px;\n        }\n      }\n      label {\n        top: -15px;\n        font-size: 12px;\n      }\n    }\n\n    /* When icon position in right */\n    &.icon-right {\n      .field-wrapper {\n        > input {\n          padding-right: 20px;\n        }\n      }\n    }\n\n    /* Material input focus style */\n    &.is-focus {\n      input {\n        border-color: ", ";\n      }\n\n      label {\n        top: -16px;\n        font-size: 12px;\n        color: ", ";\n      }\n\n      .highlight {\n        width: 100%;\n        height: 2px;\n        background-color: ", ";\n        left: 0;\n      }\n    }\n  }\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }



var InputField = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div(_templateObject(), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.labelColor', '#767676'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.4', '16'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.4', '500'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.3', '10'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.textColor', '#484848'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.inactiveIcon', '#ebebeb'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#028489'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.inactiveIcon', '#ebebeb'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.textColor', '#484848'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#028489'));
var EyeButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button(_templateObject2(), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.textColor', '#484848'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.textColor', '#484848'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.textColor', '#484848'));

/* harmony default export */ __webpack_exports__["default"] = (InputField);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Link/index.js":
/*!**********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Link/index.js ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Link\\index.js";

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var LinkWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('a')({
  textDecoration: 'none'
}, _base__WEBPACK_IMPORTED_MODULE_3__["base"], Object(_base__WEBPACK_IMPORTED_MODULE_3__["themed"])('Link'));

var Link = function Link(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ["children"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(LinkWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    },
    __self: this
  }), children);
};

/* harmony default export */ __webpack_exports__["default"] = (Link);
Link.propTypes = _objectSpread({
  as: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object]),
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any.isRequired
}, _base__WEBPACK_IMPORTED_MODULE_3__["base"].propTypes);
Link.defaultProps = {
  as: 'a',
  m: 0,
  display: 'inline-block'
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Navbar/index.js":
/*!************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Navbar/index.js ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _navbar_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./navbar.style */ "../../node_modules/reusecore/src/elements/Navbar/navbar.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Navbar\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var Navbar = function Navbar(_ref) {
  var className = _ref.className,
      children = _ref.children,
      navbarStyle = _ref.navbarStyle,
      props = _objectWithoutProperties(_ref, ["className", "children", "navbarStyle"]);

  // Add all classs to an array
  var addAllClasses = ['reusecore__navbar']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_navbar_style__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: addAllClasses.join(' ')
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    },
    __self: this
  }), children);
};

Navbar.propTypes = {
  /** ClassName of the Navbar. Default class is reusecore__navbar*/
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Used to render menu, logo, button or any component that
   * you want to show in navbar. */
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,
  width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  space: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderRadius: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  boxShadow: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  color: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  display: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  alignItems: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  justifyContent: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  flexDirection: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  flexWrap: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
};
/** Navbar default proptype */

Navbar.defaultProps = {};
/* harmony default export */ __webpack_exports__["default"] = (Navbar);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Navbar/navbar.style.js":
/*!*******************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Navbar/navbar.style.js ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  /* Navbar default style goes here */\n  display: flex;\n  align-items: center;\n  min-height: 56px;\n  padding: 10px 16px;\n  \n  /* Style system supported prop */\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }



var NavbarStyle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.nav(_templateObject(), styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexDirection"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexWrap"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"]);
NavbarStyle.displayName = 'NavbarStyle';
/* harmony default export */ __webpack_exports__["default"] = (NavbarStyle);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Text/index.js":
/*!**********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Text/index.js ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Text\\index.js";

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var TextWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('p')(_base__WEBPACK_IMPORTED_MODULE_4__["base"], styled_system__WEBPACK_IMPORTED_MODULE_3__["fontFamily"], styled_system__WEBPACK_IMPORTED_MODULE_3__["fontWeight"], styled_system__WEBPACK_IMPORTED_MODULE_3__["textAlign"], styled_system__WEBPACK_IMPORTED_MODULE_3__["lineHeight"], styled_system__WEBPACK_IMPORTED_MODULE_3__["letterSpacing"], Object(_base__WEBPACK_IMPORTED_MODULE_4__["themed"])('Text'));

var Text = function Text(_ref) {
  var content = _ref.content,
      props = _objectWithoutProperties(_ref, ["content"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(TextWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }), content);
};

/* harmony default export */ __webpack_exports__["default"] = (Text);
Text.propTypes = _objectSpread({
  content: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  as: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  mt: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  mb: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontFamily: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontWeight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  textAlign: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  lineHeight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  letterSpacing: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))])
}, _base__WEBPACK_IMPORTED_MODULE_4__["base"].propTypes);
Text.defaultProps = {
  as: 'p',
  mt: 0,
  mb: '1rem'
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/UI/Logo/index.js":
/*!*************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/UI/Logo/index.js ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../Link */ "../../node_modules/reusecore/src/elements/Link/index.js");
/* harmony import */ var _Image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\UI\\Logo\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var Logo = function Logo(_ref) {
  var logoWrapperStyle = _ref.logoWrapperStyle,
      logoStyle = _ref.logoStyle,
      titleStyle = _ref.titleStyle,
      withAchor = _ref.withAchor,
      anchorProps = _ref.anchorProps,
      logoSrc = _ref.logoSrc,
      title = _ref.title,
      props = _objectWithoutProperties(_ref, ["logoWrapperStyle", "logoStyle", "titleStyle", "withAchor", "anchorProps", "logoSrc", "title"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Link__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, props, logoWrapperStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    },
    __self: this
  }), withAchor ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", _extends({}, anchorProps, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 19
    },
    __self: this
  }), logoSrc ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Image__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    src: logoSrc,
    alt: title
  }, logoStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21
    },
    __self: this
  })) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Text__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    content: title
  }, titleStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    },
    __self: this
  }))) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, logoSrc ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Image__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    src: logoSrc,
    alt: title
  }, logoStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  })) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Text__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    content: title
  }, titleStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    __self: this
  }))));
};

Logo.propTypes = {
  logoSrc: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  logoWrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  logoStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  titleStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  withAchor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  anchorProps: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
Logo.defaultProps = {
  logoWrapperStyle: {
    display: 'inline-block',
    mr: '1rem',
    'a:hover,a:focus': {
      textDecoration: 'none'
    }
  },
  titleStyle: {
    display: 'inline-block',
    fontSize: '2rem',
    lineHeight: 'inherit',
    whiteSpace: 'nowrap'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (Logo);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/base.js":
/*!****************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/base.js ***!
  \****************************************************************************************************/
/*! exports provided: themed, base */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "themed", function() { return themed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "base", function() { return base; });
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_0__);
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/** this is our Base Component every components must be Extend it */

var themed = function themed(key) {
  return function (props) {
    return props.theme[key];
  };
};
var base = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["compose"])(function () {
  return {
    boxSizing: 'border-box'
  };
}, styled_system__WEBPACK_IMPORTED_MODULE_0__["space"], styled_system__WEBPACK_IMPORTED_MODULE_0__["width"], styled_system__WEBPACK_IMPORTED_MODULE_0__["minWidth"], styled_system__WEBPACK_IMPORTED_MODULE_0__["maxWidth"], styled_system__WEBPACK_IMPORTED_MODULE_0__["height"], styled_system__WEBPACK_IMPORTED_MODULE_0__["minHeight"], styled_system__WEBPACK_IMPORTED_MODULE_0__["maxHeight"], styled_system__WEBPACK_IMPORTED_MODULE_0__["fontSize"], styled_system__WEBPACK_IMPORTED_MODULE_0__["color"], styled_system__WEBPACK_IMPORTED_MODULE_0__["flex"], styled_system__WEBPACK_IMPORTED_MODULE_0__["order"], styled_system__WEBPACK_IMPORTED_MODULE_0__["alignSelf"], styled_system__WEBPACK_IMPORTED_MODULE_0__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_0__["borderColor"], styled_system__WEBPACK_IMPORTED_MODULE_0__["display"]);
base.propTypes = _objectSpread({}, styled_system__WEBPACK_IMPORTED_MODULE_0__["display"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["space"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["borders"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["borderColor"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["width"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["height"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["fontSize"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["color"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["flex"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["order"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["alignSelf"].propTypes);

/***/ }),

/***/ "../../node_modules/reusecore/src/hooks/index.js":
/*!**************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/hooks/index.js ***!
  \**************************************************************************************************/
/*! exports provided: useToggle */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _toggle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./toggle */ "../../node_modules/reusecore/src/hooks/toggle/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useToggle", function() { return _toggle__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "../../node_modules/reusecore/src/hooks/toggle/index.js":
/*!*********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/hooks/toggle/index.js ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }


/* harmony default export */ __webpack_exports__["default"] = (function (initialValue) {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(initialValue),
      _useState2 = _slicedToArray(_useState, 2),
      value = _useState2[0],
      setValue = _useState2[1];

  var toggler = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(function () {
    return setValue(function (value) {
      return !value;
    });
  });
  return [value, toggler];
});

/***/ }),

/***/ "../../node_modules/reusecore/src/theme/customVariant.js":
/*!**********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/theme/customVariant.js ***!
  \**********************************************************************************************************/
/*! exports provided: cards, buttonStyle, colorStyle, sizeStyle */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cards", function() { return cards; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buttonStyle", function() { return buttonStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorStyle", function() { return colorStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sizeStyle", function() { return sizeStyle; });
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_0__);

var buttonStyle = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["variant"])({
  key: 'buttonStyles'
});
var colorStyle = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["variant"])({
  key: 'colorStyles',
  prop: 'colors'
});
var sizeStyle = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["variant"])({
  key: 'sizeStyles',
  prop: 'size'
});
var cards = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["variant"])({
  key: 'cards'
});


/***/ }),

/***/ "./assets/css/style.js":
/*!*****************************!*\
  !*** ./assets/css/style.js ***!
  \*****************************/
/*! exports provided: ResetCSS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetCSS", function() { return ResetCSS; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  ::selection {\n    background: #333333;\n    color: #ffffff;\n  }\n\n  html {\n    box-sizing: border-box;\n    -ms-overflow-style: scrollbar;\n  }\n\n  *,\n  *::before,\n  *::after {\n    box-sizing: inherit;\n  }\n\n  * {\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n  }\n\n  html,\n  html a,\n  h1,\n  h2,\n  h3,\n  h4,\n  h5,\n  h6,\n  a,\n  p,\n  li,\n  dl,\n  th,\n  dt,\n  input,\n  textarea,\n  span,\n  div {\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n    text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.004);\n  }\n\n  body {\n    margin: 0;\n    padding: 0;\n    overflow-x: hidden;\n    -webkit-tap-highlight-color: transparent;\n  }\n\n  ul {\n    margin: 0;\n    padding: 0;\n  }\n\n  li {\n    list-style-type: none;\n  }\n\n  a {\n    text-decoration: none;\n  }\n\n  a:hover {\n    text-decoration: none;\n  }\n\n  // modal default style\n  .reuseModalOverlay {\n    z-index: 99999;\n  }\n\n  .reuseModalHolder {\n    padding: 0;\n    &.demo_switcher_modal {\n      border: 0;\n      background-color: rgba(16, 30, 77, 0.9);\n      .innerRndComponent {\n        border-radius: 8px;\n      }\n    }\n  }\n\n  button.modalCloseBtn {\n    position: fixed;\n    z-index: 999991;\n    background-color: transparent;\n    top: 10px;\n    right: 10px;\n    min-width: 34px;\n    min-height: 34px;\n    padding: 0;\n    span.btn-icon {\n      font-size: 22px;\n      transform: rotate(45deg);\n    }\n\n    &.alt {\n      border-radius: 50%;\n      z-index: 999999;\n      padding: 0;\n      transition: all 0.3s ease;\n      top: 25px;\n      right: 30px;\n      min-width: 40px;\n      min-height: 40px;\n\n      span.btn-icon {\n        font-size: 20px;\n      }\n\n      &:hover {\n        opacity: 0.88;\n      }\n    }   \n  }\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }



var ResetCSS = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["createGlobalStyle"])(_templateObject());

/***/ }),

/***/ "./assets/image/agency/footer-bg.png":
/*!*******************************************!*\
  !*** ./assets/image/agency/footer-bg.png ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/footer-bg-61e61976e8a4ea1e4ff698142517ef3a.png";

/***/ }),

/***/ "./assets/image/agency/google-icon.jpg":
/*!*********************************************!*\
  !*** ./assets/image/agency/google-icon.jpg ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QBARXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAFaADAAQAAAABAAAAFgAAAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/8AAEQgAFgAVAwERAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/bAEMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/dAAQAA//aAAwDAQACEQMRAD8A/cT9tH9oT9rX9qv9qG7/AGM/2Zh4h8D+E9MkurTUNW0/Ubrwy/jS103ZH4j8aeI/F1gPtOn/AA20u4eXTLPT9LuJk1uQKt5batrGq6ToGn/ylmfiVi/FjPcXw54Z51hsdlGX5nmOS47G5Rjo8s8xyivLC5usxxmHlKphcNgq6dNYdf7zSnRrqGJjjMJCP+rXgD4W+CPgp4PUPHzxf/sziHO8XChiMLgcXhaWbLIKuMvPKcgynIsT+6xXFmNpxjjK+KxlKEsvi28PWwOAwWNzLEcLdf8ABGn9rj4Y/wBmeOfg9+0D4buviNFfWEl7/YuseL/AGp2ck91Elzfab4sjM02pJp5la9uRew6TcXNnDcfZoLq+a30+49CXgzxdlfssdk3EGGlmUalNz9hWxmXVYOUkpVKWMTk6ipuTnLnjRlKClyRlPkpy+io/T48D+L/rnDnHfhhm1HhSWHxMcN/aGByPifCYiNKjOVHDYvJJQpwwcsSoRw9F0KmOpUcRUpe2q0cNGpiqX9Gfww8P+MPCvw88HeHPiB4zk+InjXRtA0+w8T+NpNLs9FbxJrEMIF5qQ0uwRLW0SSTKRKoMskSJNcu9y8zv/R2V4fGYTLsHhswxrzHHUcPTp4rHOlCj9ZrRXv1fZU1GME3otOZpXnebk5f5T8YZnkWdcU59mvDGQR4W4fx+Z4rE5Pw9DGYjMI5TgKk70MJ9cxMpVq0ox96bb5Izk4UYwowhA//Q/qH/AGOviN8PfC37SPjD4P8AiXWdKg+Lmo+HNUtbCyuDGdSSTRtWhu9d0BroqfI1TUoYItdXRWlW7utO0KTU5IBbxWcsv+P37NTw9454F438X8bxrkuPyqlmaXDuCxuZznhp5pnnDme5hDPVhcFVca2Jpwq83NmMqSoyq0K9DDVq044qNL9/+kT40+Heb5pwj4YZNxdgsXxJKhPiXFcPYKtKtQwlCeXUHlcMdWpN4OjnE8Di8TicJlkpPMIZbOvi6tGjhq+Hnip/22/2Yf20Pil8Vp/iB8D/ANou3+Evwz07wRpdrqGk3nxj+J/gC0tNR0iTV7vWtbutO8KaJfaFBbtZzWzz6nNdLM0VqxuljigRm/6PfA3xS8E+FOE6fD3HXhtU4v4oxOe4qrh8ZR4L4W4hrVsNjI4OjgcDSxObY6hj6lRVoVVTwsKTgpVUqTlKpJH8D+JPBXiLnmeyzXhni6GQ5NRy2hCtQqcQ51lVOFbDyxFTE4mdHA4aphowdOUOatKpzNQvPlUUfh/8N/iF+3D8S7vxRa/Dz49fHXxVH4YubKDU73T/AIn/ABF1C0ZL6XU49OurY3mppcxW18NMvJbfz7a1nkiQedBG6FE/ufifh3wK4Yo5VV4j8P8AgLKpZpTr1MLQxHC3DmHrJ0IYWWJpVfY4R0pVaDxVGFT2dSrCM5PknKLUpfzXkua+JedVMdDKOKeJ8asFOlGvUpZ3m1Wm1VlXVGcPa14zUKqo1JQ5oQk4r3opq0f/0f6X/wBvz/gnAfiT4l1P9pX4HeLrH4cfErToo/EHi6yvZ9V0zStbvtDijlh8WaLrGgW15qnh7xdDBaxCcwWUtnrF1DbX7z6VqQv7/UPzfizgz67XnnWV4iODxsLVsRGTqU6dWdJXWIpVKUZVKOISjryrlqSSm5U5885/zB4xeB/9u4+vxzwnmVHJM9oqOMzKlVniKGHxVbCxUoZjhcThKdWvgsyhGnHn5KUqeJqRhWc8NXVatX/J7wr4p/bZ/at8RW37O+pftEanqVjd30ejXln4r8S61B4f1RYJEHl6/PpPh+71PxJZlkWVrfXbe/juJEV542dQ9fKZBnvHazrLp5PxTj8szXLMdQxWX5hh8dicJXwuMwtSNShiKeJw1NV3OnOKlFzlK7WqabP53y3MfFbxBx9LgyrxtiKsJ1oYecMfj8VDCVuSV7YueGwdTEY6ndKThi41ozkk5q6vL+j/APY2/ZF8H/sh/DSfwlo14viDxb4kvINY8e+MGtDZnW9Tt4pIbGx0+0ea6msvD+hwT3EGk2c91czebdahqE8v2nUZ0T+tePvFXjrxRnkOJ44zPDZhjciyijldKeAwcctwlataDx+aTwdOc6NPH5pWpwq42eHjQw79lRpYfC4bDUaFCH9z+HPAOC8P8j/s+lWWNzLFzhiM2zJUnRWLxEIuNOnRpOVSVLC4aMpxoU5TnLmnVrSanWlGP//Z"

/***/ }),

/***/ "./assets/image/agency/login-bg.jpg":
/*!******************************************!*\
  !*** ./assets/image/agency/login-bg.jpg ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/login-bg-e83ee3496f127d370a043d08d1bcc19c.jpg";

/***/ }),

/***/ "./assets/image/agency/logo.png":
/*!**************************************!*\
  !*** ./assets/image/agency/logo.png ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/logo-b73048211d7a9a05b4c449061f130c5f.png";

/***/ }),

/***/ "./assets/image/app/1.jpeg":
/*!*********************************!*\
  !*** ./assets/image/app/1.jpeg ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/1-be2ed1511f856f57648ebb4d1c0a1b96.jpeg";

/***/ }),

/***/ "./assets/image/app/1.svg":
/*!********************************!*\
  !*** ./assets/image/app/1.svg ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4OSA4OSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNmZmYyZjY7fS5jbHMtMntmaWxsOiNmZjU1ODk7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT4xPC90aXRsZT48Y2lyY2xlIGNsYXNzPSJjbHMtMSIgY3g9IjQ0LjUiIGN5PSI0NC41IiByPSI0NC41Ii8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNTkuNzIsNTguNDFsLTcuNTMtNy41M2ExMy4xLDEzLjEsMCwxLDAtMS4zLDEuMzFsNy41Myw3LjUzYS45MS45MSwwLDAsMCwuNjUuMjcuOTMuOTMsMCwwLDAsLjY1LTEuNThaTTMwLjg2LDQyLjIyQTExLjM2LDExLjM2LDAsMSwxLDQyLjIyLDUzLjU4LDExLjM3LDExLjM3LDAsMCwxLDMwLjg2LDQyLjIyWm0wLDAiLz48L3N2Zz4="

/***/ }),

/***/ "./assets/image/app/2.jpg":
/*!********************************!*\
  !*** ./assets/image/app/2.jpg ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/2-36da1d5d8a3ddcc2cd86faf1ff7fd9e5.jpg";

/***/ }),

/***/ "./assets/image/app/2.svg":
/*!********************************!*\
  !*** ./assets/image/app/2.svg ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4OSA4OSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNlZGY0ZmQ7fS5jbHMtMntmaWxsOiMxYTczZTg7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT4yPC90aXRsZT48Y2lyY2xlIGNsYXNzPSJjbHMtMSIgY3g9IjQ0LjUiIGN5PSI0NC41IiByPSI0NC41Ii8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNMzksNjVhLjgzLjgzLDAsMCwxLS41OS0uMjVMMzQuOTEsNjEuM2gtNUE1Ljg4LDUuODgsMCwwLDEsMjQsNTUuNDNWNDIuNDlhNS44OSw1Ljg5LDAsMCwxLDUuODgtNS44OGg4LjQ4YS44NC44NCwwLDAsMSwwLDEuNjhIMjkuODhhNC4yMSw0LjIxLDAsMCwwLTQuMiw0LjJWNTUuNDNhNC4yMSw0LjIxLDAsMCwwLDQuMiw0LjJoNS40NmEuODQuODQsMCwwLDEsLjc3LjVsMiwyVjYwLjQ2YS44NC44NCwwLDAsMSwuODQtLjgzSDQ4YTQuMjEsNC4yMSwwLDAsMCw0LjItNC4ydi01LjhhLjg0Ljg0LDAsMCwxLDEuNjgsMHY1LjhBNS44OCw1Ljg4LDAsMCwxLDQ4LDYxLjNIMzkuNzl2Mi44NmEuODUuODUsMCwwLDEtLjUyLjc4QS44Ny44NywwLDAsMSwzOSw2NVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDApIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNjEuNjMsNDkuNGEuODYuODYsMCwwLDEtLjYtLjI1TDU3Ljg5LDQ2YTEyLjQyLDEyLjQyLDAsMCwxLTMuMS4zOUg1Mi42N2ExMi4yMSwxMi4yMSwwLDEsMSwwLTI0LjQxaDIuMTJBMTIuMjMsMTIuMjMsMCwwLDEsNjcsMzQuMjFhMTIuMSwxMi4xLDAsMCwxLTEuMzMsNS41NCwxMi4zNywxMi4zNywwLDAsMS0zLjIxLDR2NC44NmEuODQuODQsMCwwLDEtLjUxLjc4QTEsMSwwLDAsMSw2MS42Myw0OS40Wm0tMy40OS01LjE3YS44My44MywwLDAsMSwuNTkuMjVsMi4wNiwyLjA1VjQzLjI5YS44NC44NCwwLDAsMSwuMzMtLjY3LDEwLjUzLDEwLjUzLDAsMCwwLTYuMzMtMTguOTRINTIuNjdhMTAuNTMsMTAuNTMsMCwxLDAsMCwyMWgyLjEyYTEwLjQ0LDEwLjQ0LDAsMCwwLDMuMS0uNDZBMSwxLDAsMCwxLDU4LjE0LDQ0LjIzWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik01NCwzNy42OWEuODQuODQsMCwwLDEtLjg0LS44NHYtMmExLjU5LDEuNTksMCwwLDEsMS4yNS0xLjU2LDEuODgsMS44OCwwLDAsMC0uMjgtMy43LDEuODgsMS44OCwwLDAsMC0yLDEuODcuODQuODQsMCwxLDEtMS42OCwwLDMuNTUsMy41NSwwLDEsMSw0LjQsMy40NnYyQS44NS44NSwwLDAsMSw1NCwzNy42OVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDApIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNTQsNDFhLjg0Ljg0LDAsMCwxLS42LS4yNS44NS44NSwwLDAsMS0uMjQtLjU5Ljg5Ljg5LDAsMCwxLC4yNC0uNi44Ni44NiwwLDAsMSwxLjE5LDAsLjg2Ljg2LDAsMCwxLC4yNS42LjgyLjgyLDAsMCwxLS4yNS41OUEuODMuODMsMCwwLDEsNTQsNDFaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQ3LjEsNDkuNzFIMjkuMzdhLjg0Ljg0LDAsMCwxLDAtMS42N0g0Ny4xYS44NC44NCwwLDEsMSwwLDEuNjdaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQ3LjEsNTQuNDJhLjg0Ljg0LDAsMCwxLS42LS4yNS44NS44NSwwLDAsMS0uMjQtLjU5Ljg5Ljg5LDAsMCwxLC4yNC0uNi44Ni44NiwwLDAsMSwxLjE5LDAsLjg2Ljg2LDAsMCwxLC4yNS42LjgyLjgyLDAsMCwxLS4yNS41OUEuODMuODMsMCwwLDEsNDcuMSw1NC40MloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDApIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNDMuNzksNTQuNDJIMjkuMzdhLjg0Ljg0LDAsMCwxLDAtMS42OEg0My43OWEuODQuODQsMCwwLDEsMCwxLjY4WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00MS42NCw0NUgyOS4zN2EuODQuODQsMCwwLDEsMC0xLjY4SDQxLjY0YS44NC44NCwwLDEsMSwwLDEuNjhaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwKSIvPjwvc3ZnPg=="

/***/ }),

/***/ "./assets/image/app/3.svg":
/*!********************************!*\
  !*** ./assets/image/app/3.svg ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4OC45MiA4OC45MiI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNmMGZhZWY7fS5jbHMtMntmaWxsOiMzZmM0Mzg7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT4zPC90aXRsZT48Y2lyY2xlIGNsYXNzPSJjbHMtMSIgY3g9IjQ0LjQ2IiBjeT0iNDQuNDYiIHI9IjQ0LjQ2Ii8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNDYuNDYsNDQuODhsLTkuODUtNy4xMmEuNzUuNzUsMCwwLDAtMSwuMDguNzYuNzYsMCwwLDAtLjA4LDFsNy4xMyw5Ljg1YTIuNzIsMi43MiwwLDAsMCwyLDEuMTFoLjIxYTIuNzEsMi43MSwwLDAsMCwyLjctMi45MywyLjY4LDIuNjgsMCwwLDAtMS4xMS0yWm0tLjc1LDNhMS4yLDEuMiwwLDAsMS0uOTMuMzQsMS4xNSwxLjE1LDAsMCwxLS44Ny0uNDhsLTQuMzUtNiw2LDQuMzRhMS4yMSwxLjIxLDAsMCwxLC4xNCwxLjgxWm0wLDAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0wLjA4KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTY0LjM4LDQxLjQzaDBhMjAuMzcsMjAuMzcsMCwwLDAtMi00LjkuMDkuMDksMCwwLDAsMC0uMDVzMCwwLDAsMGEyMC42OSwyMC42OSwwLDAsMC0yLjcyLTMuNjZsMS42NC0xLjYzLDEuMDcsMS4wOEw2NS41MiwyOWwtMy4yMy0zLjIzTDU5LjA2LDI5bDEuMDgsMS4wOEw1OC41MSwzMS43QTIxLjE0LDIxLjE0LDAsMCwwLDU0Ljg1LDI5czAsMCwwLDBoLS4wNWEyMC4zNywyMC4zNywwLDAsMC00LjktMmgwYTIxLjg4LDIxLjg4LDAsMCwwLTMtLjU3di0uODlINDhhMS45LDEuOSwwLDEsMCwwLTMuOEg0MS4xMWExLjksMS45LDAsMSwwLDAsMy44aDEuMTR2Ljg5YTIxLjQ3LDIxLjQ3LDAsMCwwLTMsLjU3aDBhMjAuNDYsMjAuNDYsMCwwLDAtNC44OSwyaDBsMCwwYTIwLjc3LDIwLjc3LDAsMCwwLTMuNjYsMi43MWwtMS42My0xLjYzTDMwLDI5bC0zLjIyLTMuMjNMMjMuNTYsMjlsMy4yMywzLjIzLDEuMDctMS4wOCwxLjYzLDEuNjNhMjEuMTQsMjEuMTQsMCwwLDAtMi43MSwzLjY2bDAsMCwwLC4wNWEyMC4zNCwyMC4zNCwwLDAsMC0yLDQuOWgwYTIwLjMsMjAuMywwLDAsMC0uNyw1LjMxLDIwLjYxLDIwLjYxLDAsMCwwLC42OSw1LjMxaDBhMjAuMjcsMjAuMjcsMCwwLDAsMiw0Ljg5czAsMCwwLDAsMCwwLDAsLjA2QTIwLjU1LDIwLjU1LDAsMCwwLDMwLDYxLjIyczAsMCwwLC4wNWwwLDBhMjAuMzYsMjAuMzYsMCwwLDAsNC4xNywzLjJzMCwwLDAsMCwwLDAsLjA3LDBhMTkuODcsMTkuODcsMCwwLDAsNC44NywyaDBhMjAuNDUsMjAuNDUsMCwwLDAsMTAuNjEsMGgwYTE5Ljk0LDE5Ljk0LDAsMCwwLDQuODgtMmwuMDcsMHMwLDAsMCwwQTIwLjkyLDIwLjkyLDAsMCwwLDU5LDYxLjNsMCwwczAsMCwwLS4wNWEyMC4xOSwyMC4xOSwwLDAsMCwzLjE5LTQuMTVsMC0uMDZhLjA3LjA3LDAsMCwwLDAsMCwyMC4yOSwyMC4yOSwwLDAsMCwyLTQuODloMGEyMC40OSwyMC40OSwwLDAsMCwwLTEwLjYyWk02Mi4yOSwyNy45Miw2My4zNywyOWwtMS4wOCwxLjA4TDYxLjIyLDI5Wk0yNS43MSwyOWwxLjA4LTEuMDdMMjcuODYsMjlsLTEuMDcsMS4wOFpNNjEuMjQsNTJsMS40Ni4zOWExNy43OSwxNy43OSwwLDAsMS0xLjMzLDMuMThsLTEuMy0uNzVhLjc4Ljc4LDAsMCwwLTEsLjI4Ljc2Ljc2LDAsMCwwLC4yOCwxbDEuMy43NWExOS4zMiwxOS4zMiwwLDAsMS0yLjEsMi43NGwtMS4wNi0xLjA2YS43Ni43NiwwLDAsMC0xLjA4LDAsLjc4Ljc4LDAsMCwwLDAsMS4wOGwxLjA2LDEuMDVhMTkuMjMsMTkuMjMsMCwwLDEtMi43MywyLjFsLS43Ni0xLjI5YS43NC43NCwwLDAsMC0xLS4yOC43Ni43NiwwLDAsMC0uMjgsMWwuNzUsMS4zYTE4LjYyLDE4LjYyLDAsMCwxLTMuMTksMS4zMmwtLjM5LTEuNDVhLjc1Ljc1LDAsMCwwLS45My0uNTQuNzcuNzcsMCwwLDAtLjU0LjkzbC4zOSwxLjQ1YTE4LjQsMTguNCwwLDAsMS0zLjQyLjQ1di0xLjVhLjc2Ljc2LDAsMCwwLTEuNTIsMHYxLjVhMTguMjksMTguMjksMCwwLDEtMy40Mi0uNDVsLjM4LTEuNDVhLjc2Ljc2LDAsMSwwLTEuNDctLjM5bC0uMzksMS40NWExOC41MiwxOC41MiwwLDAsMS0zLjE4LTEuMzJsLjc1LTEuM2EuNzYuNzYsMCwxLDAtMS4zMi0uNzZsLS43NSwxLjI5YTE5LjksMTkuOSwwLDAsMS0yLjc0LTIuMWwxLjA2LTEuMDVhLjc2Ljc2LDAsMCwwLDAtMS4wOC43NS43NSwwLDAsMC0xLjA3LDBsLTEuMDYsMS4wNmExOS4zMiwxOS4zMiwwLDAsMS0yLjEtMi43NGwxLjI5LS43NWEuNzUuNzUsMCwwLDAsLjI4LTEsLjc2Ljc2LDAsMCwwLTEtLjI4bC0xLjI5Ljc1YTE3Ljc5LDE3Ljc5LDAsMCwxLTEuMzMtMy4xOEwyNy44Myw1MmEuNzYuNzYsMCwwLDAtLjM5LTEuNDdMMjYsNTAuOTNhMTguNTEsMTguNTEsMCwwLDEtLjQ1LTMuNDNIMjdBLjc2Ljc2LDAsMCwwLDI3LDQ2aC0xLjVBMTguNCwxOC40LDAsMCwxLDI2LDQyLjU2bDEuNDUuMzlhLjY5LjY5LDAsMCwwLC4yLDAsLjc2Ljc2LDAsMCwwLC4xOS0xLjVsLTEuNDUtLjM5YTE3Ljg5LDE3Ljg5LDAsMCwxLDEuMzMtMy4xOWwxLjI5Ljc2YS44NS44NSwwLDAsMCwuMzguMDkuNzUuNzUsMCwwLDAsLjM4LTEuNDFsLTEuMjktLjc1YTE4LjA5LDE4LjA5LDAsMCwxLDIuMS0yLjc0bDEuMDYsMS4wNmEuNzcuNzcsMCwwLDAsLjUzLjIyLjc5Ljc5LDAsMCwwLC41NC0uMjIuNzYuNzYsMCwwLDAsMC0xLjA4bC0xLjA2LTEuMDZhMTkuODMsMTkuODMsMCwwLDEsMi43NC0yLjA5TDM1LjEzLDMyYS43Ny43NywwLDAsMCwuNjYuMzguNzUuNzUsMCwwLDAsLjM4LS4xLjc3Ljc3LDAsMCwwLC4yOC0xbC0uNzUtMS4zYTE5LjM5LDE5LjM5LDAsMCwxLDMuMTgtMS4zM0wzOS4yNywzMGEuNzYuNzYsMCwwLDAsLjc0LjU2LjYzLjYzLDAsMCwwLC4xOSwwLC43NC43NCwwLDAsMCwuNTQtLjkybC0uMzgtMS40NmExNy42MSwxNy42MSwwLDAsMSwyLjczLS40bC42Ni0uMDVoMHYxLjVhLjc2Ljc2LDAsMSwwLDEuNTIsMHYtMS41aDBsLjY1LjA1YTE4Ljg0LDE4Ljg0LDAsMCwxLDIuNzQuNGwtLjM5LDEuNDZhLjc1Ljc1LDAsMCwwLC41NC45Mi42OS42OSwwLDAsMCwuMiwwQS43NS43NSwwLDAsMCw0OS44LDMwbC4zOS0xLjQ2YTE5LjUsMTkuNSwwLDAsMSwzLjE5LDEuMzNsLS43NSwxLjNhLjc2Ljc2LDAsMCwwLC4yOCwxLC43NS43NSwwLDAsMCwuMzguMUEuNzcuNzcsMCwwLDAsNTQsMzJsLjc1LTEuMjlhMTkuMTYsMTkuMTYsMCwwLDEsMi43MywyLjA5bC0xLjA2LDEuMDZhLjc4Ljc4LDAsMCwwLDAsMS4wOC44MS44MSwwLDAsMCwuNTQuMjIuNzkuNzksMCwwLDAsLjU0LS4yMmwxLjA2LTEuMDZhMTguNzYsMTguNzYsMCwwLDEsMi4xLDIuNzRsLTEuMy43NWEuNzYuNzYsMCwwLDAtLjI4LDEsLjc3Ljc3LDAsMCwwLC42Ni4zNy44NS44NSwwLDAsMCwuMzgtLjA5bDEuMy0uNzZhMTcuODksMTcuODksMCwwLDEsMS4zMywzLjE5bC0xLjQ2LjM5YS43Ni43NiwwLDAsMCwuMiwxLjVsLjIsMCwxLjQ1LS4zOUExOS4yOCwxOS4yOCwwLDAsMSw2My41NCw0Nkg2MmEuNzYuNzYsMCwxLDAsMCwxLjUyaDEuNWExOS4zOSwxOS4zOSwwLDAsMS0uNDUsMy40M2wtMS40NS0uMzlhLjc2Ljc2LDAsMCwwLS40LDEuNDdaTTQzLjc4LDI2LjIydi0yLjNINDEuMTFhLjM4LjM4LDAsMSwxLDAtLjc2SDQ4YS4zOC4zOCwwLDAsMSwwLC43Nkg0NS4zdjIuM2wtLjc2LDAtLjc2LDBabTAsMCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTAuMDgpIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/app/4.svg":
/*!********************************!*\
  !*** ./assets/image/app/4.svg ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4OC44NiA4OC44NiI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNmZmY0ZjQ7fS5jbHMtMntmaWxsOiNmZjcwNzA7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT40PC90aXRsZT48Y2lyY2xlIGNsYXNzPSJjbHMtMSIgY3g9IjQ0LjQzIiBjeT0iNDQuNDMiIHI9IjQ0LjQzIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNjguMDgsMjUuMTcsNjQsMjUsNjMuODcsMjFhLjg4Ljg4LDAsMCwwLS45LS44NC44OS44OSwwLDAsMC0uNTkuMjZsLTcuNDksNy40NWEuOTEuOTEsMCwwLDAtLjI1LjY1di44NmExOS41OCwxOS41OCwwLDEsMCw1LDVoLjg3YS44Ni44NiwwLDAsMCwuNjEtLjI1bDcuNS03LjVhLjg3Ljg3LDAsMCwwLDAtMS4yMy44My44MywwLDAsMC0uNTgtLjI1Wk02MS40LDQ1LjQ2YTE3Ljg1LDE3Ljg1LDAsMSwxLTYuNjUtMTMuODhsMCwxLjQ1TDUxLjMyLDM2LjVhMTEuOSwxMS45LDAsMSwwLDEuMjEsMS4yM0w1NiwzNC4yNmwxLjQzLjA1YTE3LjgyLDE3LjgyLDAsMCwxLDQsMTEuMTVaTTQzLDQ2YS44Ni44NiwwLDAsMCwxLjIyLDBMNDYsNDQuMzFhMi41NiwyLjU2LDAsMCwxLC4yNiwxLjEyLDIuNjIsMi42MiwwLDEsMS0xLjQ4LTIuMzRMNDMsNDQuODJBLjg2Ljg2LDAsMCwwLDQzLDQ2Wm0zLTQuMjNBNC4zMiw0LjMyLDAsMSwwLDQ3LjIyLDQzbDQuMTEtNC4xMWExMC4xMywxMC4xMywwLDEsMS0xLjIyLTEuMjJabTE0LjI1LTkuMi0zLjctLjEyLS4xMi0zLjY5TDYyLjIzLDIzbC4xLDIuODlhLjg3Ljg3LDAsMCwwLC44Ny44N2wyLjg5LjA5WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAtMC4xNCkiLz48L3N2Zz4="

/***/ }),

/***/ "./assets/image/app/5.jpg":
/*!********************************!*\
  !*** ./assets/image/app/5.jpg ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4gKgSUNDX1BST0ZJTEUAAQEAAAKQbGNtcwQwAABtbnRyUkdCIFhZWiAH3wAIABMAEgAWADFhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtkZXNjAAABCAAAADhjcHJ0AAABQAAAAE53dHB0AAABkAAAABRjaGFkAAABpAAAACxyWFlaAAAB0AAAABRiWFlaAAAB5AAAABRnWFlaAAAB+AAAABRyVFJDAAACDAAAACBnVFJDAAACLAAAACBiVFJDAAACTAAAACBjaHJtAAACbAAAACRtbHVjAAAAAAAAAAEAAAAMZW5VUwAAABwAAAAcAHMAUgBHAEIAIABiAHUAaQBsAHQALQBpAG4AAG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAMgAAABwATgBvACAAYwBvAHAAeQByAGkAZwBoAHQALAAgAHUAcwBlACAAZgByAGUAZQBsAHkAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1zZjMyAAAAAAABDEoAAAXj///zKgAAB5sAAP2H///7ov///aMAAAPYAADAlFhZWiAAAAAAAABvlAAAOO4AAAOQWFlaIAAAAAAAACSdAAAPgwAAtr5YWVogAAAAAAAAYqUAALeQAAAY3nBhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbcGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW2Nocm0AAAAAAAMAAAAAo9cAAFR7AABMzQAAmZoAACZmAAAPXP/bAEMACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0Mv/bAEMBCQkJDAsMGA0NGDIhHCEyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAIAAgAMBIgACEQEDEQH/xAAcAAABBAMBAAAAAAAAAAAAAAABAAUGBwIDBAj/xAA2EAABAwMBBgMHAwQDAQAAAAABAAIDBAUREgYTITFBUSJxgRQyYZGxwdEHQqEkUmLhFRYjkv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAAEEBQb/xAAkEQACAgIDAAEEAwAAAAAAAAAAAQIRAyEEEjETBSJRcTJBYf/aAAwDAQACEQMRAD8AuIIoIogAooIqygorB72xsc97g1rRkk9FFrlfnVD3Rwu0Qj5uQyko+hRi5eEjlr6aEkOlBI6N4rSbpCG6j4R0zzPoFEIpZpn+Ahv+TuJ9E9Qtipodc0haD15ud5BI+Vsb8aXoq/a6GgJ1UsrgBknTj6rgp/1JtEkgjnbNTk9Xxkt/+m5Cbrvbam9sc2XeU9G0jTFry6Q9M/hddk/T6kpId7UwNmqJCOBOGxjoD3KLvIroiX0VxprhCJaeVr2njlpyutR+k2dlttQZ4KwMZpwIGjwD5lbI785leaSppZWHmJG+JpHfKYppgOLQ9pIAhwBHIpIwBJFJBQhgiEAiFRYQkgmzaCuNDaZHsOJHeBvmVG6VkSt0Me0l93spoqY5Y0+N3Qn8JgjdrcA3xOPU9f8AS485Jy4c8ucep/CzirNBIh4D9zz1WGU7dmyMElRIIXspeBw+fGeJ4N8/wtsEstTUtHFzz1Pb7BNVHvJQA0EAnOo83fH/AGpBR7qniw14yfekz9+qFMNxHiljYwjhqc3kTxPxwnaIZA+6ZoJWDGhjnZ68gnaEvewftHw4BOixTVGc2GsOdI4c3KFXmSuq75Rw0kQ3EWZKieQaQG8g0D4n7KauaGgiNu8eeJJPBN89JLUN8btWg5HDAL++OwUZSMbTWxV9vZNFqxyIcMEELuTdTBtNUbiP3A0D5BOC0QdozzVMWUksoIwTBFBIKEMlFdtJSIKaMHHEuKlKg+3Ly6rgizhugl3wHVLyv7WMxK5Ih8k2+IAJEecNGeLvj5LvoossDsZHl9E2x6ZZNTvDGPp2WFde45P6WlqI4tPAZIGT6rAb0vwSiOox4RgA+84nn6ruiuAhLdA1n+5x5Kt6SsrYagtqqkyuJ8Jxj+FLpIql9qM0b9GW8Ceioaoa2TigrXStDsMb8SOKeYtUgGpxLe5+wVQ2eouftIabs52T7ugHPqrOtNNX7gb+r3zSPE1zNJPljknQaehGSFDo6piax5Em7iZ78h+gXJV1OId7lzIgzIYOePyue4QvxGGs8OsAN6D/ACPfH1QinirgZmODoi4Mb5BFYlqjfSsc58kjxgkN4dua61wWWqFbb2VGCDM4uAPMN6LsJ4p+LwRlM8pZWGUU0UBFYhFUWFV/t0S67xR8muhGT8MqwFDNvKJz4IqxgyWjQ49uyXl3EbidSKxrp31VWaKnJaxoySO6aX7INZG9swlcHuD3OyMkjlxKdLWA2uqJH/3NH8KRVNWz2XJ7LCm1tHSUIyWyL0NvdC6CnBeQHjRqOSB2VwVdnd/1YwRt/wDQx8Pkq4sX9XdoXubpZrGCeo7q7i3eW0OjbqLW8B3RRjdkm+tJHn6usdbV1JY6rnpmBww5jT4QPLn6q09jLdcKBsRgv0lZSFgaaaoYXBuBza4kuB7g5HwCa6y50tRWvi3ZjeHYc1wwQVMdm42NaC3lhXBu6JkikuzHS4QuNuqCPf3biPPCqj9OdonubHa6txLyXkPJ65JH1x6K27tKYrXVPAyRE/A7nBVE7OUEtJtDSs0k6JwHO8zghMemZ6bjZcdqjZT0jo2DAY4tC68rVBHuosY4klx81sWnGqiYcjuRkllAIhGCBFBFUWFc9dSR11FLTyDLXtI8l0BJUXZRt4tNRZ7hPFI3Trw5p6HHBcEk0jgwO93l6q3tsrJ/y1oL4WZqYTqZ8R1H0VRVEDKqikgkaQRkdiCsOWHWR0+Pk7RFRzVNHXQmNwc1pHAHBVq2m+19QIzTgMhaMFsjclx+ap2wW6gn3dNXvqIpA7G+DstcB9CrVtVqsVDa4Zpa2eUmPIDS4knIzgD4FUou9Dvtqpe/oZ9qrfUR1Elw3ZDy7UeGAVKtibgKi3skzwPDj0KiV7ornc6xk8EtdTW+QhraSZ+S49SW8cAeamWzlsFupBG39ztXkotSKl/CmO21N3pbLs7U3GtL/Z4tOsMGScuAwB6qK7JUrbs1t6ex+5kOuESBoceJ4uDeGfJP+1NpO0NLSWyRgNE6cS1Rzza3iGjzOPknKCnipadkEEbY4o2hrWtGAAFojj7O2YJ5eq6oyKCywlhaTIBEJJKEMQigEVRYUViioQJAIIPVVrtzYW0FY2507cQVLtMoH7X9/X6hWVlcl0pKWvtlRTVuPZ3sOs5xpxx1A9COaDJDtGhuKbhKyjW2uT2newSuZq544g+in2ytGYpGzTPMj28WgNAwofRV0cFU6F7w5oOGudw1DoVPbRdKCBrdU0eojg1pyT6BYbr+zsd5dKRIvZN6/ey4yPhyXRTx+PDeXfssaZz6wBzssj6N6nzTiyJrAABgI1vaMrdaZp06SQTniktkvv5WtbIO4o5+RVJgwkikjAAkigVCGsJZWuSaOGMySvaxg5uccAJiqtqqeNxbSxOmP9x8I/KCU4x9DjCUvESIJuvG0Fp2fp2zXWvhpWPzo3h4uxzwBxKi1XtTcJGnS5sDe7Bx+ZVD7WX+p2gvs1TNM+VkZ3cOp2fCD9+amOayPReTG4LZaF2/XVjKmRlotTZIG5DZal5Bce+kch5lcLNqL5erSJrhXPd7SNRiYA2No6AAKocHGOqs21NJs1K3HERgfwg5T6xSQzixTk2zAtEziCn6wwbmoa4DHHoE1tgO9BA9FJLfTua0ODeK5sjpw0WFaagua0Ek+akAcC3KiNnbI0AkKTsfiLJTsb0IyrZue3U3yULuW39stV+fbKlkmmMAPmZ4sPPTCeNoL9HZbPUVbiCWN8I7novPE9TLVVktTM4ukkLnuJ6kldPg4fkk2/DncyfSKr09C2zaizXZzI6SvidM/lE7wv8AkU7rznsdUvG1Nvbk5FWz6r0O2XuPkj5EYYpJJ+isPfIm6NqCQcDySSk0/A2mvStrpepLtWu0kimYcRt+5+K1sZlqa6LmMp13ga1cuUnJ2zrQioqkM21VULfs7VzA4foLWeZ4fdUnjAHmrI/Uiv8A6OmpQffeXkfAD8lVyBlkY75K6XDhWO/yc7ly++vwGMZljGM5I+qvWlpab2eMNiDQGjgAqNb4J2EftwR6cV6Et0Daihp5WjwyRtcPUIebGkhnCabZjTWykmOHsHDkU7U9BHF7ucLXFTljuSc4W8srnUb26OmmeI2Dgt7qzIw44C1BgwmLaq7w2a0S1Dj4sYYM8S7oEyKb0hcmvWRD9S9pI6qaCz0rsiM7ydw79B6c/kq/Mni7cM/RYmd9XUyVEpJe4l7s9StD3nWT105+y9NxsXw4lE8/nyfLkch32Lk07X21zjw3+r5L0HHUa25yvPWxzc7YW9nYk/wVdrKgsAHRcn6lKpx/R0+BG4N/6P8AFL4hxTg2IvZkc1HqSoy8EqUUUgfGFjxt3o0ZUq2f/9k="

/***/ }),

/***/ "./assets/image/app/5.svg":
/*!********************************!*\
  !*** ./assets/image/app/5.svg ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4OSA4OSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNmZmY2ZWI7fS5jbHMtMntmaWxsOiNmZjkxMDI7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT41PC90aXRsZT48Y2lyY2xlIGNsYXNzPSJjbHMtMSIgY3g9IjQ0LjUiIGN5PSI0NC41IiByPSI0NC41Ii8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNTkuMzMsNDMuM2EuOC44LDAsMCwxLS44LjguOC44LDAsMCwxLDAtMS42LjguOCwwLDAsMSwuOC44Wm0wLDAiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0zMC41Myw0My4zYS44LjgsMCwxLDEtLjc5LS44Ljc5Ljc5LDAsMCwxLC43OS44Wm0wLDAiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0zMi45NCw0NS43YS44MS44MSwwLDEsMS0uODEtLjguOC44LDAsMCwxLC44MS44Wm0wLDAiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0zNy43NCw0NS43YS44MS44MSwwLDEsMS0uOC0uOC44LjgsMCwwLDEsLjguOFptMCwwIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNMzUuMzMsNDguMWEuOC44LDAsMCwxLS44LjguOC44LDAsMCwxLDAtMS42LjguOCwwLDAsMSwuOC44Wm0wLDAiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00MC4xMyw0OC4xYS44LjgsMCwxLDEtLjgtLjguOC44LDAsMCwxLC44LjhabTAsMCIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQyLjUzLDUwLjVhLjguOCwwLDEsMS0uNzktLjguNzkuNzksMCwwLDEsLjc5LjhabTAsMCIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQ3LjMzLDUwLjVhLjguOCwwLDAsMS0uOC44LjguOCwwLDAsMSwwLTEuNi44LjgsMCwwLDEsLjguOFptMCwwIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNDkuNzQsNDguMWEuODEuODEsMCwxLDEtLjgtLjguOC44LDAsMCwxLC44LjhabTAsMCIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQ0Ljk0LDUyLjlhLjgxLjgxLDAsMSwxLS44MS0uOC44LjgsMCwwLDEsLjgxLjhabTAsMCIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTUyLjEzLDQ1LjdhLjguOCwwLDEsMS0uOC0uOC44LjgsMCwwLDEsLjguOFptMCwwIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNTYuOTQsNDUuN2EuODEuODEsMCwxLDEtLjgxLS44LjguOCwwLDAsMSwuODEuOFptMCwwIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNTQuNTMsNDguMWEuOC44LDAsMSwxLS43OS0uOC43OS43OSwwLDAsMSwuNzkuOFptMCwwIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNTksNDguNzVsNy41Mi00LjI5LTcuNzItNC4zOSw3LjcyLTQuNDEtMjItMTIuNDgtMjIsMTIuNDgsNy43Miw0LjQxLTcuNzIsNC4zOSw3LjcyLDQuNDItNy43Miw0LjM4LDIyLDEyLjU2LDIyLTEyLjU2LTcuNzItNC4zOC4wNSwwYS4zOC4zOCwwLDAsMCwuMTUtLjA5Wk00NC41LDI1LDYzLjI1LDM1LjY3bC02LjExLDMuNDlMNDQuNSw0Ni4zOCwyNS43NSwzNS42N1pNMzEuNDIsNDEuMjVhLjc5Ljc5LDAsMCwwLDEuMjcuMjJsMS44MSwxYS43OS43OSwwLDAsMC0uNzYuNzkuNzkuNzksMCwwLDAsLjc5LjguOC44LDAsMCwwLC44LS44Ljc2Ljc2LDAsMCwwLS4xLS4zN2w4LjI2LDQuNzFhLjg1Ljg1LDAsMCwwLS4xNi40Ni44MS44MSwwLDAsMCwxLjYxLDAsLjUzLjUzLDAsMCwwLDAtLjEybDgtNC41OWEuNzkuNzksMCwxLDAsMS4yNi0uNzJsMS43Ni0xLC4xNiwwYS43OS43OSwwLDAsMCwuNzUtLjU2bC4yNi0uMTQsNi4xMSwzLjQ2LTEuNTkuOTFhLjc4Ljc4LDAsMCwwLS43Mi0uNDcuOC44LDAsMCwwLS44MS44Ljc5Ljc5LDAsMCwwLC4xNi40NUw1Ny4xNCw0OCw1Miw1MC44OGEuODMuODMsMCwwLDAsLjEtLjM4LjguOCwwLDEsMC0uODMuNzlsLTEuODEsMWEuODIuODIsMCwwLDAtLjU1LS4yMi44LjgsMCwwLDAtLjgxLjgsMS4xNiwxLjE2LDAsMCwwLDAsLjE4bC0zLjY3LDIuMS00LjQxLTIuNTJhLjgxLjgxLDAsMCwwLS43Ni0uNTZsLS4xNiwwLTEuNzYtMWEuNzkuNzksMCwwLDAtLjQ3LTEuNDMuOC44LDAsMCwwLS43OS43MWwtOC00LjU5YS41LjUsMCwwLDAsMC0uMTIuOC44LDAsMCwwLS44LS44Ljc2Ljc2LDAsMCwwLS40OS4xOWwtMS4wOS0uNjJabTMxLjgzLDEyTDQ0LjUsNjQsMjUuNzUsNTMuMjdsNi4xMS0zLjQ3TDQ0LjUsNTcsNTcuMTQsNDkuOFptMCwwIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/app/6.png":
/*!********************************!*\
  !*** ./assets/image/app/6.png ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/6-c75e78614b9d8f601983fc2faf62ddfe.png";

/***/ }),

/***/ "./assets/image/app/6.svg":
/*!********************************!*\
  !*** ./assets/image/app/6.svg ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4OC41NiA4OC41NiI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNlYmZiZjQ7fS5jbHMtMntmaWxsOiMwMGM2NzQ7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT42PC90aXRsZT48Y2lyY2xlIGNsYXNzPSJjbHMtMSIgY3g9IjQ0LjI4IiBjeT0iNDQuMjgiIHI9IjQ0LjI4Ii8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNTQuNywyMy41OEg0OS41VjIwLjRIMzkuOTR2My4xOGgtNS4yQTIuNzcsMi43NywwLDAsMCwzMiwyNi4zNFY2NS40MWEyLjc2LDIuNzYsMCwwLDAsMi43NiwyLjc1aDIwYTIuNzYsMi43NiwwLDAsMCwyLjc2LTIuNzVWMjYuMzRhMi43NywyLjc3LDAsMCwwLTIuNzYtMi43NlpNNDEuNTQsMjJINDcuOXYxLjU5SDQxLjU0Wk01NS44Niw2NS40MWExLjE2LDEuMTYsMCwwLDEtMS4xNiwxLjE2aC0yMGExLjE2LDEuMTYsMCwwLDEtMS4xNi0xLjE2VjI2LjM0YTEuMTYsMS4xNiwwLDAsMSwxLjE2LTEuMTZoMjBhMS4xNiwxLjE2LDAsMCwxLDEuMTYsMS4xNlptMCwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMC40NCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00Ny45LDM0YS44My44MywwLDAsMC0uNDgtLjgxTDQ2LjgsMzNsLS4zOS40OS04LjY5LDE0aDQuNjFWNTcuNzJhLjgzLjgzLDAsMCwwLC40Ny44bC42My4yOC40LS41MSw3Ljc4LTE0LjgxSDQ3LjlaTTQ5LDQ1LjA4bC01LjA2LDkuNjNWNDUuODdINDAuNThsNS43My05LjI1djguNDZabTAsMCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTAuNDQpIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/app/apple.svg":
/*!************************************!*\
  !*** ./assets/image/app/apple.svg ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8c3ZnIHdpZHRoPSIyNTZweCIgaGVpZ2h0PSIzMTVweCIgdmlld0JveD0iMCAwIDI1NiAzMTUiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgcHJlc2VydmVBc3BlY3RSYXRpbz0ieE1pZFlNaWQiPg0KICAgIDxnPg0KICAgICAgICA8cGF0aCBkPSJNMjEzLjgwMzM5NCwxNjcuMDMwOTQzIEMyMTQuMjQ1MiwyMTQuNjA5NjQ2IDI1NS41NDI0ODIsMjMwLjQ0MjYzOSAyNTYsMjMwLjY0NDcyNyBDMjU1LjY1MDgxMiwyMzEuNzYxMzU3IDI0OS40MDEzODMsMjUzLjIwODI5MyAyMzQuMjQyNjMsMjc1LjM2MTQ0NiBDMjIxLjEzODU1NSwyOTQuNTEzOTY5IDIwNy41MzgyNTMsMzEzLjU5NjMzMyAxODYuMTEzNzU5LDMxMy45OTE1NDUgQzE2NS4wNjIwNTEsMzE0LjM3OTQ0MiAxNTguMjkyNzUyLDMwMS41MDc4MjggMTM0LjIyNDY5LDMwMS41MDc4MjggQzExMC4xNjM4OTgsMzAxLjUwNzgyOCAxMDIuNjQyODk5LDMxMy41OTYzMDEgODIuNzE1MTEyNiwzMTQuMzc5NDQyIEM2Mi4wMzUwNDA3LDMxNS4xNjIwMSA0Ni4yODczODMxLDI5My42Njg1MjUgMzMuMDc0NDA3OSwyNzQuNTg2MTYyIEM2LjA3NTI5MzE3LDIzNS41NTI1NDQgLTE0LjU1NzYxNjksMTY0LjI4NjMyOCAxMy4xNDcxNjYsMTE2LjE4MDQ3IEMyNi45MTAzMTExLDkyLjI5MDkwNTMgNTEuNTA2MDkxNyw3Ny4xNjMwMzU2IDc4LjIwMjYxMjUsNzYuNzc1MTA5NiBDOTguNTA5OTE0NSw3Ni4zODc3NDU2IDExNy42Nzc1OTQsOTAuNDM3MTg1MSAxMzAuMDkxNzA1LDkwLjQzNzE4NTEgQzE0Mi40OTc5NDUsOTAuNDM3MTg1MSAxNjUuNzkwNzU1LDczLjU0MTUwMjkgMTkwLjI3NzYyNyw3Ni4wMjI4NDc0IEMyMDAuNTI4NjY4LDc2LjQ0OTUwNTUgMjI5LjMwMzUwOSw4MC4xNjM2ODc4IDI0Ny43ODA2MjUsMTA3LjIwOTM4OSBDMjQ2LjI5MTgyNSwxMDguMTMyMzMzIDIxMy40NDYzNSwxMjcuMjUzNDA1IDIxMy44MDMzOTQsMTY3LjAzMDk4OCBNMTc0LjIzOTE0Miw1MC4xOTg3MDMzIEMxODUuMjE4MzMxLDM2LjkwODgzMTkgMTkyLjYwNzk1OCwxOC40MDgxMDE5IDE5MC41OTE5ODgsMCBDMTc0Ljc2NjMxMiwwLjYzNjA1MDIyNSAxNTUuNjI5NTE0LDEwLjU0NTc5MDkgMTQ0LjI3ODEwOSwyMy44MjgzNTA2IEMxMzQuMTA1MDcsMzUuNTkwNjc1OCAxMjUuMTk1Nzc1LDU0LjQxNzAyNzUgMTI3LjU5OTY1Nyw3Mi40NjA3OTMyIEMxNDUuMjM5MjMxLDczLjgyNTU0MzMgMTYzLjI1OTQxMyw2My40OTcwMjYyIDE3NC4yMzkxNDIsNTAuMTk4NzI0OSIgZmlsbD0iIzAwMDAwMCI+PC9wYXRoPg0KICAgIDwvZz4NCjwvc3ZnPg=="

/***/ }),

/***/ "./assets/image/app/credit-card.png":
/*!******************************************!*\
  !*** ./assets/image/app/credit-card.png ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/credit-card-e7b0300438ee2c95451209ec1aa861b0.png";

/***/ }),

/***/ "./assets/image/app/dribbble.svg":
/*!***************************************!*\
  !*** ./assets/image/app/dribbble.svg ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8c3ZnIHdpZHRoPSIyNTZweCIgaGVpZ2h0PSIyNTZweCIgdmlld0JveD0iMCAwIDI1NiAyNTYiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgcHJlc2VydmVBc3BlY3RSYXRpbz0ieE1pZFlNaWQiPg0KCTxnPg0KCQk8cGF0aCBkPSJNMTI4LDguNSBDMTk0LDguNSAyNDcuNCw2MS45IDI0Ny40LDEyNy44IEMyNDcuNCwxOTMuNyAxOTQsMjQ3LjIgMTI4LDI0Ny4yIEM2MiwyNDcuMiA4LjYsMTkzLjggOC42LDEyNy45IEM4LjYsNjIgNjIsOC41IDEyOCw4LjUgTDEyOCw4LjUgTDEyOCw4LjUgWiIgZmlsbD0iI0U3NEQ4OSI+PC9wYXRoPg0KCQk8cGF0aCBkPSJNMTI4LDI1NS43IEM1Ny40LDI1NS43IDAsMTk4LjQgMCwxMjcuOSBDMCw1Ny4zIDU3LjQsMCAxMjgsMCBDMTk4LjYsMCAyNTYsNTcuMyAyNTYsMTI3LjggQzI1NiwxOTguMyAxOTguNiwyNTUuNyAxMjgsMjU1LjcgTDEyOCwyNTUuNyBMMTI4LDI1NS43IFogTTIzNS45LDE0NS4zIEMyMzIuMiwxNDQuMSAyMDIuMSwxMzUuMiAxNjcuOCwxNDAuNiBDMTgyLjEsMTc5LjggMTg3LjksMjExLjggMTg5LDIxOC40IEMyMTMuNiwyMDEuOSAyMzEuMSwxNzUuNyAyMzUuOSwxNDUuMyBMMjM1LjksMTQ1LjMgTDIzNS45LDE0NS4zIFogTTE3MC43LDIyOC41IEMxNjkuMSwyMTguOSAxNjIuNywxODUuNSAxNDcuNCwxNDUuNyBDMTQ3LjIsMTQ1LjggMTQ2LjksMTQ1LjkgMTQ2LjcsMTQ1LjkgQzg1LDE2Ny40IDYyLjksMjEwLjEgNjAuOSwyMTQuMSBDNzkuNCwyMjguNSAxMDIuNywyMzcuMSAxMjgsMjM3LjEgQzE0My4xLDIzNy4yIDE1Ny42LDIzNC4xIDE3MC43LDIyOC41IEwxNzAuNywyMjguNSBMMTcwLjcsMjI4LjUgWiBNNDYuOCwyMDEgQzQ5LjMsMTk2LjggNzkuMywxNDcuMiAxMzUuNywxMjguOSBDMTM3LjEsMTI4LjQgMTM4LjYsMTI4IDE0MCwxMjcuNiBDMTM3LjMsMTIxLjQgMTM0LjMsMTE1LjIgMTMxLjEsMTA5LjEgQzc2LjUsMTI1LjQgMjMuNSwxMjQuNyAxOC43LDEyNC42IEMxOC43LDEyNS43IDE4LjYsMTI2LjggMTguNiwxMjcuOSBDMTguNywxNTYgMjkuMywxODEuNiA0Ni44LDIwMSBMNDYuOCwyMDEgTDQ2LjgsMjAxIFogTTIxLDEwNS42IEMyNS45LDEwNS43IDcwLjksMTA1LjkgMTIyLjEsOTIuMyBDMTA0LDYwLjEgODQuNCwzMy4xIDgxLjYsMjkuMiBDNTAuOSw0My42IDI4LjEsNzEuOCAyMSwxMDUuNiBMMjEsMTA1LjYgTDIxLDEwNS42IFogTTEwMi40LDIxLjggQzEwNS40LDI1LjggMTI1LjMsNTIuOCAxNDMuMiw4NS43IEMxODIuMSw3MS4xIDE5OC41LDQ5LjEgMjAwLjUsNDYuMyBDMTgxLjIsMjkuMiAxNTUuOCwxOC44IDEyOCwxOC44IEMxMTkuMiwxOC44IDExMC42LDE5LjkgMTAyLjQsMjEuOCBMMTAyLjQsMjEuOCBMMTAyLjQsMjEuOCBaIE0yMTIuNiw1OC45IEMyMTAuMyw2MiAxOTIsODUuNSAxNTEuNiwxMDIgQzE1NC4xLDEwNy4yIDE1Ni42LDExMi41IDE1OC45LDExNy44IEMxNTkuNywxMTkuNyAxNjAuNSwxMjEuNiAxNjEuMywxMjMuNCBDMTk3LjcsMTE4LjggMjMzLjgsMTI2LjIgMjM3LjQsMTI2LjkgQzIzNy4xLDEwMS4yIDIyNy45LDc3LjUgMjEyLjYsNTguOSBMMjEyLjYsNTguOSBMMjEyLjYsNTguOSBaIiBmaWxsPSIjQjIyMTVBIj48L3BhdGg+DQoJPC9nPg0KPC9zdmc+"

/***/ }),

/***/ "./assets/image/app/google.svg":
/*!*************************************!*\
  !*** ./assets/image/app/google.svg ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8c3ZnIHdpZHRoPSIyNTZweCIgaGVpZ2h0PSIyNjJweCIgdmlld0JveD0iMCAwIDI1NiAyNjIiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgcHJlc2VydmVBc3BlY3RSYXRpbz0ieE1pZFlNaWQiPg0KCTxnPg0KCQk8cGF0aCBkPSJNMjU1Ljg3OCwxMzMuNDUxIEMyNTUuODc4LDEyMi43MTcgMjU1LjAwNywxMTQuODg0IDI1My4xMjIsMTA2Ljc2MSBMMTMwLjU1LDEwNi43NjEgTDEzMC41NSwxNTUuMjA5IEwyMDIuNDk3LDE1NS4yMDkgQzIwMS4wNDcsMTY3LjI0OSAxOTMuMjE0LDE4NS4zODEgMTc1LjgwNywxOTcuNTY1IEwxNzUuNTYzLDE5OS4xODcgTDIxNC4zMTgsMjI5LjIxIEwyMTcuMDAzLDIyOS40NzggQzI0MS42NjIsMjA2LjcwNCAyNTUuODc4LDE3My4xOTYgMjU1Ljg3OCwxMzMuNDUxIiBmaWxsPSIjNDI4NUY0Ij48L3BhdGg+DQoJCTxwYXRoIGQ9Ik0xMzAuNTUsMjYxLjEgQzE2NS43OTgsMjYxLjEgMTk1LjM4OSwyNDkuNDk1IDIxNy4wMDMsMjI5LjQ3OCBMMTc1LjgwNywxOTcuNTY1IEMxNjQuNzgzLDIwNS4yNTMgMTQ5Ljk4NywyMTAuNjIgMTMwLjU1LDIxMC42MiBDOTYuMDI3LDIxMC42MiA2Ni43MjYsMTg3Ljg0NyA1Ni4yODEsMTU2LjM3IEw1NC43NSwxNTYuNSBMMTQuNDUyLDE4Ny42ODcgTDEzLjkyNSwxODkuMTUyIEMzNS4zOTMsMjMxLjc5OCA3OS40OSwyNjEuMSAxMzAuNTUsMjYxLjEiIGZpbGw9IiMzNEE4NTMiPjwvcGF0aD4NCgkJPHBhdGggZD0iTTU2LjI4MSwxNTYuMzcgQzUzLjUyNSwxNDguMjQ3IDUxLjkzLDEzOS41NDMgNTEuOTMsMTMwLjU1IEM1MS45MywxMjEuNTU2IDUzLjUyNSwxMTIuODUzIDU2LjEzNiwxMDQuNzMgTDU2LjA2MywxMDMgTDE1LjI2LDcxLjMxMiBMMTMuOTI1LDcxLjk0NyBDNS4wNzcsODkuNjQ0IDAsMTA5LjUxNyAwLDEzMC41NSBDMCwxNTEuNTgzIDUuMDc3LDE3MS40NTUgMTMuOTI1LDE4OS4xNTIgTDU2LjI4MSwxNTYuMzciIGZpbGw9IiNGQkJDMDUiPjwvcGF0aD4NCgkJPHBhdGggZD0iTTEzMC41NSw1MC40NzkgQzE1NS4wNjQsNTAuNDc5IDE3MS42LDYxLjA2OCAxODEuMDI5LDY5LjkxNyBMMjE3Ljg3MywzMy45NDMgQzE5NS4yNDUsMTIuOTEgMTY1Ljc5OCwwIDEzMC41NSwwIEM3OS40OSwwIDM1LjM5MywyOS4zMDEgMTMuOTI1LDcxLjk0NyBMNTYuMTM2LDEwNC43MyBDNjYuNzI2LDczLjI1MyA5Ni4wMjcsNTAuNDc5IDEzMC41NSw1MC40NzkiIGZpbGw9IiNFQjQzMzUiPjwvcGF0aD4NCgk8L2c+DQo8L3N2Zz4="

/***/ }),

/***/ "./assets/image/app/img-1.png":
/*!************************************!*\
  !*** ./assets/image/app/img-1.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAAXNSR0IArs4c6QAAAc1JREFUKBV9U89LG1EQnpkVDaIJVWtFpbVrAvEPEKHFQ3voUfxBLUElvffqxUs9CB5EeutVkW2ltJ7MvYXiof0LqiQatSIGhWiKQsruG+c9ebosi++w38z3vm/n7bxZhMjqL0+PItMgIPQDQ6/gkeAuAP4uuWubYTnaxN19nXIwsYCIzywXRVawxSp4X8p8ruk9Y04Xp5LoOOuI0BU1RHNmOKk185tKl3dJZtPB+Tsj1wF42VcwrvzT5xql4gfhhJdqUiB5BXMmTu9NvSJ0FnXCwL7PnC+7n3Z0Hl6Z/ZkBEawiYIPmFahZQqQxK5JvWIkz6v1in/eHFa/daWmS5G09lvBV8MPGcRggfA/xPcSAbZYgVT20cRzWExd/LS+Na5dj84ElFD18YuM4bKy3PLY8Au9LZbhtjkP80m7GYYNyXoT4bQJfbSiWQ9yst6arIYUN+8q5LBLmda71PvA3aTBAujwzR4ATOtb3yQo/BgBbpE4rjKlOwsZhJH4nt9xkFMBfi0+9JWPu2B5pfdCU+iJ3+Mj473noCbtMVCePuwtXZsLOspv/2Fc5Pbv3+GQw+Gf1/3lOG7XOVA4b0nv5EYBgCJAifxX/KrleIay9BjC7sMc/ISkEAAAAAElFTkSuQmCC"

/***/ }),

/***/ "./assets/image/app/img-3.png":
/*!************************************!*\
  !*** ./assets/image/app/img-3.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAhpJREFUOBGVVL9rFEEU/t7sGUwjlgYsxQQkSiTxLiFCYqIpNaiVthZiY6GlFtooIv4BElAUmyikUAi5hBP8wV3UKMQrxCJ26bRJ493tPL/ZvZudHCGLA7vz8b3vvXkz894IdhhanToKkRlYlAAZB7RJWQ0GVcRYlLHl9W43CQmtH+nBVt8dqNwkb0JbgC1EHyD6c0uGv7gFkuED6eczA2jZBWbQ3zHuOquuoxBflJHKD6dLVtWNib1o2tddQZ5zSxdgmn2w8UGonqeeXHuIDKIVvUl2QSrJSKvTjwivtyWbgL0kpZVKxyeceX6T1L7gd6DNP5RS+Ybo6qkxWPOehnSbinEZLX8Inbuxrp6e4kUsp7wqz/SkQWyuBUHm8oI4ZzlRXuH0xOHUV68abu5wSrh//CrDOUj0pVeIHDJQDHhij/nocR6IorVMogwk2PKEbfV6/H+g6TL65n1iM+RxHojj45lE1piRfM2I6EqGc5Ai0GoS6DGz+pu4CWaTq82LUZue4W2dbcsa0NackeLSBiv4rve1eJYWnWe2gcSmeOpJxW0ZffsrrezKRAG9he9cJewz1yILrLN3iBo9QKFI+zkGuOyDAHUU9x8TmY/TaqZFP032s3fmeWaDgXA3WKdxlu3x04n8U5F08b7NYT4R98lbZ9xxKF8k6D0Ufg91gjidzyh08g+bouj6iKoGnWvUVBGZRRlZ4jFsH/8Aa1OuoCtPH4MAAAAASUVORK5CYII="

/***/ }),

/***/ "./assets/image/app/img-4.png":
/*!************************************!*\
  !*** ./assets/image/app/img-4.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAkCAYAAAAU/hMoAAAAAXNSR0IArs4c6QAAA4NJREFUWAnNl01IVFEUgM+5M5POvPnRyKGiAluEEaWBy/yZKOmPwqSIimrTLoiCVu1bFgUFLSJplxnaJimSycFaZGhW9EMLqQwrRWe0N5bj3NN5Nvf5TIN0nnAvPM657913zvfuPfecdxE0bIOdgyGf9F8HwoMAeAl1Y6Tn5EuZ5iOGq86xSaEbJAOedgBaeA+0giQigYBnHBPXNuYLNGi13Mm4WQkCunKQWR/CaqPaGNBqJhmw3DGL3Rag1dcLEqBUQfISv1G6ZpBoQzJgn6aQtF6BSSD9IMeejEUZ0BGT+EoBe5XitrScTmbEKUSoA4TlQDDMPrpQUks4ZLRjJWaUT4qTNzWZvsZ9FX5fi6oDver5oqSgkY70fjbcCEAh5egvOYIE9wjgGWfGAiQ6xs8322MIzhfVGhdU33XIkQ5zLxttYQdqVpSv/5VdETNQhbvwl3rBoxQ35Pc4Bb2YaWdbwZy9SZY3CfAWV5LXrIf5smLvHw3bhczWF9YVjjkHuBqTS0T6CBsvyTmYIBDbi2v8CYfDc6Px0bIseg4LATEiWMdLnuWZ7+E/nsZIjb8ZkQNhMVuqw2xNdpg0dSVMayO40hYaN3M65ynYpB5ICW1Kz1e6BmmlEYZZo4A85Hmr9Hyla5BJ+LmKYdRGpHC04FO+cOp91yAFZMuUUZb9uAEnHP28VNcgpcDdioRj86XS3ZBzpiD+Q8ZUYvwAV4wT7LCCU4SX5Qcube2EdGdpTdCuqxbE8OPxKgR5UgHxl7u2aSybsyoO57FlUnibGDCmnM6ShO8RZZtE8VFIKieEozxGffBQxpNeW7KlZEZCnmVjHjdmQNJ9KkgZ6U5+v3IeNpxDJQM3FFcbrc6b+erq66fspILmWc78TsBu5ErASzzBS13J876PB6qK8rfvUQY87jag5cSeSeuklkyk+/nGipz3uxEZOIQxtOrvVKMm8qSi5lYQWJ+DjnJp+8Ix+BBl9mo4Fh5SY92UNuRI/EcFCuzJGZfeDK0Mbgt+c9PZQm3ZKYgPvBsdRnp1AbSYbEhe+VIbEumdrWugOCCnj5MM3KcBm41gQ/LOtE9q/FQ/SDNhWjt6OvVk4YX9GRoo4vNT8mcIbjDL1B8Ml7+BSG2gWwM2G0GEMulm7u1UdxDoIv/CS9XXQVoxuWMahBIRw7g83ddD4/RIV/6g0O2MZ3yP89CuByLAb7M8F5v2IOfIAAAAAElFTkSuQmCC"

/***/ }),

/***/ "./assets/image/app/img-5.png":
/*!************************************!*\
  !*** ./assets/image/app/img-5.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAkCAYAAAAU/hMoAAAAAXNSR0IArs4c6QAAA6NJREFUWAnNmF1IVEEUgM+Z2c0sLbJdK6nAoDAos/DVwKDo32xJoqKCiCCiUpQeetmnIDMlwcKHSHpr85cgKZJAekrQfqQffJD+0NxtNaUfN3dO5647d9dNjPSG98LlnLlz5pxvz517ZmYRbHhd9rekogjXIkERIFSh3RhrqdY5HHQ/AoLNUTYl7Ab5NeA+FwcIrD+wFaSXvAIRis3EEbTKn2MeW0EmB9ZtYsCMKGTYAXSiZEXRD1tBCiE3mFkE6Cx2e/qMtq0ggSgzDvKV1u0FCRiDROy1KSSs1WBEZD/IK/2N6VxvzDkplXqpgR1asVpGgko8A6i2AeBSvoOEqoNl08I0f9spPPVLx/TSYwd8CV7nPj39+kfc3c91/39ZcSoCjfsJoI6DpOpACXIQgVoUiKeIKglIHOUsbtQ23Hex1OW5FGtrzSJ51d+wVyE2sTudlX/13JE0ODfv7Oqdo3qg1IoVsmbAlxISso19pUT9jXFZuYVC3OaNQjc/W8A3z73JL85+m5jjLCzO2D0Sb2HpnPyO8jA7d0cDhFDR1tJ0T3tcwLKKQH0WkTzErzefwddwXxgQuwioriytsB6R9z4Jl6Vz8kqgsZn9F4zHoBtlLs/phHjTak533kwejCjb7CDZauozVCyDjJQRxJWaRxK+1vpMpWWQSUNDyxlGf4g07B59P1M4Pd4ySKkoSztl+dGLRaG49oxUyyCRaJdJgvDC1C1QJi1BvLhjRbD5ACg6zmUih+OwHfXwytAmJd4tSdtnrqsGQ/lAcx6AOql5iHfUWrdC/lGCKobvuSD0y8fFKn+KAG+BsBWEesdVbQMBHmHb8R9MEFAgV11wF0woyFP4+mvXBMjqnvtJo4tGn3DWcv86cnIDhYCeUlehUS8tuya8bgYsSQDsNFYCzlaIs5XLhySjUOsVJRFimAGPWQ1oBDEzaZzU5n/J/sjPlo1Hp4Zvi9MOejF/bLwN4COffB90bOE5W8hDjWwbe8BPvMN6iE5HTemCPQFta6U0IcsHmnJQUFfUuXKGZcb5JQWfrQw2XV9mCRJCrY85wed2ATSYTEjeiWRqSEJ6o3U7yBhk/HGSoNcOcJrBhOS6aJ7UBMZOatpwNmUEssrfwF905GuNsIQVPZtNqMTYovKDL3kM8CZ36B1M3w9Xd2ei4Wy2RXies56r5Q4NwetupRe9SrftIPmPK9pugiC0L1zsv2a2baII3ihUGyxIeEcpuTv+0G4TRvgNMiQgk+8coMEAAAAASUVORK5CYII="

/***/ }),

/***/ "./assets/image/app/img-6.png":
/*!************************************!*\
  !*** ./assets/image/app/img-6.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAiCAYAAAA6RwvCAAAAAXNSR0IArs4c6QAABINJREFUWAm1WF1oXEUU/mbuJi2pNhHtm4JIaq1NsltprT8vRR8E8QcfrYI/WPSlWPvUJI2sJtGCUBUFi0L6oiL4ooJPWn/AVrBodzeJ/ZNqH3yoqTYkGNpm7x2/c5Mzubtmk01373CTc+acM985M3Pmbw1WUHK7XYdbi22IcCebrTMG15K2O8AZh2lnMUXdBOvHZjI4+lveTNULb+ox3Nzrbnct2AGHbtrbetrQJmJAJefwYWnInFquzZKB5PLuZhfiGRrdsRzQUnoG9MuVCCMnhs25WnY1A8kNuK0E2EuD1urGlF/htJxgb/8h/Zt1GaUO2q6jbEPNNsD+wqA5Vo0n9UUDyfa7xwgtI1Ghp8MjFBwOzqPw8/tmdjHATXnX2hIiS9v7aXtvlU3EHBopDJvPq+SVjkSZe9k9ylx4LmlI0NNMxoOFIXMmKV+O79nnNliL54m3PmnL5PmAefNFUlbRY+ZELgrxCoULCenwXfEU3sKnJkw2rJvPu0x3GbuswX3ahh2L6Gdg7DVTUpkPpKvf3ZSxOEDFalVyvD4pvGo+8vUGGObcDjZ/PAEx4yLsKQ6bP0Xmex5Y7Gakq/nHkWTIwPfNCkIcMUk/JuZhxSdtcwFeFJ2UOJDsgNtM/tZYwn80OlkKOB1NLsR8l5CnFZZ5t7Er73qkriPygCoZRIQAbyBvyiprGhXMCAfog99cCUI8KJyV5Ubplnm5mPxQypu/fL3JjOQEE/Oowsa+mdCWu8EWKlapghvU18qnRZkrXym2+O4OsdVyWflNh9FdLgYYVaO0aOt5yLKdVXzmx92WS/QWFTC6c6nkhjqYp/O78u8q5rHQyQHBNSognUjwqbJ0fsE7MFhjOR3tXgCklqQJH3Osqej0Glm+l72RWVhWXpYSw0WRPDJ4pwIm1VcUoUP51KnDdd6Hw8WKQIytmCZvlxKzEIjFpOVknPWO5LjOx6PkRakw9MHc7FRsbvVnrTMoeAGwtgvgl27JAT3J1cqgjtvpAMfJ8JsrtoyHlU+LhiEeUmw6DqcCFO0feXOJQn/LZjbfle11/iTWBs2iG/e59UzMbQm8cYlBklXW0WcJBVwGL3Xucv78Seoa4QWzxWBPEoMr9Uupx4GMD5oj3OmKasD5u7GtvbKB6hqhginYisFpKY0Nm/gkjgMRBe8Fb8trjYbxjZp7/z28SD+hjRqlvHw9KZiKL74uBXhTcUXuS0+f6+KlaIjCQIW8cX8zmsE7V30Y8q6RLfNKaLBdMSVBwzL6xl83v6qsIhAR8gnwCCPfqQYxNTjDm9V7V/WcMHiBGH7PmMc7yPtwnBvq53+BiCLXz7eNxbNk/dSJnD1p9IEVcoRHqt80gr1oIKLI9bkcJ6iXbJvUk4UBzT05I1zkXF/gXixT2cGlf0OtJyf1M1GAQV5Dx5JYytcMRAxu63XXr8rgKTreTsMlbRWwmrKtY4Df8hw7VMibyWq91usC37TXdbZk8DRDWfHPEtEsDo3uNwvnmXquonUFom2W+KEmItA0p2WathPMrJ/+tfhxJT/U/AcYcX8sSV+Q4wAAAABJRU5ErkJggg=="

/***/ }),

/***/ "./assets/image/app/img-8.png":
/*!************************************!*\
  !*** ./assets/image/app/img-8.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAXCAYAAADgKtSgAAAAAXNSR0IArs4c6QAAA1BJREFUSA2dVVtPE1EQnjm7BQQ1QAsa4gXQmigJRIMXLsWSGBMToy8mPvETTIz+DuOf0PgkPqqJSRsQ0IjGG2DCpUQMUaQgFsG2u2ec2fbUthQE52HnzPfNfHt2zmURNrGl0EwrWXARAHcDkauJpn1gjVQPNMY2KdkA4waEgYWe2ZOWoqulOE0wr7R67h88PF6Kz8c2iFMLlcUDM7cRVXl+YvGYiOKk9HAgcuQtArrFvMQbxJfC090E6oKQIuBL+e5jJaKbTnVphDZAtIQzpoFWLbRG4nOp0eBUMGlw8QXiBGQtn4/dIsQqIR2kR/size9kLPa969MeZVkdhFY7IpZl0MyTSCddwNH61YohfN2wJmiB+I/Q7CnXoitC8IwSgWjTXf5kLXG+0aXJ8uX1stNALr8oMxHDc5ziT+7n2k8F4vFw7CYnVWcTn/ijTS9MUSlP4Yi9gs1tLulQXp2kknb0g5z4Ys/scVR0XRgG12ug8Q5G0ZH4X8btxKXeqRNEvl4ECmTy6YsyhYQkb/dMa/fVdoWlgFtH/khwzAK6l1HwsIAnvhyONSqEBo/gA+P/VbllO4xAsSenfK/BiL/eEyfALgOiUm/Mahtsu95V690mF7WeVInOr/Xcs2AW5O7QkEnYif95ZsKvlPqro9Swcuy1czkRovGaaNOPXLyDgVtZIWuW2SCaJkRHaaQjRkM79n/NWg4X3zmtOR3Xfi5jxY2vMKByqlbNeCdelVmdPOfs+sFs3dChealXhPDZCNGulT7Z7ybejpeLjvd3u8nV4HqzlljpdXzGjfotAe/XOjlIi+dnbshVwAvtzUa4zWw5MHeWD45PeCT4Vh89OmVyvQX4GZ4POJC8xi3ab4iMxwSi86JmIfkKx1pShRyf8aKLDrX9sHbg4AeTl1ndbLTSMxd0IBUCpQ6ZBPHyZWnQo/WJXcP5Z+B7eLpdgbosOaUuugJxSRKLh78c0JQO8ak9xmEuh2fqKLDegu0M2lRup910H/PeRcdr9zgQaXop9cZyhQbI99KuFCS7uZetZjfk82YsR91f4qLbUtwUx89O7oVK6CDinwSgt3iGE48u9dcONr/Pxzy8GNgqlp/E4hp28v+1i19is2wCwXlaGz36sVTdH9siUVL3gLdoAAAAAElFTkSuQmCC"

/***/ }),

/***/ "./assets/image/app/info1.png":
/*!************************************!*\
  !*** ./assets/image/app/info1.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/info1-09d1c932c7068fd24c788e1025ed058f.png";

/***/ }),

/***/ "./assets/image/app/info2.png":
/*!************************************!*\
  !*** ./assets/image/app/info2.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/info2-ab8e3a8dd3f6be35f48d4e4a064763b4.png";

/***/ }),

/***/ "./assets/image/app/iphone-mockup.png":
/*!********************************************!*\
  !*** ./assets/image/app/iphone-mockup.png ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/iphone-mockup-b321fceeeff71a03f0fd087048dbc84b.png";

/***/ }),

/***/ "./assets/image/app/logo.png":
/*!***********************************!*\
  !*** ./assets/image/app/logo.png ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAI8AAAAkCAYAAACwuGm+AAAN20lEQVR4nO2cC5QcRbnHf9XdM7sz+5jdTcJunhsIgYTwiOeICAQUFAgiR1EQoiLiBUThHokY8cpFUUG8SPQgCgJqSIhHQgghQBCRCIaHnITgvTEx4ZmwhLwgZN8zOzPd5amZr6F3MjM7O+vuRZz/SZ2e9FTXVnX96/v+31e1q/TXwkeiuQvYi+JLWGo9SoElRQG2hfnQ/fBEep4bjVIaO5oCS4NWYGsMrMZ6Yn9eiDVpLHnRl0Bv34a39SVU4yi8LS+g2vfg3n8nvLUL4l0o0yY68zNQ3sEofgEcBpyDVo/lb7g/HOXyhY5J3NPTSFjpUh6poAw4KPUgiv3kUTM5pwJr3gUv8zhQK9HUyf9vA6aW9KSVZm2iFlsNa//+7WFhqf3etjKWakKpZ4Bj/59fzIUa9bj2rDrtWUhpCHwuWBw0S7qb2ZyKYFOxOsMJK+Oi+heFUvdlV/4IQpuJViHgf0DdgqesjEscZIl7Nld2jiNmp96bM/YugoOVtzOjgQeAjwLPDnt3vYyFqAN9t/as2eU2Y4bySDLKLmOBlK7YnWGGhWVRoMREA504bF0w1iYSBcduVWNaVuMyG21RTtHaEMbj+u7mjMivEGf4YQX0zr7FtmpR6l40HxmOnqjGJvT2tqOprn1OV9fP1O7AmqZQqdKaxb1NPJ2sqWidEYKVCcWLFUvFUDyqU9aRui9bfUjIhP4hVF093vp1X/CeeeIRcJpIudkvy9A5pqS1xSVdLcTs5Ht9zt41sDLxbCklpP9IxD3RIzyEvmuwHFQ4rNwH77lBP7xiIcquNbe1VhnXU05R2mJhooG0pYdO7gpKhpNxT8XgueAmUeFQrPa011f1Pd9wXKor+qRNGdFMVQRSyXD6gaUr9NqnZjO6Oat7zD8vSwS8/Aq+EIyDSqO5JdFAiIpIHkkU1zymVNfC6AOAEKoqQdPlm1ZV799+gZdwBt1Nb1vb+1I/uXad9+ya2TQ1g8c7rifz2Rm0WI5oxR/SNazzhmIRKygH+fI8/Uv9WBh1IIw9DKwWrKrucMPFm293Rieu8HpCpRNny8tnp268/gl38+ZDaRizr/DV5Qlls/swNz6KqPIqBBhhFAvVpShI90JVFJqnQWQqytE0fOXF6+xxiW95vSGb4vtHlrdu7RWpX950l+5L1dC0X1bfYPUv3uD1jqUtNrrVvKZtwvs6rDHAH4GNwGvAW5n9O9hh0kHAD/6F5ulA4G/A/0nuLR/mA23Ab0eqUwML5swGpXEracCFUQdA7RGoeks1XLD5utCU7gVuR0GX0ZBetnRlcuGCH+KEoToKnipQyOqdQZaEaxNSXj6tY8ziQcAhwASg0fQHaAFOAv4beBwYNczveCB8ErgfuKJIvWpgBnA48HMZWy72ByYCBwxTP82Ow93AT4EaspZHUrOlFEMkNw61jdB4ONaYCA0XbDw3tH98kdcdqgmGOrqne1rqt4sfTT/00GxV12BhV6GKWhdbIq7BFbvwYDXv5Aq/bhIEMsIocBVgYvoPAV8appddKsxm7+nAUUXqm3H4fvlg4Gd56vg5iuHy32YBfkosX0bwOqgBohvzfW6ddBKcCESmGzFD7PyN53YuPqgpvSf2CcIhV+/efUrqzkULvS1bm9XEVvBkPFoEcp6A2vDS8+yslSsRWXYUoc87CL78OHANcAowSzaBfxyoexZwvLys54G/ACty2otIvffLit8E/FncYTAMNRbj00KMccALYu0ekdV7MXCC1D1IrM9TwJNFxuHKc38A7ith7IfIpM8Ugpm2fycu3OBqIAE8J/3yx3e2uP4ngEOBk2XxmXvfMPWdAc8t+O5rH7gQGwsN47FCTxP74qbTOu6ofzz17Nalav3vf+Ltess2GWTcwEIoQp5s1GXl/64oys7sJOTquwDzw38hE9OvZzKp8wMEXAUcHajzcWAecCXwQ7lnjpIsh32y8/8llvAO0V0RuW/c0o/k+ULkMcS/05w6AG6QozPbi4zRWIml4q59zAEuDZDJWOLvAp2yp5mSRXGrjP0YIcvB8nyzuPz7Bg7VlSqQgVbQdCC0vA8OOAM1cSaxOU/P6rvszBuTz71lWxPGo1VIoiLjkhw8VxWJnIp9V7yUgcOlICvO4JtCnB2yysxLPT+TRoLrZXKRF2eI86JYlOoA4a4FWuXzfCFOL3Cm3P9PcyQue3IgMymzRMMgFukI4JYBhuOTZgpwb5F6VRIwNEj/68Sa/gmYDiyTeleLda0HbpR7pg9GyP5S3s9ZQjCzeF4RUs4bmDzFipfMEqlxCkw9GzXzY9R9fhvp1SvoW/UCVIWgqupt8WHyv3n1jtmNKiPa8ksJ26CflZX+G2AJ8DRkDsC9Adwudc6W6zx56XF55lty3yeIeZmfkMlfI2S4VaI5AkdZLpTrXJmoNiHKciHkLGlri9R7E1gPbBtgLFH5GZ1C3isL1LtUro+J5ewGXgcuEpdl2pgm5L480OdrZaH8FbhM7v9NXLh50T3AWuAlRw+UYfbJsw/EIhn3le4GOwytp6KapxGLLqb9mvvwdh1H+OOHQqQWUqlslFXMbXlqUJongwLN5eBIKUEsFXPcJvd8yzJX3IrKEZ8+KR4SF/cx4AxgvERsNYG6hwY+L8/5uefnREtOzrWUERvyXQIsEGL8Ls8KmiXXKUJyv/0+IWCV6LDNYnl+IIHEt2VRzclpzw68bYuStidUoQlV/b/zUtDnok0e6MMXErMW0TF/A/Ff9xCefSDWuPFoKySWIrc9lQm7839XGBlrZp4ZWDPfLqLXEevTJPmftkAdf0IniyuSjtEulsq3CMalLRbh6KMv0HEvR2Pk7uMkAnprKFgsBPmyHNHdktOW34eYaBmfXK7kiwx5ugL1HxTyIOTZNVDfhua2rNyMtIbOV9Gh0QnroiXnNMztWqRUG4klf8X9+yb0nr2SSVY5xURaqqw8T9aSDYi/AyuFQHOl8tU5BPCjD5N3qZVSI5blWHFrEdEyJmf0fckZKSFbR4BwLwXaHZ/TufeLBjomUJ88JCsFxpVuEG11Rk79rXJdLuPwxxQTdzdT3I+POwLPmQjtczntBReHVyJ5Bjiy8bYhU9C3B1U7doeafu4pqNYlKsJ5sct23uyM3ZuMr3wFt21n9vCXsnOSSjaKMvVOaeQJYpFknJHV6+MZuZ6TU/9CWanfFMtVJxP9aGB1HhEgounQTtEwiND0YdzFTeIyT5J7vuJvHOxAAv3rzZPs9MP40wOWFHFjSyQlMFnufVtEtBnTZ+TezwPinwB5qkVMD9Hy+FGXsYh9e6DlqMeYcd6HqW5cjdsHcbP7oS9p+OqOi0MTOkmt3YHe9gbKZJsNgQIWpNxIK6XtQo6umBryRbBZsefJ5/niTi6RjO/lcr1NIrMNYuZfFgv0K+A7wK+BdcBuacd3ol+W61mSK/m+iNcPSnjtR1W+hThehPpnC4zFCnwOwpD+ujyTvEKOEBtSvSpRounvaiGIK+Q/SES3FqtsrNHN0sYjgVTCa7JoTP17zPsZInmEOF4vquWoe9XUT51IuO6FfkOLG3KwoOHStlOdCfGevmd34r78epY0oXDOrvrgdtSN5an2FEmVlyWeTHZPIPvq4wERiUarfFHurZJVuk2uN8h1q7iEhwKkMOGqyQx/TzLU/yHRCAE9s1y+e0W0yVXisl4U3eST7XEhVUpC4Gl5yOOKW+wSsZyLa8Q1uzJeHyeLlRktgvh7Qqa7hKxxCeOjskg2yHM/lXFPkhwWkgRdJlGeycwfo7wFrcXj3NoJUJXPoioYNSMbZY0/4SrVctS1WCFtDntl0P4q3HYspOLZmQ176Ij3wY5bpyxLbgqPc8ZFsKdMhNooJFPonjju81uKRVtv5miUDJo0tNZ67Nl3w0fJS7GEJLkEqpZH6iWE9WGJaW+VFftynpS/qTNV2t8khKkRq9ObM8GWRF+NQsxXCuQWYtKXXXn6akn7WtrPtwXhSH/SUqffa5JfnExKoNAZ+G6GjDMu5PNRI+8nJALaR1QI+KbyFk4ugzyS46mblFCHXHAeda13Y0cgFAFVgDymNMfNa6hvnz/9yXSbcxghB3tSC6p5FHr3Xty27YMmjxnJ/Y5mTjRNzKucIxxJlHYkI1ccpzvAqW5XEz5yNE2H3I2bKCVRB+b8j6c6oyftPFZFQ2u0q0i/tJ30xi2kX9ud3RwdpObp9ixOTtkc5paVaa5gCChR8wiRHAeSb6Capq9Xk0+bpptm/C+p3kH8nouGlPmdQt1FyDsBFVpNqApvbw8kvbJ+5UbJ0dWvJrIHYyu2Z+QwCMFsJF07jD3+LqZ85hRC9btIx8vraDojko1fPl171sM41WjLKetIhimuVpyTCOFYlTPMI4kSN0bNsQw0tZNvUId/Y04mj2Fc1WC3EvZFZ+a4gFYPl5UgDIT5Uc/mx13VdNiV46gjhRIsj529Rpq+xqiZ80j3ZMXyPw/GfM3R2nqq3I1RU/aguKi3iiNSTr+QoYLhQwmWx20n3XkmVvVNmVOEOl+aYchoR6uPam2tGcrvbu1Wiqu6Iu/s2VYwzOQpvu2wjWT76biJZdm/YjGsSKA5GU+te3v3fZDF04pZfSHGVEL2EYGxPF4Bq7MBpQ5Gp58c8KjqPw8doD6Attbm0Ta6FP1T59nM64rSblW0z3DDkOdHQqAuKXEstVJ2fXsp8DdYhhHmD66cqLVaqrXq1lp1aa08rdXNpUReJof/lc4o9UZIv0cm6V0J4B9PaJYXuERy2QAAAABJRU5ErkJggg=="

/***/ }),

/***/ "./assets/image/app/mail.svg":
/*!***********************************!*\
  !*** ./assets/image/app/mail.svg ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgMzEuMDEyIDMxLjAxMiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzEuMDEyIDMxLjAxMjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGZpbGw9IiMwZjIxMzciIGQ9Ik0yNS4xMDksMjEuNTFjLTAuMTIzLDAtMC4yNDYtMC4wNDUtMC4zNDItMC4xMzZsLTUuNzU0LTUuMzk4Yy0wLjIwMS0wLjE4OC0wLjIxMS0wLjUwNS0wLjAyMi0wLjcwNg0KCQkJYzAuMTg5LTAuMjAzLDAuNTA0LTAuMjEyLDAuNzA3LTAuMDIybDUuNzU0LDUuMzk4YzAuMjAxLDAuMTg4LDAuMjExLDAuNTA1LDAuMDIyLDAuNzA2QzI1LjM3NSwyMS40NTcsMjUuMjQzLDIxLjUxLDI1LjEwOSwyMS41MXoNCgkJCSIvPg0KCQk8cGF0aCBmaWxsPSIjMGYyMTM3IiBkPSJNNS45MDIsMjEuNTFjLTAuMTMzLDAtMC4yNjYtMC4wNTMtMC4zNjUtMC4xNThjLTAuMTg5LTAuMjAxLTAuMTc5LTAuNTE4LDAuMDIyLTAuNzA2bDUuNzU2LTUuMzk4DQoJCQljMC4yMDItMC4xODgsMC41MTktMC4xOCwwLjcwNywwLjAyMmMwLjE4OSwwLjIwMSwwLjE3OSwwLjUxOC0wLjAyMiwwLjcwNmwtNS43NTYsNS4zOThDNi4xNDgsMjEuNDY1LDYuMDI1LDIxLjUxLDUuOTAyLDIxLjUxeiIvPg0KCTwvZz4NCgk8cGF0aCBmaWxsPSIjMGYyMTM3IiAgZD0iTTI4LjUxMiwyNi41MjlIMi41Yy0xLjM3OCwwLTIuNS0xLjEyMS0yLjUtMi41VjYuOTgyYzAtMS4zNzksMS4xMjItMi41LDIuNS0yLjVoMjYuMDEyYzEuMzc4LDAsMi41LDEuMTIxLDIuNSwyLjV2MTcuMDQ3DQoJCUMzMS4wMTIsMjUuNDA4LDI5Ljg5LDI2LjUyOSwyOC41MTIsMjYuNTI5eiBNMi41LDUuNDgyYy0wLjgyNywwLTEuNSwwLjY3My0xLjUsMS41djE3LjA0N2MwLDAuODI3LDAuNjczLDEuNSwxLjUsMS41aDI2LjAxMg0KCQljMC44MjcsMCwxLjUtMC42NzMsMS41LTEuNVY2Ljk4MmMwLTAuODI3LTAuNjczLTEuNS0xLjUtMS41SDIuNXoiLz4NCgk8cGF0aCBmaWxsPSIjMGYyMTM3IiAgZD0iTTE1LjUwNiwxOC4wMThjLTAuNjY1LDAtMS4zMy0wLjIyMS0xLjgzNi0wLjY2MkwwLjgzLDYuMTU1QzAuNjIyLDUuOTc0LDAuNiw1LjY1OCwwLjc4MSw1LjQ0OQ0KCQljMC4xODMtMC4yMDgsMC40OTgtMC4yMjcsMC43MDYtMC4wNDhsMTIuODQsMTEuMmMwLjYzOSwwLjU1NywxLjcxOSwwLjU1NywyLjM1NywwTDI5LjUwOCw1LjQxOQ0KCQljMC4yMDctMC4xODEsMC41MjItMC4xNjEsMC43MDYsMC4wNDhjMC4xODEsMC4yMDksMC4xNiwwLjUyNC0wLjA0OCwwLjcwNkwxNy4zNDIsMTcuMzU1DQoJCUMxNi44MzUsMTcuNzk3LDE2LjE3MSwxOC4wMTgsMTUuNTA2LDE4LjAxOHoiLz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjwvc3ZnPg0K"

/***/ }),

/***/ "./assets/image/app/mailchimp.svg":
/*!****************************************!*\
  !*** ./assets/image/app/mailchimp.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/mailchimp-bc260ae9c7737c46b74bd4fbfb191ad7.svg";

/***/ }),

/***/ "./assets/image/app/mobile.png":
/*!*************************************!*\
  !*** ./assets/image/app/mobile.png ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/mobile-84957fa30ad8d80ca18f9a46cf37a3c6.png";

/***/ }),

/***/ "./assets/image/app/mockup.png":
/*!*************************************!*\
  !*** ./assets/image/app/mockup.png ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/mockup-f27c3d1014383a12be9de89ae582eefa.png";

/***/ }),

/***/ "./assets/image/app/partner-bg.png":
/*!*****************************************!*\
  !*** ./assets/image/app/partner-bg.png ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/partner-bg-052c60c71b9b20a8c1ac801b55d02692.png";

/***/ }),

/***/ "./assets/image/app/pattern.png":
/*!**************************************!*\
  !*** ./assets/image/app/pattern.png ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABOCAYAAACDtFBaAAAAw0lEQVR4nO3asY0CURBEwf7oYgCD/EPDOIJgMUC4jU5zYoWqAhjNPv31JgEAAAAAAHZhTQzZtu2c5JjkmuQyMfMPXjustcZ2OAzNOT1nHYfm7WaHqUC/SW55vKBP+Zcdpn6xiTFj1hr5rCRzL+hrCVQIVAhUCFQIVAhUCFQIVAhUCFQIVAhUCFQIVAhUCFQIVAhUCFQIVAhUCFQIVAhUCFQIVAhUCFQIVAhUCFQIVPwMzdnVEefkDo44C0ecAAAAAMD77oxYGlHmfHMuAAAAAElFTkSuQmCC"

/***/ }),

/***/ "./assets/image/app/slide-1.png":
/*!**************************************!*\
  !*** ./assets/image/app/slide-1.png ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/slide-1-11eb3993dc428f7bd905480528f9b766.png";

/***/ }),

/***/ "./assets/image/app/slide-2.png":
/*!**************************************!*\
  !*** ./assets/image/app/slide-2.png ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/slide-2-7de142d35b73c74a176c6a1527ea1a4d.png";

/***/ }),

/***/ "./assets/image/app/slide-3.png":
/*!**************************************!*\
  !*** ./assets/image/app/slide-3.png ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/slide-3-ba0e1629dbe6f663f0b778f5bcc2543d.png";

/***/ }),

/***/ "./assets/image/app/slide-4.png":
/*!**************************************!*\
  !*** ./assets/image/app/slide-4.png ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/slide-4-7ae2e951576476835ce0e8a0adccad50.png";

/***/ }),

/***/ "./assets/image/app/slide-5.png":
/*!**************************************!*\
  !*** ./assets/image/app/slide-5.png ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/slide-5-b46d89a616ee768c6e0f39f57640fc11.png";

/***/ }),

/***/ "./assets/image/app/substract-hover.png":
/*!**********************************************!*\
  !*** ./assets/image/app/substract-hover.png ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeAgMAAABGXkYxAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACVBMVEUAAAAadOcAAABm1PezAAAAAnRSTlMAtyOW6xcAAAABYktHRACIBR1IAAAACXBIWXMAAA3XAAAN1wFCKJt4AAAAB3RJTUUH4wEJDSstJxuX+QAAABNJREFUGNNjYBhQEAoBAQjGgAIAyTkFR/LaIPkAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMDEtMDlUMTI6NDM6NDUrMDE6MDAW+EkNAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTAxLTA5VDEyOjQzOjQ1KzAxOjAwZ6XxsQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAAASUVORK5CYII="

/***/ }),

/***/ "./assets/image/app/substract.png":
/*!****************************************!*\
  !*** ./assets/image/app/substract.png ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeAAAAHgCAQAAADX3XYeAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QAAKqNIzIAAAAJcEhZcwAADdcAAA3XAUIom3gAAAAHdElNRQfjAQkNFyOzUMMBAAACGElEQVR42u3csRGAMBADwTcF038GPZjAc8NuBUou1QwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAF+tuU9PAHateU5PAHZdpwcA+wQMYQKGMAFDmIAhTMAQJmAIEzCECRjCBAxhAoYwAUOYgCFMwBAmYAgTMIQJGMIEDGEChjABQ5iAIcytLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8GsvZ4ECCdeosigAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMDEtMDlUMTI6MjM6MzUrMDE6MDD0iIpXAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTAxLTA5VDEyOjIzOjM1KzAxOjAwhdUy6wAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAAASUVORK5CYII="

/***/ }),

/***/ "./assets/image/app/testi.jpg":
/*!************************************!*\
  !*** ./assets/image/app/testi.jpg ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4gKgSUNDX1BST0ZJTEUAAQEAAAKQbGNtcwQwAABtbnRyUkdCIFhZWiAH3gAEAAQABQA1ACZhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtkZXNjAAABCAAAADhjcHJ0AAABQAAAAE53dHB0AAABkAAAABRjaGFkAAABpAAAACxyWFlaAAAB0AAAABRiWFlaAAAB5AAAABRnWFlaAAAB+AAAABRyVFJDAAACDAAAACBnVFJDAAACLAAAACBiVFJDAAACTAAAACBjaHJtAAACbAAAACRtbHVjAAAAAAAAAAEAAAAMZW5VUwAAABwAAAAcAHMAUgBHAEIAIABiAHUAaQBsAHQALQBpAG4AAG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAMgAAABwATgBvACAAYwBvAHAAeQByAGkAZwBoAHQALAAgAHUAcwBlACAAZgByAGUAZQBsAHkAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1zZjMyAAAAAAABDEoAAAXj///zKgAAB5sAAP2H///7ov///aMAAAPYAADAlFhZWiAAAAAAAABvlAAAOO4AAAOQWFlaIAAAAAAAACSdAAAPgwAAtr5YWVogAAAAAAAAYqUAALeQAAAY3nBhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbcGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW2Nocm0AAAAAAAMAAAAAo9cAAFR7AABMzQAAmZoAACZmAAAPXP/bAEMABQMEBAQDBQQEBAUFBQYHDAgHBwcHDwsLCQwRDxISEQ8RERMWHBcTFBoVEREYIRgaHR0fHx8TFyIkIh4kHB4fHv/bAEMBBQUFBwYHDggIDh4UERQeHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHv/AABEIAIAAgAMBIgACEQEDEQH/xAAdAAACAwEBAQEBAAAAAAAAAAAHCAQFBgMCAAEJ/8QAPhAAAQMCBAMGAwYEBAcAAAAAAQIDBAURAAYSIRMxQQciUWFxgRSRoQgVIzJCsVLB0fBDcpLhFjRTYoKiwv/EABoBAAMBAQEBAAAAAAAAAAAAAAMEBQIBAAb/xAApEQACAgEEAAYCAgMAAAAAAAABAgADEQQSITEFEyIyQVFCYYGxcZHR/9oADAMBAAIRAxEAPwBsm46UjdCfTHziEJ3CEFQG18dUm/JJ98cpAJSBbrhwEkydmA3tqZmLzvKER15CXaUkFLbpQAQVWJsRe2Ft7PvuhmsVcVjdpLKg2j+NevYYcnOsOI/VnnHmQt5UdKNV7aRvhJ4oaZzFWklLatDjgSCLgfifTGPEbd2nAx1FtOrVvaxOcy5XXqpTkqhMvsxSVWPCTbf1PPEZ/MVZflMSFTdT8Q/hOaQCPfFNWHHX30OuoTpBsmyeQxqcs02HOeKoza1oABceUBa/gPPEBLHbAHcLucgAc5neNXs51dxtCahMdWT3mr3RbzHhi1arz9EcQZQhyJFtCkN94fPxxUZtqD0SMYcNaYkZW/dPfWP4lHmR9MZzLj7SZ6HVtofAVcqfWfLkm9vng9tQcgWcmUafD1cbreTCU/WV1x9NQdkiCI7fDQhDqUJ03BIULb3tiRSpzDw+CTOS80tClJZkDx6JVztfGIzixRoim3YwS0473nNII6eIBH1xURY8l9tqoSpTzTLl0sdAenXbHrdNU/DAQraKiwYKzQO5cebeLjbCS08s6Un9HkPEDEqDH+GIEplYCTZLqRf5+GPbAm0+khMiQXVKOtFndWken6fXcYrJFRqC3llmWtsrTzIBI8fI4Su0zEekxLVeHMo3KZEzWxQpTTsxp/gTk7KbA/OfPz88DqpgF2xBtjdVGmzpOqQpxMh8gAhCbKOM+MvvyHS46pSLHdGne/hh/S4RMbsw2mAC7Q2ZTGAyimOSLnWk7b4YnsupxiZVphULBEcLPvvgBvx5KpbdM+HDaXpCUJPVW4GGndiCk5NWbBOiOEDy2tg9hOyMr7oySCoDn8seHSSLE3x6AA2545vG23LyxSA5krMwueXloqT6GmS4v4UKBv8AltffCX9ncBip5rzY3UpbbKkMOuJ4itIUri7jD0VmnIlVNTy21Ls2lOxsOZwkeXGEDtdzVEQhlSVuy20pcHP8Q2t54BrWDVFRB6ephY7HoiQolOTPmFIS6mO25pUnqrfYA+fjjcwuBGaERhCEIbACkt7D/KP5n5+dZOachxozEZQDzw1LKTuDe1vW3L1xxmPGNHSwhYVLkp0sov3WUfqWr+9/fC2hrCpuI5j6U+WgHzKKutKqlVeKVDho3KzsLeO/0xZ5cy9VpzqfuGIzZJv8TJa1C/iEnb3N8azIeUU1p9n4gOCIlIUArYuX/Ur154OFDoEGAylmM0lCAOQGJ+pv2uQk+m0WjDVg2f6gSj9mGZqvJQ5V3lPfxkbA+3T2xXdoUX7gqDlNkNlaY8dKIg06UgdeXXe+Gsp0VvRpCRt1GB9235CRmChPuwm0pmJGts+JHS+Mpc+cmds0yYKrFRptWlIqQUl8aEG4Q5sSPDzGLZypQ36slCVoQFDUkJtY35jFGiK41NUzIZU3IaWUuIULFKsQHYTqagdyixuNI6+nTDhUFZKbJO09Tb1BDjCo09lxAQjuqRqtfGgqhXUKUhcGBIkvOI1NORk6iCP0qGCV2L0TLdWywzLl0uM9NT3XysX73oeV+eN6w3DpkSdSIMdKJSmHHYQQAkH/ALb+R/fCVdRLgk4xJ66IqwYnqKzkqhVGqdpNIZqMB+MlpPxSkupsogciffDKZtoLdQyTUpD0z4OLBjl9xem99Ivb6YyeX4gOY6nXJRWhxKWon4p3b0JusX8Lk4IeZqqiLkB+ks0adUpFYjraZSygELKk2G5NrW3w4zZAzGuiYTilPU48O/lGx9cQZldpUVJU9UGbDo3dZ/8AXEA5j+ICfhKdOeSTsS1oB/1b4rM6p7jiSgpPUiZjkufeIhstuLccaCgEGx5kYVLsUp1Qd7c82xGFMsy0olpUHWuK7bigKDe4Gux5nDgxEypF334PBcKgANYJ0+eE8y0uVD+0Xm+SwpxttuZKLik7d3ictXS/jife5IZhGqACQoHM6dotMTSc0vQWKm+WmrOSCSEqSLXKTpNr+OM3l+O5mDMvAUglCygvm26UD8jI8yNz6+WO2ZZBmyZ0tLgKZEj8xN7grP0vb2xe0KBSqPEU9TXKwuoxGBImyYaCpLNxcldxYYFvYDYO5UqqU4duodstUhEOIHFJSlagLpA5C1gPbF40sBVul7YF/ZrnF6sPIYXVWZqHAeESnQ4fUXscENHHU044lO6ByO2EigJ4l2tx3NTSlAWBIucTJjAdZUhQ6YDj2c65T5rbK3aUhZP5Fvb28sbjLmZKpIZDkyPHlN23MZd1p9jzxoKCMAwVmQcwAfaCyx90ZlarkRmyHzpeFtlKGBBV3tT7b8fStJ5g8wfPzw6vaRlyLmPL0uM8yFBbRU2SN0qtcH1vhFnNcWsSYj42SspIPQjDFVmU2mTNRXh9w+YwvYDV5CKHJCGXFOa02CdwByww0LJECrx4VQny5rE5tBKVR1AaNQ3F7G+Ery7USnLtSipfeYSY+ygSCk6hYgg4tcmV7MNHqrcikV+s8NtOtwKlrUi1t7gki2NVU5JY8xawk4UdxtsxdksSblyZT4VZmtuvpWS66ErJUfGwHpgeryxnYQm3xW3nI0QhMVLZN0BGwFsZ3ss7Vc51ufWlT6k7IjU6OHW2rhIWSbAEgXxocqdq1RlVhunooeqHJUBwWSVONKJ7xT4jyxl8OcCFsobS+48nP8YOId240UICW46G0DwSBjtw2kcjY4gSJ8OK0pb0tpAHMlWw9zjK1jtOyjTwrVV2XVJ2KWbuG/8A44LrNSEfCjJ/XMm6fS22L6VmuqUhqLHU+tZQlO5JwoXa7Lg5cfq7VOaLNRrkx2Q+s/nspVvYXvYeWDHnDtGS9wjEZLbbbXGV8QN0k8jp8bWtfYX3wpueK9KzJW6nW1rN1ucJq+9kpsP/AK+uEKLnufLcAShXpjp1LMOTCZ9lCiQcz9pbjNSjtyYUOnvSuC4ApOvUhtFx5XUfUDBz7ScuswqTMg0SiMKZlIKJTaEpHFT4G/O3TqMAn7G9VRTu15+Co2MujvNJB/iQpDlvkFYYTOeZhFW48uOXtP6EjnbDd7bRkdxzRUmxsdiCjsp7PKnPznTZrtOdp1OpYAbvbvEG/qfD0wbKpHQI0pplIusqAxL7P8wGsZFRXHYjMTjFxLLSOYSlRTv5kg45PLT8OHHAbHfujASu1RzkmOJ6nbjAHHEWiv5QnVI1GC8gt1F6QFNyVH9IPLfxHUeGCVkrKtQoM2E5TpDxhCMG34zj2sKc/wCoi/5fDTcg2vscajhw58ous6FoUeoxrKJDYYYFhsOWAozkeWIa+pVbzDI8sLTTHC4LENk7+mEMzJCDdbkTG1d5ZW8SehKjYfLf3w9faBKUxluaqPbjLaU23/mV3R9TfC89ukShUbsslRY8M0yUie2lsvJAcnKQLFSBe+i25Pl54IhYHAibopTLQXZSXBkMuomsOOxu4qQ22dKlJBBIHgcbSKctR6PUjSoE5hTjKg2h2QlVrjbzxhuzRcZ+txos14MxpDgQ8sC5QkmxNvIb4b/Kf2fsiQVqekqnVLilJIXKCUbcu6kA/XFPS2hVcEycCiXVO/QIz/gGCn7LeV2K1UK9FqTKhDfbTxE6ihSgk7Dbpe+GBiZJodI0GixGILrZ7rjTfft1Grmb41FByzQKAwpukUqLDQRZXDRur1PM45yqzTYylqDMh0p7qghu9sCSsqMTXierq1N5esEL+++Tk/3EvrtYqs1Wp6S84pR/K8oqJ+ZxW0ZwrrkRuWFlkOcRxP6VBO9ve1sZKs5lnynU8RfDCV7BCdwcWeQ6FmGoZigyolNqsxlDpU458OtSALG91chzwdnHkk4wcGLjUs1gGeMzY5lzBHnMymIoUqQptSXdrAuG4HsNvpgVRY7iGnmnwQllziPC3XmE+6rf6TgxN9n1fguqrGYGYVMbDR4yVvDWs32OlN7HkfXA6z4UR3FBphceLfUNYsp5VtjboOov4+mJdR2nGI25LrnM59imYY2XO2nL9XnL4cUSOBIWTYIS8kt3PkNQPoMMn2nTnqXXUx5RDEBzUHXw0XCi29yBva19wDhNq0wApwBV7m5t1Nhhnfs/5vb7QqJBp1Uka8x5eCdes3MyL+UOeZAOlXseuD2gkDE1pLhXYQfmEWgKhx8pNuUSqs1GM4dTZju60KN97W5b3v8AXFrTpVSlNEuOqbBGnh2vb02xR1uHl3Lch1hulFESW8qS8hlZbHEIAKkEflJsNQ5E74/csSac4ylMFqpvO6UhRcmWSTfvbjfljDe7Es10ua94BI7zxj+5wabkUKvEuKWqFIVso/oWehPnjex5Z4CUBJtgb17LtWnPOuSa/Oc4xCBFbXaO0jYHY3Kj5k+mN9AKIlOQhxRVoQBcm5NhjAwCcQVrkgZMGn2rMxKovZv8My+WplQeDLelViAN1Eeg/fCcSXpk0PzJsuRJWEaQt50rNuXMn6YLX2qczuVzPKaehZ4FPRwkJB2Cj+b3/pgTTkluEGEkDvd7ztjaccyXqDlsZ6l1k91xuzyQVqQNdvax/bH9Aexqvf8AEXZzRqrclxccNuXNzqR3SfoDhA8kOsR3LvEElpaUpJ5q08ve+HE+znmag5d7L6XAqiH2nHEFy/CUq/eIJ2HKwG/88HrOG5ilo3Jx8Q3NOkEi+M/m6kyaq4y5HnmNp7q027qh6DriXTcxZUqySun1dh0tjUpCVHUkeaTvjxDr9LlVRUSNd0oTc8VJR16X54OTgwNdL2qSoyB3MxlvssyTQH1u0zKdMS7cFL8oGS6NvFVwMad6mrdjqZdfdDRBHDbAbSPYYtVrQk3B+WObjxVshSgT0Cb3wMsDMBSOYKu1OHT6VBZdcQHJbqzww4LpbAG6rePgThX+1OKmZNTPWpalafxB4WVdI9bHDA9uFQU7npumOvdyPE1rQbAlRSpQGAbUYbkuA8l5V3SeIq5vuo7fX6DCFtgUqRwDKWmXehzzBTOA+JWCNkoJI8D0xN7Ncxy8nZ/peY4eomG6kutp/wAVlWziPdJPvbEWaw58aW7HiOr4YH7n2xzpzCTV12F20lSL+3+2GN4AgSmWj0Vt+j5ggxqpAlh6JKbS9HebNwpCht/uOhvj3l6AlpISlwFPoBhTeyrNdUoNYcpKZzogOOEpYUdSArqQDyv1thjqNXVSI7XCkgXAKk8iP9sAJy0p124qxiblxtpC9LQ4i/LpjPZ5rjeX6HIlvLGtCDpHnbkMSXK1HhQi448hNkk2vha+3bPr1WeVEiuWbTcbHYDHDjOBM7u2PUFWYKg5Vq+7MdUVKekEk8yd8eqlH0x1k2uFKSN+v93xFo7XFntEJKksDWq36j0HuSBidWnOGhuKVal2usj+Le/1NvbDPAAk/JYkmfQ4ym5CVabBsgja19rYN+RM7zqA0xSpTelplP4V1WLZJ1XB/Te+/TxHPAqp7iUvBx8a0tqGkHfXpF7ed8S5FYflyhIUE2V31ggWKjfY28DYeGBvV5/A4hVtFHfMbLKnabAqS3UMw2qbVEtFA4zSdLpt3QpadwCepxzjdqjcPMESkZ4yk/TZT6gGZTFnYq77BQWenzwtWX51auniSIqI3eAaW2ToSNyQoEFPz9sF3sVZamVeTl/Nc342gTG1FtqQ/s07cFKkKNii4vy8t8Gq86s7bPUPuAtFT+qo7TGpbiM6bdxVttjjqlthoAhKR4Yy78qe3UH3GHHQpxsalaQU3HIaem3XEmlrqcyUhBeWUJF3VuIAsegSOv0wXBH4xNbqXO0WDP8AP/ItPbFPcR221F+SlZbTZKtt9KEhNx05E4oa4z93QpTzik2UkKbQB+Y7Wt5f1xJzTXU1LN8h18NlUp9a2SW9Su8opAHqbYzNTekSkuvj4iQ+ptRSlZue7vYC3r8vLEnXeZvVCOh39yv4fsClge4PKk2GqiFKTZ9LJPkL7H9zjmUtRJDbhI0ylWCf4VA/y/nj8nSHlS2ZDjSi8ACtA5kXsoe2Ismyoy4yiSpDg0qAva42PqbYKuSOZxyFPEkT4zkeah1olJI1JPmOv0wSMsZnkKpDTygC4E2VbofLGTkxC9Q4z5SC43ZDgvueQviyo0NTUJStWhJ6eYwBnO3mOUV5Jx1LPMNfqsziJBd0CwI1dOm3hgY11EiVL3SUjn3uuNPWZc1l5SGJfDKUjZXTFG8pLKg89JLryj3U7i/uf5DBavsQd7fiZzhNNU6CVLukncqt3ifEf3tiucbXLqJKUkJJCUDwHL+uLOLT5MuelclClkHZASSkDwxY8GHTpOvVxXEkqFtyB0G3Xzw3jC/ZiPZ+hODg4Snkm12m+h/UbDfHSiJR9yvahfSpagLePTHMrUpguurB+IcK1W6AC38/Llj3SwpmhP3RdwOkEeWG612qBFbG3MTJVOqDjLSUMp1na+vclOw3/bGsg1R9iSFNLIQoJXfVukcv7t5YH1OI+NSFKIIJ58ji9cqKoscBJHGWNCU2vgwgjP6LIkqUnRGiuugfrc7oPz3Pyx0SxJVu46hoHmGU2J9ziZihzzmukZOoa6vWHFpZSdKUNjUtaudgMCAJ4EwQOzElzow2iuPI1KvAXc6VWJ7/APUYp6u7UnHm59JqMfhsL1OJSDdDit7E+f8AX2+zjmJNTzxmCpMxyxEktOPsoJuUoUoFKSRzNzjH5QU4t2a+pR7ye9vsd8F1FIuIE9p7mpBMm5mqd0l2Y2wt9ZspTeyAo87f0xmplXdDjJSGmo7K/wAqAO94knqbcvDE7OAAdQysW0NhSjb9SuX0xRUiNHlVKIxIdPBAWpSQN1KTufpbCbaVK2wIwdVY4yYQviw9lQoaBQqzbiQeaQSrb2sPnjWU+EtNKbEgL5BSk3sSbXtjOZUifekZmUdJYKhZsdEpOw/bBXp0Bt+IkOIB2xLvABIl7SBguT9QO5llTlPqR936UIBspSgvb16YyWhTMt2bLcb4zP8Ay7SUd1JB/MfTpg3Zso7TEOVIsNLLal7DwF7YAFSedfGgH8VxYCUAbm5w34eFKliOpO8SypCgyRS6w80lSH1rdZWoqO/eTbc28t+WLhIEh1K0PtjUn/EVpIFuRxT0+GH5XASELQlSWdQOxVe6j6dMTaiEqnpFgdr8uuKSjjJk3JkmqOgD8JWpCEaUkbXtzPzJxPpb6XaEUOEqIFkK8R0B/bFPUTdhKBz6YsacjTSiLWITuPHGwMmcJIkGACZOtNwoGxxPZUFyDNfJKBu0LHdI52HnzvisSShDiwSStWhPTdW2JNRlIiU5tvm4lOgWPMnHQJ4n4n//2Q=="

/***/ }),

/***/ "./assets/image/hosting/author-1.jpg":
/*!*******************************************!*\
  !*** ./assets/image/hosting/author-1.jpg ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4QlQaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzEzOCA3OS4xNTk4MjQsIDIwMTYvMDkvMTQtMDE6MDk6MDEgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiLz4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSJ3Ij8+/+0ALFBob3Rvc2hvcCAzLjAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/bAIQAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQICAgICAgICAgICAwMDAwMDAwMDAwEBAQEBAQECAQECAgIBAgIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMD/90ABAAI/+4ADkFkb2JlAGTAAAAAAf/AABEIADsAOwMAEQABEQECEQH/xACdAAABBAMBAQAAAAAAAAAAAAAIAwYJCgAEBwUBAQABBQEBAQAAAAAAAAAAAAAHAAEEBQYDAggQAAEFAAEDAwMCAwcFAAAAAAMBAgQFBgcACBESEyEJFCIVMRZBURcjMnGBkcFDUmGh0REAAgECBQIEAwUIAwAAAAAAAQIDBBEABRIhMQZBEyJRYRRxgQcjMkKhFSRSkbHB0fBicuH/2gAMAwAAARECEQA/AL/HSwsZ0sLGdLCwH/dt3o8U9oeZhXG5kLYW9qaMKBQw51bFPHjS5gq4NzbPmygljVK2EgYGe0M5zne1gxr+bmQavMKejssh+9PC9/n7D+/6XOUZHWZuzGEaYE/E54B9B6m2/YAcni8UdR9XzXcgcog4vymj4xy3KtMC6nQ+Mb/JXZ87zHWjdJOGPlNZI0kK1rNXT18F73QR+82X5d4Vq+GpSTZ9PH5gq+H6jf6HfbGuXoqltvJJfuNtQ97W3B9e3fBFdtn1me3zlbnQXbHzBIruC+aLcUJuIrNhMn56q39wVHNs8rnS6uupvutPTmRrCR4ppoyOf4aT1IiOn0WcR1FhMAhNrEG6knge3pvsfW+2KPNelamhTxqYmWMAki1mAHJt+YW3NtwN7W3xMl1dYymPnhP6J/t0sLH/0L/HSwsZ0sLGdLCxXM7k+3/kXv8AdJzPS7rjbH3PCR9fZU3G1htbB5bjbWeHvZNbF1NVBqkipicPlrCOgoEuROfPtJbHuZGYFrjOGOay5jV1sk1MqEBiEJ5IU254UA7XPPp3B26bTJcqy2GGtlkWQorSqouAXAaxvu7EWNgLLtcjYGK3kD6LnKm719C3TugWtvQ3H3dZyfl4e1425JpraSd0m0umJB0MrByWOmRwuhywLFkF9K++v5eHVMFVXxzmKpRhEeQBc39h8+CTbGtqY8jkphPSOrSgbFiALc7t+IbfiAF+2O0d1n09O8yD23aCBsbSFyRQ0BKyxrtBYuz1xpo+iioraHdQcVQxITKPa1VmQQg2lXOjS1Vr58tWkanqmwR5hTP4k8TLl7G19Sk78XUcX/Tv2xSNU5BXXipKhTmQXVp0OF8ttQV2G9gfTcbC9jiwF9KLnzkLuF7H+INNzFbNveaMhCmcZcuXCka+RbbnDGSqnXMxEENUkXkBI8xXv/vDodDPRriKxpIy2qWspFlBuRcH1uPX3I3wEeocuOWZrJT6QsRsy240sL7ewNx9MSN9T8UuP//Rv3odf+1OnAvhYUQn/j/jpsLHham3j02cu7OVYwqcUWtlKyysCuFEiyijUMJxXMRSuUkwg2MYNHFI9yNY1z3Ii8p5oqeIyzukcQ5ZiFUXNhcnbkgYk0dJU11StLRxSTVDXsiKWYgAs1lAJ2UEnsACTsCRX4p/qxcWdvnAuU1e17Xu4DPVRq4dnIyuxkca5vmLxe3ZYQdNoOG5WkdqM9Xa+wJ9xWkkEVs4JmKNyv8AcRmSZqSgnbKgwmzJF8RwA2hVfdWZgh0huQTz6YJUWVZnnYXNUKw5W8gijfylnZPKUjBlUOym4spuO9tr9Ad9bT6ckrOStRX7BdJsqAE8234XzlUf+3bjEtPYhpr6JyDx/a/phsnKp7gyQyulSWAfM8BE8j3sR1cZpWljf4CRjIbhlZNBXkMsjMEYMPMtmvYbgEECxjyeQmeiGaRxvDYMkiyFtXDI0SK0qFG8j64wA3BIIJIGT3h9u/cbxZ/C/FPKrafYcr1Jy4PjrZwXY3lLTS6Mf61aZzGUOiWMHYaQNZDcQ1bVFlWIQI56i9vy9O8qy5hl8vwCyMLgMlgXW25/CWBBt2Nx6W3xW+F+w84hTODCsmk6ZAWETahYX1Kji17+ZdJ/iFiMEV2C08qi4A96bnpuXn3nIvI1tOorOlJnrGBJHojU7mTak0eLIiySMqWvehGI5Vd5+UVOtLkkckVAolUrIWYkEWIN7cfTGN6mnjqM1Z4WV4hGgDA3BGkG4IuDzg1fef8A0b/7/wDvVvjOlwMf/9K/Y1qeEXpybbDDc4U6bD4Y3Jtaa3453NdFNBjTZGVu/wBOl2ddFtoMG0DAMessJNbNa+LMZX2AhmRj08Ko0/b90r81p/issnp7qC8TAEgMAbbHSbg2Nj9MX3S1d+zeo6GuIkZI6mMsqO0bumoB0DqQy60JW4PB9MRD8+VPEtXQ4DI3WwzWh19xArM/mcbrsdP5I5Qk1kQzb6ylzrOHoaMmn4048+8LYFBo1NVwYEVoBKQijGQcdRZlk7SxmpWOTNm0poQyLK4FvM3h7FIxd2L7ACy3JAJ06AyPqJKapegeamyFdUnit4Jpo3OrTGqTKzCeU2iTwBr1Nrk0opIZXPvB/ZfneG+3kFbs8OfKccZPV1rYM2bR2Or5Z4y5FvqG82/I5hPqruRZPoOQvs9JOWdAk1YklzByWAc5phTc+znIY8oiM06GJShUxlfEAXYyohuAqhrup3CE3N1sYvSHTHWsvUlUYaWQTSB1l8ZXaAO24ppZAVu8ukrHIhOqVVZQVckb8j6fvbPMpcX97naqr4ny8m/2krPwdNcHnF5JuMHO4uwPIXHkHPSodBxTK4/x2utZILfOHBaznnjDYQYhvVzUtJl0KPXJPK9TU6dcgbQSo3Vh4ZAPYkg+ZRbcE4p89zLP56uPLZqaBaekDeDEYgyhjs8ZMwLXa5QBh90SWFmtc++ybMcrUmL1U3lBLLNMZb1mExfFbNAHUYvDZLi+EbKVF9hLs0SNoJlXybWjj3J/1Z57Fhi+kpHKnVz0UuezU1RX5+8nxMs2lYy4dFWO6q8RAB0zCzkNdhwTtiL9sL9B0D5T030NHTyU9HRGWetWJ4KiolqysrU9VGXdA+XkNTK0NkYAsBvg0/canx6mf69bTQ2AqSp7HH//0731Fq6rQRmTKm0iy4z/AD6CiIxzXeFVP6/Py1epstM8Rs6m+Icc4kF1bDhSUvz5MxU8fHhEXz/t5646B6Y66z67YSdMR6KwjGkG5Fa8bkRWEY74exzXeWq17fKKip4VF6fwlIscISlWDA7g4hf5X4GvS9zu43nG+3NhOXcBFz9urUIAGY5a4jsUnFr+MdfPLQaCyxVUYBzjgW1KFJkC0gIQgpACnE4M1OUR0XWdVNKzp4kIZGU25O3KkeSzLaxBte298fTPT/VBruhaDLJFiem+IKOZI/F8JttUnhh08QP5WcF1bSfKwK2Ij0OY5a3+g5Cy/C3ENXw7uuQKK4rtNznyZy32y9wWIp4tgR0KXorTi/LcY0nImjkxRlK8dCqUUK1IRPekDRjnpGjy/LJJXekkVDICZTeBzIL2PlEasmrffnfa5G5PztqzLsnWpzeejkgpJUWljipswgdjpJHhSGreCy2X8RYKRY2BOCC7BeMoubST201e8vthS4exey600mUE84FdWPPbTg1YwLJrctAkTSRQw60amDWrKPFC54ozVWv6Dy56itkomaQU2t7b3styQEP/ABBUE25Jt3wP/tV6i/doc4eOL43w4/KRsWNt3HLXs3fzALfkYm4rIUSkrYdTAUzIUESiChzvkGd6nvKUhzv/ACKYxiOc5fj5X4RE8Ih9pqaOlgWnhFo0Fh3x8uV+YVOZVkldVEGeVrmwAHoAAOABYAegxue41f8AqN/1VP8An56729sQyT64/9S0rnqvkCiIkcDJUMjlVXpEkvCxy+VVF9Kt9KOX/L562BzLK5xrD+X3GMstPVodNvN7YJLJ8jchQWgrLTPkvzOaiA+18rO9CfHrP7bPaRnlP8bvSnn916hzRUEoMscgVRyTsMTEarjskiXPtzjqS8hS4AxluqdkF0gqBDGbNEdwFRikMW0lD9UWAOOxi+pqOI//AC6oqqqpIvLATI3c8KPr3+mLSCnnfzSgIvpyf5dsA13EaLklJUfuW4oylBr9rxtnLmgm8Y2Mx1XD5Z42PKizrXKx7uQwg4GjqZLks6uQYTxOKwgXIjTfAx6nq5IatsyVVcxQX0kXuASSLcnY/pce5f6GhhmolymZ3jSeqPnU2KsRZTfgbi3HffbcRSbT6sGs3NVrMV2qdh3JFbz3plDTTNxybnY/GnHfHUiz8w7K9Nu2vOuon0sFSvjxa8D3DN7au9CeU6wT9cZbU0rSRQxJK5sCvmkvxsoAsDwC1rdh3Bmn6DrKaWKOarqJIYQLq9ljK8gEkkue5CDfubXBNrtmtK/sp4CLs+QrWBoeV9o6K+ZBqnNjxr3Sr7jYmTykIvmd/C1CGQp7CaRpJEoxCSDqpSjalr0jVVCymSn8kw0n2Qb3v699vzE298YLr6KkZPCqTqgFxxvI1hx73sN/wgX7EEkMZ3eWfIVDWxIF9mc9yIsURZdZovNbn7p0hz3B+0sn/hRS2sVEe0vrjI5PQrmPRVU25TnlI5EWaKQP415H/Ze4+W49DgAZjlNUl3oSDb8p/sfb359ceBadzvOVJYS6m1x0iPYQTODIGPPXcwXqTw5hAy6+JMgygGE5r2EEV43scjmr4Xrdx0GXTRiWGRWiYXBDCxH874yElbWROY5UZZAbEFTt+mP/1bNtb3G2+l0UaoqYInS7K2BWVjXOc5XlM9G/LRr5QIWo4r1T5QTHL/Lq/TIaanpi8reRVLMfYf7/ADxQNmkks4SNfMzWA9T/AL+mE9P3oUWbkaKPXzqN+apWoKdeWDpLXTHV0L3pd0jAFHEnPm2EhgIsMjvy9TBtRXI9Vwk+Ya3OgWhB2B7D19z642MVCVRdW8h5I/p8sI1XOIrmut7DQ2sqROFVQaeX7w/aDnLfSebM9WyIFGwQlqadwYznIikEUz0Xw5FVOHxFwS5ubW+V/wDGOogsQFG17/MD/wBwK/cH3dbDiup0IIeIk8jZHUx1h1EOh09RlNRx9Okx0HItK+bfBNTXdNLOJFa0rmEUv7enw5rs3n1C+ZRMIZDHMU0huQPe3+MbDpbM1yidTPGJKdZNduCSO199vn9D6Q9UHdvzBnrmbWZLgyBe6aRLIdNTyty7SWudiEkfl70mmwsVk6fLC5/qQIH+0j/xd4Reh3l32cLTzeJW1jyte/lQC5PuSbfMDbBZzj7V3royKGiSG4A8zM1gB2AC/qeMEnmIHIu7eu05z2kzSa24gtiEsZsWLn6rL0pCpJdmsHmg+1Gz0AKoiIVqe64ie81HE8EQm0NBS0EAgpUCR9/Un1JO5PufpbAazPMavMqn4ircu42F+APRRwB7D6k46hVTc5KvvtZsm2kie77ePdgIaVbyHR3tcKPcNerUmQyDGrFlhVkpXeHGEVE9Sz1sT7Yq2DDccc4OzK8h8iQM9VRajZXBascb1V76eXdza1YZSENHSJIgSGRXjaIiJ4a1qsVFa5EciokkFgLDERvDvvzj/9aYLiifNhTbaVGklHJh5XRvinV3uFjkIsOI4wnk9bmG+2kPYj0/NEevhU89aXqZ3TJpdJtdkB+RO4xnMkVTmMdx+Vj9bc4Abh60sLurjht5ZbII9nS2CCmKhxul07Nzd1pSseitOkW1rAGRr0cxXib5RU8oopUf1/zgmvsygdx/W2C84amTLDgDBWs6XJl2Ottbe+0k2QcpZFzbygqc86aR7lUhCGM53j4aiu+ETpA/dg9zfDSgCpZRwuw9hhvbtEsGSQT/ADMjgMBgY0pVPGG0YFViMjFVwE9Pn4/Hrw42xKi4HvjhBqOjzjFmUNJTU82cAjZs6uqa+LOlNInqe080MZsojXORFVFf/LrxYLfTtzj2WZ9nJIwhjTyLWUZ1nJlWCseo2JMknkNG1o1c322FI5g3NVfhyIjk/r10j3G+OE2xAHGGvr7CdFuaUMaWcA5M5ozoIrhuKz1/LXvaqEVHePn5+f59P6fPDL3+WCKp7m0r6quiw5po8dsOORo2KnhCSRtknf5cjnK4pzOe5VX5Vy9TVA0jEQqpJJAvfH//2Q=="

/***/ }),

/***/ "./assets/image/hosting/author-2.jpg":
/*!*******************************************!*\
  !*** ./assets/image/hosting/author-2.jpg ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/author-2-4a2ad16560ffa781d0f410f1bfa3bf55.jpg";

/***/ }),

/***/ "./assets/image/hosting/author-3.jpg":
/*!*******************************************!*\
  !*** ./assets/image/hosting/author-3.jpg ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4QlQaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzEzOCA3OS4xNTk4MjQsIDIwMTYvMDkvMTQtMDE6MDk6MDEgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiLz4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSJ3Ij8+/+0ALFBob3Rvc2hvcCAzLjAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/bAIQAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQICAgICAgICAgICAwMDAwMDAwMDAwEBAQEBAQECAQECAgIBAgIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMD/90ABAAH/+4ADkFkb2JlAGTAAAAAAf/AABEIADcANwMAEQABEQECEQH/xACaAAADAAMBAQAAAAAAAAAAAAAICQoFBgcCBAEAAgMBAQEBAAAAAAAAAAAABgcEBQgDAgEJEAABBAEDAgYABQMEAwAAAAABAgMEBQYHCBESIQAJExQiMRUWQVFhCjJxIySBgpGh0REAAQIEBQEHAgQGAwAAAAAAAQIDAAQFEQYSITFBUQcTIjJhcYEIFCNykcEVM0KhsdFD4fH/2gAMAwAAARECEQA/ALFm1Hnjk/FX7n6B+z4sxvFQryn2jKMda1IQk8qPPAKwkAdyVKUohKEJHcqPYDue3cdgBYqWQlsAkk7D3MQVrCLcqJAAG+sAnqNvcgs5S7hGjlbByyXEsTVSMmkqL8GZYtKLUhqjiEoYcrmHQUe6e6/VWklDZT3IFWMZNslLNM82chS90kW2B631g1puE3X099NrFsoIQfMLncjpxHLtcdRd5OXYvX43tgzOtZ1ckSIzdlOVApPyTjrjriG3IFvZT62wkWlq96nKWoyG4kJtCnZTqUpS0uFK1+ovBRbcRmuNL+kSnqJT0qCENrSba30v6iCR0wlbvNG8KsLDdLkGGbgGaijasn8s0hxNjDM1Nozx+L1ULT1MpVXkFXDipcdZmiXClygjkRhyAb6UxAW0hioj8S9yrix2/tFZNUJwKK5MnYeHn9PWChosiq8po6jJqGWZtNf10a1rJSkLaW9DlthxpTjSiS04kHhSeTwfokcEkrLzUw0HmSC0RfTUawNPtuMult+4dvrfTWMiVq7J5PBJP2eew8dI5x//0LE21J6j+5BT/wBifFoELUcqPOdveKUuN28Xl5gEPMS1qudKtFqzHsdtFUdtqna2NBa3bTxiyq3CaiA1MyNuFKQQ5CfuPcsw1vJ+aWXHEo+ahyKY5qq6XTUfbHxPED5B8X/UEODqc1PT7n3KcxZ1sNdxof8AfSE96MZjYy3Sigaaq64pVEfyWzcVBltwEpCFRoMZP+4roL7hAUy0fdSh8XHEpJQUc5OOXCf+PNf5h4S9PQ54ilKVqTlGov8APMOZ22S6CkhwqyhdadcC2pFo7Os4cObLffSgvSp0NC5NlFjoCAmPEQhIZR9lRJJvaROd473bdyrfb94qKpSw14ikhYBg5tQ8fq9RcAu8ZuHm3ccySnsae8ZMixoocjHpkd2DdMsTatbdxLYfiSVNuvIdjhSFek2S6sAFDzofRcXvtqLbQIoKg+SrcRyfRikr8Fxh7AqKW7NxTEpLcLGnyCiHXwnYzK/y3RwiB+FY3jzKWmIMPuIrQKAe3gwwm+p2XVLq2QbfpAdiuXS08maRsRcx1xLg6h0nj7+1BX6f+vBVAz3iOsf/0bCEr+ZV34HI4/n9+PrxboWErCjwYG1pK0FA3IhHHnQ5ZEpU6Kx7WeivpK3EM5y+0lPgqYhxYd9WV7lgWxwuXPY+LcNhPJdkOpJHwB8KztJU42zLS58WQqUSNjfa3MNzs0aC1zMw3YvrCUgHi3m/URPJcbo9epOQUdRjml2oekGBY6+E4887YYpLjZ9F62G40vLorkZ7Jos7JHZKn40iG+GmOhDLoT1JAVcwlpEkJpDqVrzAFsA5k35JOlgdNNztDppMkV1QMTMo+kBJUHLpyaenm2hs+rWf667N9xWh9PFha+ZXD1LxDArC7xXSaHpzDZcl5EpsWsyXd6iNQaluTSLcQHkv2DPUAAByO82TExJznclxDJ0N1A2IIvYWufT39Im1VyTn5Bx6WbLq0qKcqbAjre+nr7Q7/cvuAx7b9oXpvuczleo1Pgc3ONMcDyxvMqKNQZbiMvU20bw6BluZ0lVLl01eMBdlPOve0MiGA76zBUpQdJxNklSXkEFohIvtrbXT4MKF+VCSZZ3K3PBKlEDxAJBTzYa+IcDW4417vppNe/J8pLiKtlpGYZKmiXTyPcw5GKuyGpmPSQ8Cr1FyqmUy8pfJLjjqlH9ADPBrSgl9Z2Ssj39RCxxg+ltLUr5nFp3G3+439qR8vmo8/p/48F8CEf/Sr6bc44HH0rjnnxYrF0EbaRQIICgTteFaebttUyLcttsTe4HWv3Ge6Pzhkox+GnmXk2Aty4lvltZGT1JU/Jq01aZzTKeVOhLiQCrjwF4ypKqtTS62pQmWspAABCgDre+o06Qb4Iq7dIqyG1KHcOKNyTYgkaWGx101iYHMdxiXrfSh/KhXxqPGbCsvm6GXbV1Q9ldTWXMYPvQXJiQJVXRlKVyWUFCgVJKlJH2ikBbodV3SUOJsFAEnQKuDr1IjXiJlbyZeWlVrW5MAoRZsrAJTqTkNwLbE6E6RQZvT3ZRNRdONGNwODsVKtNKe5qqLUTFcgscMmyssr5ZqG6bIMLrWpf5lauWWlOuy6lsSlGG2h0pBSVG3qs21UmmppDXdrSEpVa9rja1+CP7+8QKBRJjDVQfo1U8anApxKyhSCOCLKJCrHXMLW24uS+8y6Dhetuy7Qzba8rJFZFuZ1a0v070moMXpZFo/Z51jdXP1D9xfvMx3YmM4Ri9BRyrK1tpnRDitR2wpQU62lRm4Jicp7EtT2wpZtmubbW26nxAkD/ANk+tUlSa3PTFbXmVkUEG3C9r20A/DIB/ci5h4HhzGnuC4XgkWV+IIxDF6HHnrEIKPxOVT1MKrk2BSr5p92qGFAKPV08c9/pp0WTVTqamWXq+tAK/RXIHX5jPtcmU1GqKmEaMIcOQb3Txvt8RvMccLQOCAkK7n+e/8eLKK+P/TrvQs/ZP2ST2/n/54stxA8ekZOLIU26282oBxs9SSQCn4/aVJUOlaVpHBSeQQe/bx5ycJA10N9dDofm2x4jyRay0hRUk5hY63Go/85iUzzJdh7+iG4TAs40heTi+Bag5RcZlpVZy4SZlNgOpE0E6laOrkOK9BqpyKvcFtVx3SpDsFx5kpX7bgJXFVBdotWW9Tmr094WspRvm8xNz/AIjVXZXimTxDJIplcb711sDPlu2oN3yjIUEFCr7qG40hv+mG3yFrhpzovk24yLX59n+FvRbfB4z1VXxqyglV8dESKjTvBaxpiloW3oqQm1ti2Zlg2S068lnho07riqjLJlFpQ2pB0Sk6qG5JI6GCurT8jSqm41RmHGacBYqcUp1ZPB7xwlVgNLC3WGTsYxGrzjM+fXQVXNBT3FfRTQyDKoIeRCExk0OtkdfDCLxmtjNSFNpSpxhoNc+nyCzcEpljIPqKCJpgpy3JNr7kjm/EZ07SFPuVNhIXmlXQSq2hNuL72F9vWPtLXHPHHHJ4HSBx3/f9ePB6q+Y33hYpSlaQvrHkNhJBI4H+f48fI9d2mP/Uqgz7V7TTSxiM9qFnVBinvG1vQ4U+SuRczWknn1IdHXtS7V1pSe6XC0G1foonsPtQrlDo3jqTpSUi9uDbiIlOodWrBCadKPWJtmJ0F+T6DmJ7fNE/qM8I2d2UHRvarpbF1k1yu8ZbyG1zHVZNtj+mmllfZyHmsdku4dVus5BqBdXEaI9KRFenVUWMwWlver6hbFnh1bOIkicklEyYcSSb2AFxpyfEL6WsbWJG8cK5T5mhPGXmiW5nulaDcnLuOAR+/MKnv98G6vfxopo3qFuG1Dj3q7SfdZlAwzCaGBgWDYHYTLiZTRBieP1HW+1MqqiC02mZNlzJiw46r1B6hT4QHaNWJqbr8zTgpQkpdzwi5tfLY252vueY0T2b0SVp1FlqhLLJqLyPGv8ArKM1xmItfW3A1iiTyq8jyfE4LNDf2uQ5BJsAzKl299Kn28xcVaE+0iKsJy3n24oA+LKVJbT99PPhe4emVNVa5Uc3vDLxUhM1SAuwKgLE8k9TB+eYxvMxrZVtgzvWxyNVXWoEJ+vxbSXC7Rx72eX6jZE8lqoqrRER1mcaGthtSJ9gppbam48YgKBUOdGdmlKqGKMZylHp5UWnSfuEjYpB8JV1yjbpGZu0F1ml4UmqnNhOZgXaUb3CiNUp9VHe+mUE7gAir5ZXmhQ/MLj6t09xpLF0kzHRdnFXb52pyqTk2LZGMnkz4QNUixroVzUOQ5FeVFD630Lbc+KwRwXf2mYVpXZ7NSy/4i263PTBYSle6VDn83UwksD1ar4zS+pmnOJLUsCQny5+SnpDWeUqUnpUlaSCQUnqSf8ACh2PgGYclpi/2ay4BveCV9qZl7CdQG1ekf/VIvGru8zubb53qBPm3mV5bcvy7m0muokS3H5MrqRGbWlxTcavgoWGY0ds+jHZQlCRwO+VqzOz9QedqM+bulBAF9NdI1fQZCRlJRFIkbpb2PzET277JrzW7dJuE1JRELEa51JyuHTx1Psp9pjmKIZxeihoQt4KbDcSsbV0kAAqUeOT43TgXDrNNw5T6MkjK20Hr+q0i4PXUmMY43rS53EczPPg5XVlq35TofS6QmLFvLt0hg3OznabkUjGsYt6uTo5iPuI1hUVnqSFsGbCmiaE9AkOKnxXep3+9ZAVz+vjJPaBJAYwn2x5e+JEa2wIuXODZFaRZ1LWvx6+8PF0uxYYrBC8ZYiUYU2236UZtAQx3CgWyOogJ6uwH9oHgakmVy7wW1bvSbA+8T5qfRMoVLu/yRvvEofnIbxcy3CbhLHRapkLVpntVnXFMf8AREOTlmsORxo0TKMlsTKcTKfi4/Vtpq4IIS2E+u6gKLoV4/Qj6XsFnD2HqhjeZWFTs6stnmyWjlT7aHi0Yj+oLFLdbxDI4RlklMnJt94DtcuAqN9r6jS8d1/p+MousLtt5Vy80v2VrK0hZlNB5tbxLjeXzI6UKS8opaaSByP1IH/AD9WNS7lqgOtgFRmZ87ckJg7+munfcsVh5ZsWzIgfBUDt7RYrt3sa/UKBNYsDISpIDzCPkFNoHHcOAq4Uvp7j9vGd8IPVBcwoySsqcvJht44apyGU/dpClZ+nr7R//9k="

/***/ }),

/***/ "./assets/image/hosting/icon1.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon1.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4OC44NyA4MS40MyI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiMwZjIxMzc7fS5jbHMtMntmaWxsOiNlYjRkNGI7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5WZWN0b3IgU21hcnQgT2JqZWN0PC90aXRsZT48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xNDEuNTQsMTgzaC03N2ExLjUsMS41LDAsMCwxLTEuNS0xLjV2LTUxYTEuNSwxLjUsMCwwLDEsMS41LTEuNUgxMTNhMS41LDEuNSwwLDEsMSwwLDNINjZ2NDhoNzRWMTUzYTEuNSwxLjUsMCwwLDEsMywwdjI4LjVBMS41LDEuNSwwLDAsMSwxNDEuNTQsMTgzWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYzLjA0IC0xMjAuNTcpIi8+PHBvbHlnb24gY2xhc3M9ImNscy0yIiBwb2ludHM9IjE0Ljk3IDQ4Ljk0IDEzLjI1IDQ3LjEyIDM2Ljg2IDI0Ljg1IDQ4LjU1IDM1LjQ3IDg0LjA4IDIuNzQgODUuNzcgNC41OCA0OC41NiAzOC44NiAzNi44OSAyOC4yNSAxNC45NyA0OC45NCIvPjxwb2x5Z29uIGNsYXNzPSJjbHMtMiIgcG9pbnRzPSI4Ni42NCA3LjE0IDg4Ljg3IDAgODEuNTcgMS42NCA4Ni42NCA3LjE0Ii8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMTAzLjU0LDE5Ni41QTEuNSwxLjUsMCwwLDEsMTAyLDE5NVYxODJhMS41LDEuNSwwLDAsMSwzLDB2MTNBMS41LDEuNSwwLDAsMSwxMDMuNTQsMTk2LjVaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjMuMDQgLTEyMC41NykiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xMTgsMjAySDg5YTEuNSwxLjUsMCwwLDEsMC0zaDI5YTEuNSwxLjUsMCwxLDEsMCwzWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYzLjA0IC0xMjAuNTcpIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/hosting/icon2.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon2.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4MC4yOCA4Ni4zMyI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiMwZjIxMzc7fS5jbHMtMntmaWxsOiNlYjRkNGI7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5WZWN0b3IgU21hcnQgT2JqZWN0MTwvdGl0bGU+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNDc0Ljg2LDIwMC44OGExLjM0LDEuMzQsMCwwLDEtLjUxLS4xMWMtMTUuNTYtNi45Mi0yNy0xNy0zMy0yOS05LjEzLTE4LjI3LTYuNDEtNDYuMzMtNi4yOS00Ny41MmExLjI2LDEuMjYsMCwwLDEsLjYtLjk0LDEuMjMsMS4yMywwLDAsMSwxLjEyLS4wOSwyMy40OSwyMy40OSwwLDAsMCw4Ljg2LDEuNjJjMTIuMjcsMCwyNC41NS03LjY0LDI2Ljc0LTkuNjlhMi4xOCwyLjE4LDAsMCwxLDEuNDUtLjU2LDIuMywyLjMsMCwwLDEsMS4yNi40NGMzLjkyLDIuNzMsMTYuNzEsOS44MSwyOC43Myw5LjgxYTIzLjc2LDIzLjc2LDAsMCwwLDktMS42MiwxLjIzLDEuMjMsMCwwLDEsMS4xMi4wOSwxLjI3LDEuMjcsMCwwLDEsLjYsMWMuMTEsMS4xOCwyLjUsMjkuMDktNi4zMiw0Ny40OS05Ljc1LDIwLjM0LTI3LjE1LDI2LjkyLTMyLjg3LDI5LjA5QTEuMzIsMS4zMiwwLDAsMSw0NzQuODYsMjAwLjg4Wm0tMzcuNDUtNzQuODFjLS40Myw2LjI2LTEuNDMsMjkuMzYsNi4xNyw0NC41NCw3LjE5LDE0LjM4LDIwLjksMjMsMzEuMzIsMjcuNjcsNS45My0yLjI2LDIyLTguNzUsMzEtMjcuNjUsNy4zNC0xNS4zMSw2LjU2LTM4LjI5LDYuMTktNDQuNTVhMjcuMTYsMjcuMTYsMCwwLDEtOC4zLDEuMjJjLTEyLjQ5LDAtMjUuNjktNy4yLTMwLTEwLjE0LTMuNjMsMy4xNy0xNi4xNCwxMC4xNC0yOC4yLDEwLjE0QTI2LjYxLDI2LjYxLDAsMCwxLDQzNy40MSwxMjYuMDdaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDM0LjU4IC0xMTQuNTUpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNDc1LjE5LDE3Ni41MmEyMS4zMiwyMS4zMiwwLDEsMSwyMS4zMi0yMS4zMkEyMS4zNCwyMS4zNCwwLDAsMSw0NzUuMTksMTc2LjUyWm0wLTQwLjE0QTE4LjgyLDE4LjgyLDAsMSwwLDQ5NCwxNTUuMiwxOC44NCwxOC44NCwwLDAsMCw0NzUuMTksMTM2LjM4WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQzNC41OCAtMTE0LjU1KSIvPjxwb2x5Z29uIGNsYXNzPSJjbHMtMiIgcG9pbnRzPSIzOS4wOSA1MC41NSAyOS4xNSAzOS41MSAzMS4wMSAzNy44MyAzOC45NiA0Ni42NyA1MC40NyAzMS45NCA1Mi40NCAzMy40OCAzOS4wOSA1MC41NSIvPjwvc3ZnPg=="

/***/ }),

/***/ "./assets/image/hosting/icon3.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon3.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA3NS41IDgwLjIxIj48ZGVmcz48c3R5bGU+LmNscy0xe2ZpbGw6I2ViNGQ0Yjt9LmNscy0ye2ZpbGw6IzBmMjEzNzt9PC9zdHlsZT48L2RlZnM+PHRpdGxlPlZlY3RvciBTbWFydCBPYmplY3QyPC90aXRsZT48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik00NzMuMzksMzcxLjQ1YTQuMjEsNC4yMSwwLDAsMS0xLjI3LS4yQTcuNTcsNy41NywwLDAsMSw0NzAsMzcwbC05LjA5LTguNTZhNy43NSw3Ljc1LDAsMCwxLDAtMTEuMzVMNDYxLDM1MGE4LjYxLDguNjEsMCwwLDEsMTEuNzYsMGwuNTQuNTEuNTQtLjUxYTguNjEsOC42MSwwLDAsMSwxMS43NywwbC4xNC4xM2E3Ljc1LDcuNzUsMCwwLDEsMCwxMS4zNWwtOS4zMiw4Ljg2YTYuNTcsNi41NywwLDAsMS0xLjgxLDFBMy44LDMuOCwwLDAsMSw0NzMuMzksMzcxLjQ1Wm0tNi40OC0yMS4zMmE2LDYsMCwwLDAtNC4xNywxLjY0bC0uMTQuMTRhNS4yNSw1LjI1LDAsMCwwLDAsNy43Mmw5LDguNWE1LjM2LDUuMzYsMCwwLDAsMS4yNC43NCwxLjY1LDEuNjUsMCwwLDAsMSwwLDQuMTMsNC4xMywwLDAsMCwxLjA1LS41N2w5LjE4LTguNzNhNS4yNSw1LjI1LDAsMCwwLDAtNy43MmwtLjE0LS4xM2E2LjEsNi4xLDAsMCwwLTguMzIsMGwtMi4yNiwyLjE1LTIuMjctMi4xNEE2LDYsMCwwLDAsNDY2LjkxLDM1MC4xM1oiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MzQuNzkgLTMwNC41NCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00MzkuNTQsMzMxLjMyYTEuMjQsMS4yNCwwLDAsMS0xLTJsMTcuMzktMjQuMWExLjI1LDEuMjUsMCwwLDEsMiwxLjQ2bC0xNy4zOSwyNC4xQTEuMjQsMS4yNCwwLDAsMSw0MzkuNTQsMzMxLjMyWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQzNC43OSAtMzA0LjU0KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTUwNi4yNCwzMzEuNWExLjI1LDEuMjUsMCwwLDEtMS0uNTRMNDg4LjMyLDMwNi41YTEuMjUsMS4yNSwwLDAsMSwyLjA2LTEuNDJsMTYuODksMjQuNDZhMS4yNSwxLjI1LDAsMCwxLTEsMloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MzQuNzkgLTMwNC41NCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00NTMsMzg0Ljc2Yy0xLjE5LDAtNS4yMS0uMjItNy40Ni0zLTEuMzctMS42Ny0yLjE1LTYuNjYtMi4yOS03LjY0bC02LjQyLTMxLjUxYTEuMjUsMS4yNSwwLDAsMSwyLjQ1LS41bDYuNDMsMzEuNThjLjMzLDIuMjMsMS4wOCw1LjY1LDEuNzYsNi40OSwxLjgsMi4yLDUuNzYsMiw1LjgsMmg0MC40OXMzLjE0LDAsNC44MS0xLjk1YTEwLjE5LDEwLjE5LDAsMCwwLDEuODUtNC43Mmw1LjY3LTMxLjQ0YTEuMjUsMS4yNSwwLDEsMSwyLjQ2LjQ0TDUwMi45MiwzNzZhMTIuNjQsMTIuNjQsMCwwLDEtMi40NCw2Yy0yLjQyLDIuNzctNi41MiwyLjgtNi42OSwyLjhINDUzWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQzNC43OSAtMzA0LjU0KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTUwOSwzMzcuNzVINDM2YTEuMjUsMS4yNSwwLDEsMSwwLTIuNWg3M2ExLjI1LDEuMjUsMCwwLDEsMCwyLjVaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDM0Ljc5IC0zMDQuNTQpIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/hosting/icon4.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon4.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5My4zNyA4NS4wOSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiMwZjIxMzc7fS5jbHMtMntmaWxsOiNlYjRkNGI7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5WZWN0b3IgU21hcnQgT2JqZWN0MzwvdGl0bGU+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMjc5LjM1LDIwMmEyLjMyLDIuMzIsMCwwLDEtLjU4LS4wOGwuNTgtMi4xNC0uNjIsMi4xM2EyLjIyLDIuMjIsMCwxLDEsMS4wNy00LjNsLjEzLDBhMi4yMiwyLjIyLDAsMCwxLS41OCw0LjM2Wm0tMTAtNC4xMWEyLjI0LDIuMjQsMCwwLDEtMS4wOC0uMjlsLS4xMy0uMDhhMi4yLDIuMiwwLDEsMSwxLjIxLjM3Wm0tOC41NS02LjU1YTIuMTksMi4xOSwwLDAsMS0xLjU1LS42NWwwLDBhMi4yNiwyLjI2LDAsMCwxLDAtMy4xNSwyLjIxLDIuMjEsMCwwLDEsMy4xMSwwbC4wNi4wNmEyLjIzLDIuMjMsMCwwLDEtMS41NywzLjhabS02LjU5LTguNTRhMi4xNywyLjE3LDAsMCwxLTEuODgtMS4wOWwtLjA1LS4wOWEyLjIyLDIuMjIsMCwwLDEsMy44Ni0yLjE5LDIuMjQsMi4yNCwwLDAsMS0xLjkzLDMuMzdabS00LjEzLTEwYTIuMTgsMi4xOCwwLDAsMS0yLjExLTEuNmwwLS4wOWEyLjIyLDIuMjIsMCwxLDEsNC4yOC0xLjE1LDIuMjUsMi4yNSwwLDAsMS0xLjU0LDIuNzZBMi42MiwyLjYyLDAsMCwxLDI1MC4xMiwxNzIuODhabTc5LjY4LTIxLjQ2YTIuMjEsMi4yMSwwLDAsMS0yLjEzLTEuNjQsMi4yNCwyLjI0LDAsMCwxLDEuNTQtMi43NiwyLjE4LDIuMTgsMCwwLDEsMi43MSwxLjUybDAsLjA5YTIuMiwyLjIsMCwwLDEtMi4xNSwyLjc5Wm0tNC4xNC05Ljk0YTIuMiwyLjIsMCwwLDEtMS44OC0xbC0uMDctLjEzYTIuMjIsMi4yMiwwLDEsMSwzLjg0LTIuMjFsLTEuOTIsMS4xLDEuOTMtMS4wN2EyLjIxLDIuMjEsMCwwLDEtLjc1LDNBMi4xNywyLjE3LDAsMCwxLDMyNS42NiwxNDEuNDhaTTMxOS4xLDEzM2EyLjIxLDIuMjEsMCwwLDEtMS41NS0uNjNsLS4wOC0uMDhhMi4yMiwyLjIyLDAsMCwxLDMuMTQtMy4xM2wuMDUsMGEyLjIyLDIuMjIsMCwwLDEtMS41NiwzLjhabS04LjU0LTYuNTRhMi4yLDIuMiwwLDAsMS0xLjE1LS4zMiwyLjIyLDIuMjIsMCwwLDEtLjg0LTMsMi4yLDIuMiwwLDAsMSwzLS44NGwuMTMuMDdhMi4yMiwyLjIyLDAsMCwxLTEuMTUsNC4xMlptLTkuOTUtNC4xMWEyLDIsMCwwLDEtLjUzLS4wN2wtLjE0LDBhMi4yMiwyLjIyLDAsMCwxLDEuMTctNC4yOGwtLjU4LDIuMTQuNjItMi4xM2EyLjIyLDIuMjIsMCwwLDEtLjU0LDQuMzdaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQyLjk3IC0xMTcuNTIpIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMjQ4LjU3LDE2MS4zMWExLjI1LDEuMjUsMCwwLDEtMS4yNS0xLjI1LDQyLjU5LDQyLjU5LDAsMCwxLDQyLjU1LTQyLjU0LDEuMjUsMS4yNSwwLDAsMSwwLDIuNSw0MC4wOSw0MC4wOSwwLDAsMC00MC4wNSw0MEExLjI1LDEuMjUsMCwwLDEsMjQ4LjU3LDE2MS4zMVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yNDIuOTcgLTExNy41MikiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0yODkuODcsMjAyLjYxYTEuMjUsMS4yNSwwLDAsMSwwLTIuNSw0MC4wOSw0MC4wOSwwLDAsMCw0MC00MC4wNSwxLjI1LDEuMjUsMCwwLDEsMi41LDBBNDIuNTksNDIuNTksMCwwLDEsMjg5Ljg3LDIwMi42MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yNDIuOTcgLTExNy41MikiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0zMzUuMDksMTY1LjE0YTEuMjUsMS4yNSwwLDAsMS0xLS40OGwtMy0zLjc4LTQsMy4zM2ExLjI1LDEuMjUsMCwwLDEtMS42LTEuOTJsNS00LjE2YTEuMywxLjMsMCwwLDEsLjkzLS4yOCwxLjI2LDEuMjYsMCwwLDEsLjg1LjQ3bDMuNzcsNC43OWExLjI2LDEuMjYsMCwwLDEtMSwyWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Mi45NyAtMTE3LjUyKSIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTI0OC4yMiwxNjQuNDFoLS4wOWExLjMxLDEuMzEsMCwwLDEtLjg3LS40NGwtNC00Ljc5YTEuMjUsMS4yNSwwLDAsMSwxLjkyLTEuNjFsMy4xOCwzLjgxLDQtMy41NUExLjI1LDEuMjUsMCwxLDEsMjU0LDE1OS43bC01LDQuNEExLjI2LDEuMjYsMCwwLDEsMjQ4LjIyLDE2NC40MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yNDIuOTcgLTExNy41MikiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0yOTAsMTYyaC00Ljg5YTguMyw4LjMsMCwwLDEtOC4xMS04LjQ1VjE1MmE3Ljg2LDcuODYsMCwwLDEsOC4xMS03Ljk1SDMwMHYzSDI4NS4xNUE0Ljg3LDQuODcsMCwwLDAsMjgwLDE1MnYxLjZhNS4zMSw1LjMxLDAsMCwwLDUuMTEsNS40NUgyOTBaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQyLjk3IC0xMTcuNTIpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNMjk0LjMxLDE3N0gyNzh2LTNoMTYuMjdhNiw2LDAsMCwwLDUuNzMtNS42MnYtMS41OWMwLTIuNjQtMi41Ny00Ljc5LTUuNzMtNC43OUgyODl2LTNoNS4yN2M0Ljg5LDAsOC43MywzLjQyLDguNzMsNy43OXYxLjU5QTksOSwwLDAsMSwyOTQuMzEsMTc3WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Mi45NyAtMTE3LjUyKSIvPjxyZWN0IGNsYXNzPSJjbHMtMiIgeD0iNDQuMDciIHk9IjIyLjQ4IiB3aWR0aD0iMyIgaGVpZ2h0PSI1Ii8+PHJlY3QgY2xhc3M9ImNscy0yIiB4PSI0NC4wNyIgeT0iNTcuNDgiIHdpZHRoPSIzIiBoZWlnaHQ9IjUiLz48L3N2Zz4="

/***/ }),

/***/ "./assets/image/hosting/icon5.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon5.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5My43IDk3Ljg5Ij48ZGVmcz48c3R5bGU+LmNscy0xe2ZpbGw6IzBmMjEzNzt9LmNscy0ye2ZpbGw6I2ViNGQ0Yjt9PC9zdHlsZT48L2RlZnM+PHRpdGxlPlZlY3RvciBTbWFydCBPYmplY3Q0PC90aXRsZT48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik04NS4wOSwzNjMuNzVINzZhMy43LDMuNywwLDAsMS0zLjctMy43VjMzMmEzLjcsMy43LDAsMCwxLDMuNy0zLjdoOS4xYTMuNywzLjcsMCwwLDEsMy43LDMuN3YyOC4xQTMuNywzLjcsMCwwLDEsODUuMDksMzYzLjc1Wm0tOS4xLTMzYTEuMiwxLjIsMCwwLDAtMS4yLDEuMnYyOC4xYTEuMiwxLjIsMCwwLDAsMS4yLDEuMmg5LjFhMS4yLDEuMiwwLDAsMCwxLjItMS4yVjMzMmExLjIsMS4yLDAsMCwwLTEuMi0xLjJaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTIuOTkgLTI5My4xMSkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik05NC40MywzMzMuODZhMS4yNSwxLjI1LDAsMCwxLS41NS0yLjM3Yy4wNSwwLDQuMy0yLjEzLDUuNzgtNS4xbC40MS0uODFhMTkuNjQsMTkuNjQsMCwwLDAsMi42Ni04LjE3Yy4wOS0yLDItMy42Myw0LjM1LTMuNzJzNS4yNywxLjQzLDUuODEsNmMuNCwzLjQzLS41MSw3Ljk1LTEuNTEsMTEuNTlIMTIyYTEuMjUsMS4yNSwwLDEsMSwwLDIuNUgxMDhsLjQ5LTEuNjFjMS41NC01LjEsMi4yMS05LjQzLDEuODktMTIuMTktLjI5LTIuNDItMS41LTMuODYtMy4yNC0zLjc2LTEsMC0xLjkxLjYzLTIsMS4zM2EyMiwyMiwwLDAsMS0yLjkyLDkuMmwtLjQuNzljLTEuODcsMy43My02LjcyLDYuMTItNi45Miw2LjIyQTEuMjMsMS4yMywwLDAsMSw5NC40MywzMzMuODZaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTIuOTkgLTI5My4xMSkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0xMjIuMTEsMzQxLjloLTEuMjlhMS4yNSwxLjI1LDAsMCwxLDAtMi41aC43M2MxLjI2LDAsMS43OCwwLDIuNTktLjc0YTMuNDEsMy40MSwwLDAsMCwuMzUtMy4yOGMtLjQ4LTEuMTUtMS42MS0xLjctMy4zNy0xLjY0YTEuMjEsMS4yMSwwLDAsMS0xLjI5LTEuMiwxLjI0LDEuMjQsMCwwLDEsMS4yLTEuMjljMy43OS0uMTUsNS4yNCwxLjkxLDUuNzYsMy4xNWE1LjgzLDUuODMsMCwwLDEtLjkyLDYuMDdBNC44Niw0Ljg2LDAsMCwxLDEyMi4xMSwzNDEuOVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi45OSAtMjkzLjExKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTEyMSwzNDkuMTJsLS43NiwwYy0uMzEsMC0uNjQsMC0xLDBhMS4yNSwxLjI1LDAsMSwxLS4xMi0yLjVjLjQsMCwuOCwwLDEuMTksMCwxLjE0LDAsMS43MSwwLDIuMzEtLjU1YTIuMzUsMi4zNSwwLDAsMCwuNDktMS44OSwxLjI1LDEuMjUsMCwwLDEsMi40OC0uMzMsNC43Miw0LjcyLDAsMCwxLTEuMjEsNEE0LjQ4LDQuNDgsMCwwLDEsMTIxLDM0OS4xMloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi45OSAtMjkzLjExKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTExOS4zMiwzNTZsLS43NiwwYy0uMzIsMC0uNjQsMC0xLDBhMS4yNSwxLjI1LDAsMCwxLS4xMS0yLjVjLjQsMCwuNzksMCwxLjE4LDAsMS4xNC4wNSwxLjcyLjA1LDIuMzEtLjU1YTIuMzEsMi4zMSwwLDAsMCwuNTEtMS43NywxLjI1LDEuMjUsMCwxLDEsMi40OS0uMjIsNC42NCw0LjY0LDAsMCwxLTEuMjMsMy43NkE0LjQ4LDQuNDgsMCwwLDEsMTE5LjMyLDM1NloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi45OSAtMjkzLjExKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTExNy42OSwzNjIuMDljLS4yNywwLS41MywwLS43NywwLS43LDAtMjQuMjUsMC0yNC43OSwwaDBhMS4yMywxLjIzLDAsMCwxLS4wNi0yLjQ2Yy40NiwwLDI0Ljc0LDAsMjQuODgsMGguMWMxLjE0LjA1LDEuNzIuMDUsMi4zMS0uNTVhMS44OSwxLjg5LDAsMCwwLC41MS0xLjE5LDEuMjUsMS4yNSwwLDAsMSwyLjQ5LjI2LDQuMzgsNC4zOCwwLDAsMS0xLjIzLDIuN0E0LjQ1LDQuNDUsMCwwLDEsMTE3LjY5LDM2Mi4wOVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi45OSAtMjkzLjExKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTExNCwzMzMuNzVoLTdhMS4yNSwxLjI1LDAsMCwxLDAtMi41aDdhMS4yNSwxLjI1LDAsMSwxLDAsMi41WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUyLjk5IC0yOTMuMTEpIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNODIuMSwzNTYuNjJhMS4zNCwxLjM0LDAsMSwxLTEuMzQtMS4zM0ExLjM0LDEuMzQsMCwwLDEsODIuMSwzNTYuNjJaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTIuOTkgLTI5My4xMSkiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik05OS4xMSwzOTFIOTljLTMuMTIsMC01LjQyLTMuMTEtNy42NS01Ljg4LTEuNTctMS45NS0zLjE5LTQuMDYtNC43OC00LjYxcy00LjEyLDAtNi42Mi41N2EyNS41OSwyNS41OSwwLDAsMS01LjYzLjg5LDYuMTcsNi4xNywwLDAsMS0zLjgyLTEuMTJjLTIuNDMtMS44My0yLjYyLTUuNDYtMi44LTktLjEzLTIuNTQtLjI2LTUuMTgtMS4yNy02LjYxUzYzLjE3LDM2Myw2MC45LDM2MmMtMy4zMi0xLjM4LTYuNzQtMi44MS03LjY3LTUuODVTNTQuMzMsMzUwLDU2LjMsMzQ3YzEuMzUtMi4wNywyLjc1LTQuMiwyLjc4LTUuODNzLTEuMzMtNC0yLjY1LTYuMThjLTEuODItMy0zLjY5LTYuMTEtMi43LTlzNC40MS00LjIxLDcuNzEtNS40N2MyLjM2LS45LDQuOC0xLjgzLDUuODMtMy4yczEuMjItMy45MiwxLjQzLTYuNDFjLjI5LTMuNTUuNTktNy4yMiwzLjE0LTlhNS44MSw1LjgxLDAsMCwxLDMuNDMtMSwyMy40NiwyMy40NiwwLDAsMSw1LjgzLDEuMDljMi41Mi42OCw1LjIxLDEuMzIsNi44LjgzczMuNDYtMi41NCw1LjE1LTQuNWMyLjI1LTIuNiw0LjU4LTUuMjksNy41My01LjI5LDMuMTkuMDUsNS41LDIuOTIsNy43Myw1LjY5LDEuNTYsMiwzLjE4LDQsNC43Nyw0LjUyczQuMTIsMCw2LjYyLS42MmEyNi4yNywyNi4yNywwLDAsMSw1LjYzLS45MSw2LjE2LDYuMTYsMCwwLDEsMy44MiwxLjExYzIuNDMsMS44MywyLjYyLDUuNDUsMi44LDksLjEzLDIuNTQuMjYsNS4xNywxLjI3LDYuNnMzLjI5LDIuMzIsNS41NywzLjI3YzMuMzEsMS4zOCw2Ljc0LDIuODEsNy42Nyw1Ljg1cy0xLjExLDYuMTQtMy4wOCw5LjE0Yy0xLjM1LDIuMDctMi43NSw0LjItMi43OCw1LjgzczEuMzQsNCwyLjY1LDYuMThjMS44MiwzLDMuNyw2LjExLDIuNzEsOXMtNC40Miw0LjIxLTcuNzIsNS40N2MtMi4zNi45LTQuOCwxLjgzLTUuODMsMy4ycy0xLjIyLDMuOTItMS40Miw2LjQxYy0uMjksMy41NS0uNTksNy4yMi0zLjE1LDlhNS44MSw1LjgxLDAsMCwxLTMuNDMsMSwyMy40NiwyMy40NiwwLDAsMS01LjgzLTEuMDljLTIuNTItLjY3LTUuMjEtMS4zMi02Ljc5LS44My0xLjczLjUzLTMuNDcsMi43My01LjE2LDQuNjhDMTA0LjM4LDM4OC4xMiwxMDIuMDUsMzkxLDk5LjExLDM5MVpNODUsMzc3LjdhNy4zNiw3LjM2LDAsMCwxLDIuMzkuMzZjMi4yNy43OCw0LjEyLDMuMDgsNS45MSw1LjMxczMuNzYsNC43Myw1LjcsNC43NnYwYzIsMCwzLjc4LTIuMjUsNS42Ny00LjQzczMuOTItNC41MSw2LjMzLTUuMjVhNy4yOCw3LjI4LDAsMCwxLDIuMTYtLjMsMjQuMTQsMjQuMTQsMCwwLDEsNiwxLjExLDIyLjE2LDIyLjE2LDAsMCwwLDUuMTksMSwzLjQyLDMuNDIsMCwwLDAsMi0uNTFjMS41OS0xLjExLDEuODQtNC4xOSwyLjA4LTcuMTZzLjQ4LTUuNzksMS45Mi03LjcxLDQuMjUtMyw2Ljk0LTQsNS42Mi0yLjE0LDYuMjQtMy45NC0xLTQuMzctMi40OC02Ljg4LTMuMDUtNS0zLTcuNTEsMS42NC00LjgsMy4xOS03LjE2YzEuNjUtMi41MiwzLjM2LTUuMTIsMi43OC03cy0zLjQ3LTMuMTEtNi4yNS00LjI3Yy0yLjYtMS4wOS01LjMtMi4yMi02LjY1LTQuMTVzLTEuNTctNS0xLjcyLTcuOS0uMy02LTEuOC03LjA5YTMuNzUsMy43NSwwLDAsMC0yLjMyLS42MSwyMy44NywyMy44NywwLDAsMC01LjA2Ljg1LDI2LjE1LDI2LjE1LDAsMCwxLTUuNjIuOSw3LjI2LDcuMjYsMCwwLDEtMi4zOC0uMzZjLTIuMjgtLjc4LTQuMTMtMy4wOC01LjkxLTUuMzFzLTMuOC00LjczLTUuNzUtNC43NmgwYy0xLjg0LDAtMy43OSwyLjI1LTUuNjcsNC40M3MtMy45LDQuNTEtNi4zMSw1LjI1YTcuMjgsNy4yOCwwLDAsMS0yLjE2LjMsMjQuMjIsMjQuMjIsMCwwLDEtNi0xLjExLDIyLDIyLDAsMCwwLTUuMTgtMSwzLjQyLDMuNDIsMCwwLDAtMiwuNTFjLTEuNTksMS4xMS0xLjg0LDQuMTktMi4wOCw3LjE2cy0uNDgsNS43OS0xLjkyLDcuNzEtNC4yNSwzLTYuOTQsNC01LjYyLDIuMTQtNi4yNCwzLjk0LDEsNC4zNywyLjQ4LDYuODgsMyw1LDMsNy41MS0xLjY0LDQuOC0zLjE5LDcuMTZjLTEuNjUsMi41Mi0zLjM2LDUuMTItMi43Nyw3czMuNDYsMy4xMSw2LjI0LDQuMjdjMi42LDEuMDksNS4zLDIuMjIsNi42NSw0LjE1czEuNTcsNSwxLjcyLDcuOS4zMSw2LDEuOCw3LjA5YTMuNzcsMy43NywwLDAsMCwyLjMyLjYxLDIzLjg3LDIzLjg3LDAsMCwwLDUuMDYtLjg1QTI2LjI1LDI2LjI1LDAsMCwxLDg1LDM3Ny43WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUyLjk5IC0yOTMuMTEpIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/hosting/icon6.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon6.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA3Ni40NyA3Ny43NSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNlYjRkNGI7fS5jbHMtMntmaWxsOiMwZjIxMzc7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5WZWN0b3IgU21hcnQgT2JqZWN0NTwvdGl0bGU+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNjM3LjY1LDMzMC43OWMwLTQuMDgsMy44OC01LjM0LDcuMzMtNS4zNHM3LjM2LDEuNDUsNy4zOSw1LjU4YzAsMy45MS0zLjk0LDUuNS03LjMzLDUuNS0yLjgsMC02LC42OS02LDR2Mi45M2gxMy4xOXYxLjQySDYzNy41NHYtNC4zMmMwLTQuMjQsMy45MS01LjM0LDcuNDQtNS4zNCwyLjQ5LDAsNi0uOTMsNi00LjE2cy0zLjM5LTQuMy02LTQuMy01Ljg4Ljg4LTUuODgsNC4wNloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02MTQuNTggLTMwMS43NCkiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik02NjcuNTEsMzI1LjY5djEzLjM2aDIuNDF2MS40OGgtMi40MXY0LjMySDY2NnYtNC4zMkg2NTQuM2wtLjMxLTEuNzgsMTEuMDktMTMuMDZabS0xLjQ3LDEuMS0xMC40NiwxMi4yNkg2NjZaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjE0LjU4IC0zMDEuNzQpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNjc1LjIzLDMxOS41MmMtMy41Ny0xMC0xMS44My0xNS43OC0yMi42Ni0xNS43OHMtMTkuMDgsNS43NS0yMi42NSwxNS43OGwtMS44OC0uNjdjMy44Ny0xMC44OCwxMi44MS0xNy4xMSwyNC41My0xNy4xMXMyMC42Nyw2LjIzLDI0LjU0LDE3LjExWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxNC41OCAtMzAxLjc0KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTY3OSwzMjkuODVoLTJjMC0xMi41OC03LjYzLTI2LjExLTI0LjQtMjYuMTFzLTI0LjQsMTMuNTMtMjQuNCwyNi4xMWgtMmMwLTEzLjU0LDguMjYtMjguMTEsMjYuNC0yOC4xMVM2NzksMzE2LjMxLDY3OSwzMjkuODVaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjE0LjU4IC0zMDEuNzQpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNjgyLjIyLDM0OC4xM0g2NzdWMzI4Ljg1aDUuMjdjNC44NS4wOSw4Ljc3LDQuMzgsOC43Nyw5LjY0cy0zLjk1LDkuNTktOC44Myw5LjY0Wm0tMy4yMS0yaDMuMTJjMy44MiwwLDYuOTItMy40Myw2LjkyLTcuNjRzLTMuMS03LjY0LTYuOTItNy42NEg2NzlaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjE0LjU4IC0zMDEuNzQpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNjI4LjE3LDM0OC4xM0g2MjNjLTQuNjMtLjA1LTguMzgtNC4zNi04LjM4LTkuNjRzMy43Mi05LjU1LDguMzItOS42NGg1LjI3Wm0tNS4xMi0xNy4yOGMtMy41NywwLTYuNDcsMy40My02LjQ3LDcuNjRzMi45LDcuNjQsNi40Nyw3LjY0aDMuMTJWMzMwLjg1WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxNC41OCAtMzAxLjc0KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTY0NC4yOCwzNzJjLTEzLjE5LTUuODMtMTguMTEtMTguNjUtMTguMTEtMjUuMzZoMmMwLDYuMjEsNC41OSwxOC4wOCwxNi45MiwyMy41M1oiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02MTQuNTggLTMwMS43NCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik02NTMuNTMsMzc5LjQ5YTMuODUsMy44NSwwLDAsMS0xLjI3LS4yMmwtNi0yLjExYy0yLjMyLS44Mi0zLjQyLTMuNy0yLjQ3LTYuNDRhNS4xOSw1LjE5LDAsMCwxLDQuNjctMy43MSwzLjk0LDMuOTQsMCwwLDEsMS4yNy4yMmw2LjA1LDIuMTFhNC4xMyw0LjEzLDAsMCwxLDIuNSwyLjU5LDUuNzgsNS43OCwwLDAsMSwwLDMuODVBNS4xOSw1LjE5LDAsMCwxLDY1My41MywzNzkuNDlaTTY0OC40MSwzNjlhMy4yNiwzLjI2LDAsMCwwLTIuNzgsMi4zN2MtLjU5LDEuNywwLDMuNDQsMS4yNCwzLjg5bDYsMi4xMWMxLjI3LjQ1LDIuODItLjYxLDMuNC0yLjI2YTMuOCwzLjgsMCwwLDAsMC0yLjUxLDIuMTUsMi4xNSwwLDAsMC0xLjI4LTEuMzhMNjQ5LDM2OS4xMkExLjgzLDEuODMsMCwwLDAsNjQ4LjQxLDM2OVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02MTQuNTggLTMwMS43NCkiLz48L3N2Zz4="

/***/ }),

/***/ "./components/FeatureBlock/featureBlock.style.js":
/*!*******************************************************!*\
  !*** ./components/FeatureBlock/featureBlock.style.js ***!
  \*******************************************************/
/*! exports provided: IconWrapper, ContentWrapper, ButtonWrapper, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconWrapper", function() { return IconWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentWrapper", function() { return ContentWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonWrapper", function() { return ButtonWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);

 // FeatureBlock wrapper style

var FeatureBlockWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureBlockstyle__FeatureBlockWrapper",
  componentId: "sc-1qxqvjs-0"
})(["&.icon_left{display:flex;align-items:flex-start;}&.icon_right{display:flex;align-items:flex-start;flex-direction:row-reverse;.content__wrapper{text-align:right;}}", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexWrap"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexDirection"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"], styled_system__WEBPACK_IMPORTED_MODULE_1__["position"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderColor"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"], styled_system__WEBPACK_IMPORTED_MODULE_1__["overflow"]); // Icon wrapper style

var IconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureBlockstyle__IconWrapper",
  componentId: "sc-1qxqvjs-1"
})(["", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"], styled_system__WEBPACK_IMPORTED_MODULE_1__["position"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderColor"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"], styled_system__WEBPACK_IMPORTED_MODULE_1__["overflow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["fontSize"]); // Content wrapper style

var ContentWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureBlockstyle__ContentWrapper",
  componentId: "sc-1qxqvjs-2"
})(["", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["textAlign"]); // Button wrapper style

var ButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureBlockstyle__ButtonWrapper",
  componentId: "sc-1qxqvjs-3"
})(["", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexDirection"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"]);

/* harmony default export */ __webpack_exports__["default"] = (FeatureBlockWrapper);

/***/ }),

/***/ "./components/FeatureBlock/index.js":
/*!******************************************!*\
  !*** ./components/FeatureBlock/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _featureBlock_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./featureBlock.style */ "./components/FeatureBlock/featureBlock.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\FeatureBlock\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var FeatureBlock = function FeatureBlock(_ref) {
  var className = _ref.className,
      icon = _ref.icon,
      title = _ref.title,
      button = _ref.button,
      description = _ref.description,
      iconPosition = _ref.iconPosition,
      additionalContent = _ref.additionalContent,
      wrapperStyle = _ref.wrapperStyle,
      iconStyle = _ref.iconStyle,
      contentStyle = _ref.contentStyle,
      btnWrapperStyle = _ref.btnWrapperStyle,
      props = _objectWithoutProperties(_ref, ["className", "icon", "title", "button", "description", "iconPosition", "additionalContent", "wrapperStyle", "iconStyle", "contentStyle", "btnWrapperStyle"]);

  // Add all classs to an array
  var addAllClasses = ['feature__block']; // Add icon position class

  if (iconPosition) {
    addAllClasses.push("icon_".concat(iconPosition));
  } // className prop checking


  if (className) {
    addAllClasses.push(className);
  } // check icon value and add


  var Icon = icon && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureBlock_style__WEBPACK_IMPORTED_MODULE_2__["IconWrapper"], _extends({
    className: "icon__wrapper"
  }, iconStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    },
    __self: this
  }), icon);
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureBlock_style__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: addAllClasses.join(' ')
  }, wrapperStyle, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }), Icon, title || description || button ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureBlock_style__WEBPACK_IMPORTED_MODULE_2__["ContentWrapper"], _extends({
    className: "content__wrapper"
  }, contentStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  }), title, description, button && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureBlock_style__WEBPACK_IMPORTED_MODULE_2__["ButtonWrapper"], _extends({
    className: "button__wrapper"
  }, btnWrapperStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    },
    __self: this
  }), button)), additionalContent) : '');
};

FeatureBlock.propTypes = {
  /** ClassName of the FeatureBlock */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** title prop contain a react component. You can use our Heading component from reusecore */
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** description prop contain a react component. You can use our Text component from reusecore */
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** button prop contain a react component. You can use our Button component from reusecore */
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** Set icon position of the FeatureBlock */
  iconPosition: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['top', 'left', 'right']),

  /** wrapperStyle prop contain these style system props:  display, flexWrap, width, height, alignItems,
   * justifyContent, position, overflow, space, color, borders, borderColor, boxShadow and borderRadius. */
  wrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** iconStyle prop contain these style system props: display, width, height, alignItems, justifyContent,
   * position, space, fontSize, color, borders, overflow, borderColor, boxShadow and borderRadius. */
  iconStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** contentStyle prop contain these style system props: width, textAlign and space. */
  contentStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** btnWrapperStyle prop contain these style system props: display, space, alignItems,
   * flexDirection and justifyContent. */
  btnWrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
FeatureBlock.defaultProps = {
  iconPosition: 'top'
};
/* harmony default export */ __webpack_exports__["default"] = (FeatureBlock);

/***/ }),

/***/ "./components/HamburgMenu/hamburgMenu.style.js":
/*!*****************************************************!*\
  !*** ./components/HamburgMenu/hamburgMenu.style.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);


var HamburgMenuWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "hamburgMenustyle__HamburgMenuWrapper",
  componentId: "sc-11i4t5v-0"
})(["border:0;background:transparent;width:44px;height:30px;cursor:pointer;", " ", " ", " ", " ", " ", " ", " > span{display:block;width:100%;height:2px;margin:4px 0;float:right;background-color:", ";transition:all 0.3s ease;&:first-child{margin-top:0;}&:last-child{width:calc(100% - 10px);margin-bottom:0;}}&:focus,&:hover{outline:none;> span{&:last-child{width:100%;}}}&:focus{> span{&:first-child{transform:rotate(45deg);transform-origin:8px 50%;}&:nth-child(2){display:none;}&:last-child{width:100%;transform:rotate(-45deg);transform-origin:9px 50%;}}}"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["border"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"], function (props) {
  return props.barColor ? props.barColor : '#10ac84';
});
HamburgMenuWrapper.displayName = 'HamburgMenuWrapper';
/* harmony default export */ __webpack_exports__["default"] = (HamburgMenuWrapper);

/***/ }),

/***/ "./components/HamburgMenu/index.js":
/*!*****************************************!*\
  !*** ./components/HamburgMenu/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hamburgMenu_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hamburgMenu.style */ "./components/HamburgMenu/hamburgMenu.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\HamburgMenu\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var HamburgMenu = function HamburgMenu(_ref) {
  var className = _ref.className,
      wrapperStyle = _ref.wrapperStyle,
      barColor = _ref.barColor,
      props = _objectWithoutProperties(_ref, ["className", "wrapperStyle", "barColor"]);

  // Add all classs to an array
  var addAllClasses = ['hamburgMenu__bar']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_hamburgMenu_style__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: addAllClasses.join(' ')
  }, wrapperStyle, {
    barColor: barColor,
    "aria-label": "hamburgMenu"
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }));
};

HamburgMenu.propTypes = {
  /** ClassName of the Hamburg menu. */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** barColor allow to change hambrug menu's bar color. */
  barColor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** wrapperStyle prop allow to change Hamburg menu bg color, width, height, space, boxShadow, border and borderRadius.*/
  wrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
/* harmony default export */ __webpack_exports__["default"] = (HamburgMenu);

/***/ }),

/***/ "./components/ScrollSpyMenu/index.js":
/*!*******************************************!*\
  !*** ./components/ScrollSpyMenu/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_scrollspy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-scrollspy */ "react-scrollspy");
/* harmony import */ var react_scrollspy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_scrollspy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-anchor-link-smooth-scroll */ "react-anchor-link-smooth-scroll");
/* harmony import */ var react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../contexts/DrawerContext */ "./contexts/DrawerContext.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\ScrollSpyMenu\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var ScrollSpyMenu = function ScrollSpyMenu(_ref) {
  var className = _ref.className,
      menuItems = _ref.menuItems,
      drawerClose = _ref.drawerClose,
      props = _objectWithoutProperties(_ref, ["className", "menuItems", "drawerClose"]);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(_contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_4__["DrawerContext"]),
      dispatch = _useContext.dispatch; // empty array for scrollspy items


  var scrollItems = []; // convert menu path to scrollspy items

  menuItems.forEach(function (item) {
    scrollItems.push(item.path.slice(1));
  }); // Add all classs to an array

  var addAllClasses = ['scrollspy__menu']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  } // Close drawer when click on menu item


  var toggleDrawer = function toggleDrawer() {
    dispatch({
      type: 'TOGGLE'
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_scrollspy__WEBPACK_IMPORTED_MODULE_2___default.a, _extends({
    items: scrollItems,
    className: addAllClasses.join(' '),
    drawerClose: drawerClose
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    },
    __self: this
  }), menuItems.map(function (menu, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", {
      key: "menu-item-".concat(index),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41
      },
      __self: this
    }, drawerClose ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3___default.a, {
      href: menu.path,
      offset: menu.offset,
      onClick: toggleDrawer,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 43
      },
      __self: this
    }, menu.label) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3___default.a, {
      href: menu.path,
      offset: menu.offset,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 51
      },
      __self: this
    }, menu.label));
  }));
};

ScrollSpyMenu.propTypes = {
  /** className of the ScrollSpyMenu. */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** menuItems is an array of object prop which contain your menu
   * data.
   */
  menuItems: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array.isRequired,

  /** Class name that apply to the navigation element paired with the content element in viewport. */
  currentClassName: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Class name that apply to the navigation elements that have been scrolled past [optional]. */
  scrolledPastClassName: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** HTML tag for Scrollspy component if you want to use other than <ul/> [optional]. */
  componentTag: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Style attribute to be passed to the generated <ul/> element [optional]. */
  style: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Offset value that adjusts to determine the elements are in the viewport [optional]. */
  offset: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,

  /** Name of the element of scrollable container that can be used with querySelector [optional]. */
  rootEl: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /**
   * Function to be executed when the active item has been updated [optional].
   */
  onUpdate: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};
ScrollSpyMenu.defaultProps = {
  componentTag: 'ul',
  currentClassName: 'is-current'
};
/* harmony default export */ __webpack_exports__["default"] = (ScrollSpyMenu);

/***/ }),

/***/ "./components/UI/Container/index.js":
/*!******************************************!*\
  !*** ./components/UI/Container/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./style */ "./components/UI/Container/style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\UI\\Container\\index.js";



var Container = function Container(_ref) {
  var children = _ref.children,
      className = _ref.className,
      fullWidth = _ref.fullWidth,
      noGutter = _ref.noGutter;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_style__WEBPACK_IMPORTED_MODULE_1__["default"], {
    className: className,
    fullWidth: fullWidth,
    noGutter: noGutter,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    },
    __self: this
  }, children);
};

/* harmony default export */ __webpack_exports__["default"] = (Container);

/***/ }),

/***/ "./components/UI/Container/style.js":
/*!******************************************!*\
  !*** ./components/UI/Container/style.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var ContainerWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "style__ContainerWrapper",
  componentId: "posx22-0"
})(["margin-left:auto;margin-right:auto;", ";", ";@media (min-width:768px){max-width:750px;width:100%;}@media (min-width:992px){max-width:970px;width:100%;}@media (min-width:1200px){max-width:1170px;width:100%;}"], function (props) {
  return props.fullWidth && Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["css"])(["width:100%;max-width:none !important;"]);
}, function (props) {
  return props.noGutter && Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["css"])(["padding-left:0;padding-right:0;"]) || Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["css"])(["padding-left:30px;padding-right:30px;"]);
});
/* harmony default export */ __webpack_exports__["default"] = (ContainerWrapper);

/***/ }),

/***/ "./containers/App/Banner/banner.style.js":
/*!***********************************************!*\
  !*** ./containers/App/Banner/banner.style.js ***!
  \***********************************************/
/*! exports provided: DiscountWrapper, ButtonWrapper, EmailInputWrapper, DiscountLabel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountWrapper", function() { return DiscountWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonWrapper", function() { return ButtonWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmailInputWrapper", function() { return EmailInputWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountLabel", function() { return DiscountLabel; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_image_app_mail_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../assets/image/app/mail.svg */ "./assets/image/app/mail.svg");
/* harmony import */ var _assets_image_app_mail_svg__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_mail_svg__WEBPACK_IMPORTED_MODULE_1__);


var DiscountWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "bannerstyle__DiscountWrapper",
  componentId: "agsqhh-0"
})(["text-align:left;"]);
var ButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "bannerstyle__ButtonWrapper",
  componentId: "agsqhh-1"
})(["position:relative;@media screen and (max-width:991px) and (min-width:767px){display:flex;.reusecore__button{padding-left:0;padding-right:0;&.withoutBg{margin-left:25px;&:hover{background:transparent !important;box-shadow:none !important;}}}}@media (max-width:480px){display:flex;flex-direction:column;.reusecore__button{width:100%;&.withoutBg{border:0;}}}"]);
var EmailInputWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "bannerstyle__EmailInputWrapper",
  componentId: "agsqhh-2"
})(["position:relative;width:85%;@media (max-width:768px){width:100%;}&::before{content:url(", ");display:block;position:relative;width:22px;left:22px;top:46px;z-index:9;}input{border-radius:5px;background-color:rgb(255,255,255);box-shadow:0px 7px 25px 0px rgba(22,53,76,0.08) !important;border:0 !important;margin-bottom:30px;height:60px;padding-left:60px !important;color:#343d48;opacity:1;font-weight:500;@media (max-width:768px){}&:focus{border:0;box-shadow:0px 7px 25px 0px rgba(22,53,76,0.08);}&:placeholder{font-size:16px;color:#343d48;opacity:1;}}.input-icon{left:10px !important;right:auto;top:7px !important;height:46px !important;svg{color:#ececec;width:24px;height:30px;}}"], _assets_image_app_mail_svg__WEBPACK_IMPORTED_MODULE_1___default.a);
var DiscountLabel = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "bannerstyle__DiscountLabel",
  componentId: "agsqhh-3"
})(["font-family:'Open Sans',sans-serif;display:inline-block;border-radius:4em;padding:10px 24px 0 6px;box-shadow:0px 7px 25px 0px rgba(22,53,76,0.05);margin-bottom:30px;background-color:#fff;height:45px;@media (max-width:990px){margin-top:50px;}@media (max-width:420px){padding:10px;}span{@media (max-width:420px){font-size:12px;}}.discountAmount{padding:9px 21px;border-radius:28px;text-transform:uppercase;@media (max-width:420px){padding:8px 16px;font-size:10px;}}"]);

/***/ }),

/***/ "./containers/App/Banner/index.js":
/*!****************************************!*\
  !*** ./containers/App/Banner/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Card */ "../../node_modules/reusecore/src/elements/Card/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reusecore/src/elements/Input */ "../../node_modules/reusecore/src/elements/Input/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _particles__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../particles */ "./containers/App/particles/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var react_icons_kit_ionicons_email__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-icons-kit/ionicons/email */ "react-icons-kit/ionicons/email");
/* harmony import */ var react_icons_kit_ionicons_email__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_ionicons_email__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-icons-kit */ "react-icons-kit");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_icons_kit_md_ic_arrow_forward__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-icons-kit/md/ic_arrow_forward */ "react-icons-kit/md/ic_arrow_forward");
/* harmony import */ var react_icons_kit_md_ic_arrow_forward__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_md_ic_arrow_forward__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _app_style__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../app.style */ "./containers/App/app.style.js");
/* harmony import */ var _banner_style__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./banner.style */ "./containers/App/Banner/banner.style.js");
/* harmony import */ var _assets_image_app_mobile_png__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../assets/image/app/mobile.png */ "./assets/image/app/mobile.png");
/* harmony import */ var _assets_image_app_mobile_png__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_mobile_png__WEBPACK_IMPORTED_MODULE_18__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\Banner\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }





















var DomainSection = function DomainSection(_ref) {
  var SectionWrapper = _ref.SectionWrapper,
      row = _ref.row,
      col = _ref.col,
      title = _ref.title,
      description = _ref.description,
      button = _ref.button,
      image = _ref.image,
      imageArea = _ref.imageArea,
      btnStyle = _ref.btnStyle,
      btnStyleTwo = _ref.btnStyleTwo,
      textArea = _ref.textArea,
      discountAmount = _ref.discountAmount,
      discountText = _ref.discountText;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, SectionWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_particles__WEBPACK_IMPORTED_MODULE_11__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_app_style__WEBPACK_IMPORTED_MODULE_16__["BannerSquareShape"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_app_style__WEBPACK_IMPORTED_MODULE_16__["BannerCircleShape"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_12__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, col, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_banner_style__WEBPACK_IMPORTED_MODULE_17__["DiscountWrapper"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_banner_style__WEBPACK_IMPORTED_MODULE_17__["DiscountLabel"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, discountAmount, {
    className: "discountAmount",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, discountText, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_10__["default"], {
    title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, title, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 59
      },
      __self: this
    })),
    description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, description, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 60
      },
      __self: this
    })),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_banner_style__WEBPACK_IMPORTED_MODULE_17__["EmailInputWrapper"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_9__["default"], {
    inputType: "email",
    placeholder: "Enter Email Address",
    iconPosition: "left",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_banner_style__WEBPACK_IMPORTED_MODULE_17__["ButtonWrapper"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 69
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: "#services",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, button, btnStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 72
    },
    __self: this
  })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: "#",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 75
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, button, btnStyleTwo, {
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_kit__WEBPACK_IMPORTED_MODULE_14__["Icon"], {
      icon: react_icons_kit_md_ic_arrow_forward__WEBPACK_IMPORTED_MODULE_15__["ic_arrow_forward"],
      __source: {
        fileName: _jsxFileName,
        lineNumber: 80
      },
      __self: this
    }),
    className: "withoutBg",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77
    },
    __self: this
  })))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, col, imageArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 87
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_8__["default"], _extends({
    src: _assets_image_app_mobile_png__WEBPACK_IMPORTED_MODULE_18___default.a,
    alt: "Domain Image"
  }, image, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 88
    },
    __self: this
  }))))));
};

DomainSection.propTypes = {
  SectionWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  btnStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  btnStyleTwo: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  discountAmount: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  discountText: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  textArea: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
DomainSection.defaultProps = {
  SectionWrapper: {
    as: 'section',
    pt: '80px',
    pb: '80px',
    overflow: 'hidden'
  },
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px',
    alignItems: 'center'
  },
  imageAreaRow: {
    flexDirection: 'row-reverse'
  },
  col: {
    pr: '15px',
    pl: '15px',
    width: ['100%', '100%', '50%', '44%', '44%'],
    mt: '-80px'
  },
  // textArea: {
  // 	width: [1, '42%'],
  // },
  imageArea: {
    width: ['0%', '0%', '43%', '35%', '50%'],
    ml: 'auto'
  },
  title: {
    content: 'Essential Mobile  App Landing for  Workspaces',
    fontSize: ['26px', '30px', '30px', '48px', '60px'],
    fontWeight: '300',
    color: '#0f2137',
    letterSpacing: '-0.01px',
    mb: '20px'
  },
  description: {
    content: 'A mobile app landing page is important and  essential for right amount of information about your product. Start increasing your user base upon the launch of your product.',
    fontSize: '16px',
    color: '#343d48',
    lineHeight: '33px',
    mb: '10px'
  },
  button: {
    title: 'EXPLORE MORE',
    type: 'button',
    fontSize: '14px',
    fontWeight: '600',
    color: '#fff',
    borderRadius: '4px',
    pl: '22px',
    pr: '22px',
    colors: 'primaryWithBg'
  },
  image: {
    ml: 'auto',
    mt: '70px'
  },
  btnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500'
  },
  btnStyleTwo: {
    title: 'WATCH DEMOS',
    type: 'button',
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500',
    ml: '15px',
    bg: '#fff',
    color: 'rgb(26, 115, 232)'
  },
  textArea: {
    width: ['100%', '100%', '50%', '55%', '55%']
  },
  discountAmount: {
    content: 'update',
    fontSize: '14px',
    fontWeight: '600',
    color: '#fff',
    mb: 0,
    as: 'span',
    mr: '0.4em',
    bg: 'rgb(26, 115, 232)'
  },
  discountText: {
    content: 'Version 2.5.0 has just released .',
    fontSize: '13px',
    fontWeight: '400',
    color: '#0f2137',
    mb: 0,
    as: 'span',
    ml: '10px'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (DomainSection);

/***/ }),

/***/ "./containers/App/Control/index.js":
/*!*****************************************!*\
  !*** ./containers/App/Control/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-reveal/Fade */ "react-reveal/Fade");
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reusecore/src/elements/Card */ "../../node_modules/reusecore/src/elements/Card/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _data_Hosting_data__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../data/Hosting/data */ "./data/Hosting/data.js");
/* harmony import */ var _assets_image_app_info1_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../assets/image/app/info1.png */ "./assets/image/app/info1.png");
/* harmony import */ var _assets_image_app_info1_png__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_info1_png__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_image_app_info2_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../assets/image/app/info2.png */ "./assets/image/app/info2.png");
/* harmony import */ var _assets_image_app_info2_png__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_info2_png__WEBPACK_IMPORTED_MODULE_15__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\Control\\index.js";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }


















var ControllSection = function ControllSection(_ref) {
  var sectionWrapper = _ref.sectionWrapper,
      row = _ref.row,
      col = _ref.col,
      title = _ref.title,
      description = _ref.description,
      button = _ref.button,
      textArea = _ref.textArea,
      imageArea = _ref.imageArea,
      textAreaRow = _ref.textAreaRow,
      imageAreaRow = _ref.imageAreaRow,
      imageWrapper = _ref.imageWrapper,
      imageOne = _ref.imageOne,
      imageTwo = _ref.imageTwo,
      imageWrapperOne = _ref.imageWrapperOne,
      imageWrapperTwo = _ref.imageWrapperTwo,
      sectionSubTitle = _ref.sectionSubTitle,
      btnStyle = _ref.btnStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, sectionWrapper, {
    id: "control",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_12__["default"], {
    fullWidth: true,
    noGutter: true,
    className: "control-sec-container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, row, imageAreaRow, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, col, imageArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_9__["default"], _extends({}, imageWrapper, imageWrapperOne, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default.a, {
    left: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({}, imageOne, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_9__["default"], _extends({}, imageWrapper, imageWrapperTwo, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default.a, {
    bottom: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({}, imageTwo, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  }))))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_12__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, row, textAreaRow, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, col, textArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_11__["default"], {
    title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({}, title, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 60
      },
      __self: this
    })),
    description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, description, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 61
      },
      __self: this
    })),
    button: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "#",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 63
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 64
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_8__["default"], _extends({}, button, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 65
      },
      __self: this
    })))),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  })))));
};

ControllSection.propTypes = {
  sectionWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  btnStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
ControllSection.defaultProps = {
  sectionWrapper: {
    as: 'section',
    pt: ['40px', '80px'],
    pb: ['40px', '80px']
  },
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px'
  },
  textAreaRow: {
    flexDirection: 'row-reverse'
  },
  col: {
    pr: '15px',
    pl: '15px'
  },
  textArea: {
    width: ['100%', '100%', '50%', '50%', '50%']
  },
  imageArea: {
    width: ['0px', '0px', '53%', '50%', '50%'],
    flexBox: true
  },
  imageWrapper: {
    boxShadow: 'none'
  },
  imageWrapperOne: {
    pointerEvents: 'none'
  },
  imageWrapperTwo: {
    alignSelf: 'flex-end',
    mb: '-60px',
    ml: ['0px', '0px', '-200px', '-250px', '-400px'],
    pointerEvents: 'none'
  },
  imageOne: {
    src: "".concat(_assets_image_app_info1_png__WEBPACK_IMPORTED_MODULE_14___default.a),
    alt: 'Info Image One'
  },
  imageTwo: {
    src: "".concat(_assets_image_app_info2_png__WEBPACK_IMPORTED_MODULE_15___default.a),
    alt: 'Info Image Two'
  },
  sectionSubTitle: _defineProperty({
    content: 'EASY DEPLOYMENT',
    as: 'span',
    display: 'block',
    textAlign: 'left',
    fontSize: '14px',
    letterSpacing: '0.11em',
    fontWeight: '700',
    color: '#1a73e8',
    textTransform: 'uppercase',
    mb: '10px'
  }, "textAlign", ['center', 'left']),
  title: {
    content: 'Deploy your site with simple commands',
    fontSize: ['24px', '26px', '30px', '36px', '48px'],
    fontWeight: '300',
    color: '#0f2137',
    letterSpacing: '-0.010em',
    mb: '20px',
    maxWidth: ['100%', '100%', '100%', '420px', '420px'],
    textAlign: ['center', 'left']
  },
  description: {
    content: 'You can deploy your site with firebase or Now.sh with some simple process. The deployment is made easy for our customers and according to their needs.',
    fontSize: '16px',
    color: '#343d48cc',
    lineHeight: '1.75',
    mb: '33px',
    maxWidth: ['100%', '100%', '100%', '440px', '440px'],
    textAlign: ['center', 'left']
  },
  button: {
    title: 'LEARN MORE',
    type: 'button',
    fontSize: '14px',
    fontWeight: '600',
    color: '#fff',
    borderRadius: '4px',
    pl: '22px',
    pr: '22px',
    colors: 'primaryWithBg'
  },
  btnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (ControllSection);

/***/ }),

/***/ "./containers/App/FeatureSection/featureSection.style.js":
/*!***************************************************************!*\
  !*** ./containers/App/FeatureSection/featureSection.style.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var FeatureSectionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "featureSectionstyle__FeatureSectionWrapper",
  componentId: "sc-10a73mt-0"
})(["padding:80px 0 100px;@media (max-width:1440px){padding:40px 0 50px;}@media (max-width:768px){padding:40px 0 0px;}@media (max-width:500px){padding:30px 0;}.feature__block{position:relative;height:100%;transition:box-shadow 0.3s ease;.icon__wrapper{position:relative;background:transperent;.flaticon-flask{&:before{margin-left:8px;}}&:before{transform:rotate(45deg);background-color:rgba(255,255,255,0.15);}&:after{transform:rotate(-45deg);background-color:rgba(0,0,0,0.05);}}&:hover{box-shadow:0 40px 90px -30px rgba(39,79,117,0.2);cursor:pointer;}}.row{> .col{&:nth-child(1){.feature__block{.icon__wrapper{color:#29cf8a;transition:all 0.6s ease;}}&:hover{.feature__block{.icon__wrapper{background:#29cf8a;color:#fff;border:0;}}}}&:nth-child(2){.feature__block{.icon__wrapper{color:#ff86ab;transition:all 0.6s ease;}}&:hover{.feature__block{.icon__wrapper{background:#ff86ab;color:#fff;border:0;}}}}&:nth-child(3){.feature__block{.icon__wrapper{color:#ff9000;transition:all 0.6s ease;}}}&:hover{.feature__block{.icon__wrapper{background:#ff9000;color:#fff;}}}}}"]);
/* harmony default export */ __webpack_exports__["default"] = (FeatureSectionWrapper);

/***/ }),

/***/ "./containers/App/FeatureSection/index.js":
/*!************************************************!*\
  !*** ./containers/App/FeatureSection/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _data_App_FeatureSection__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../data/App/FeatureSection */ "./data/App/FeatureSection/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _featureSection_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./featureSection.style */ "./containers/App/FeatureSection/featureSection.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\FeatureSection\\index.js";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }











var FeatureSection = function FeatureSection(_ref) {
  var row = _ref.row,
      col = _ref.col,
      sectionHeader = _ref.sectionHeader,
      sectionTitle = _ref.sectionTitle,
      sectionSubTitle = _ref.sectionSubTitle,
      featureTitle = _ref.featureTitle,
      featureDescription = _ref.featureDescription,
      iconStyle = _ref.iconStyle,
      contentStyle = _ref.contentStyle,
      blockWrapperStyle = _ref.blockWrapperStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureSection_style__WEBPACK_IMPORTED_MODULE_8__["default"], {
    id: "services",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, sectionHeader, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, sectionTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }), _data_App_FeatureSection__WEBPACK_IMPORTED_MODULE_6__["default"].features.map(function (feature, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
      className: "col"
    }, col, {
      key: index,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_5__["default"], {
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
        className: feature.icon,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 34
        },
        __self: this
      }),
      wrapperStyle: blockWrapperStyle,
      iconStyle: iconStyle,
      contentStyle: contentStyle,
      title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
        content: feature.title
      }, featureTitle, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        },
        __self: this
      })),
      description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
        content: feature.description
      }, featureDescription, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 40
        },
        __self: this
      })),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33
      },
      __self: this
    }));
  }))));
}; // FeatureSection style props


FeatureSection.propTypes = {
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  featureTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  featureDescription: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // FeatureSection default style

FeatureSection.defaultProps = {
  // section header default style
  sectionHeader: {
    mb: ['30px', '30px', '30px', '56px']
  },
  // sub section default style
  sectionSubTitle: _defineProperty({
    content: 'OUR SERVICES',
    as: 'span',
    display: 'block',
    textAlign: 'center',
    fontSize: '14px',
    letterSpacing: '0.13em',
    fontWeight: '700',
    color: '#1a73e8',
    mb: '10px'
  }, "textAlign", ['center']),
  // section title default style
  sectionTitle: _defineProperty({
    content: 'Featured Service that We Provide',
    textAlign: 'center',
    fontSize: ['20px', '24px', '24px', '24px', '30px'],
    fontWeight: '400',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '0'
  }, "textAlign", ['center']),
  // feature row default style
  row: {
    flexBox: true,
    flexWrap: 'wrap'
  },
  // feature col default style
  col: {
    width: [1, 1 / 2, 1 / 3, 1 / 3, 1 / 3]
  },
  // feature block wrapper default style
  blockWrapperStyle: {
    p: ['20px', '20px', '20px', '40px']
  },
  // feature icon default style
  iconStyle: {
    width: '84px',
    height: '84px',
    m: '0 auto',
    borderRadius: '50%',
    bg: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '36px',
    color: '#29cf8a',
    overflow: 'hidden',
    mb: ['20px', '20px', '20px', '30px'],
    border: '1px solid rgba(36, 74, 117,0.1)'
  },
  // feature content default style
  contentStyle: {
    textAlign: 'center'
  },
  // feature title default style
  featureTitle: {
    fontSize: ['18px', '20px'],
    fontWeight: '400',
    color: '#0f2137',
    lineHeight: '1.5',
    mb: ['10px', '10px', '10px', '20px'],
    letterSpacing: '-0.020em'
  },
  // feature description default style
  featureDescription: {
    fontSize: ['14px', '15px'],
    lineHeight: '1.75',
    color: '#343d48'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (FeatureSection);

/***/ }),

/***/ "./containers/App/FeatureSlider/featureSlider.style.js":
/*!*************************************************************!*\
  !*** ./containers/App/FeatureSlider/featureSlider.style.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_image_app_iphone_mockup_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../assets/image/app/iphone-mockup.png */ "./assets/image/app/iphone-mockup.png");
/* harmony import */ var _assets_image_app_iphone_mockup_png__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_iphone_mockup_png__WEBPACK_IMPORTED_MODULE_1__);

 // import FeatureBlock from '../../components/FeatureBlock';

var FeatureSliderWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureSliderstyle__FeatureSliderWrapper",
  componentId: "cyk2q2-0"
})(["position:relative;padding-top:200px;@media (max-width:1440px){padding-top:140px;}.FeatureSliderInner{span:nth-child(1){position:absolute;display:block;width:5%;padding-bottom:5%;border-radius:50%;top:60%;left:50%;opacity:0;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);animation:pulsei 4.2s ease-out infinite;backface-visibility:hidden;pointer-events:none;}span:nth-child(2){content:'';position:absolute;display:block;width:5%;padding-bottom:5%;border-radius:50%;top:60%;left:50%;opacity:0;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);animation:pulsei 4.2s ease-out infinite;backface-visibility:hidden;pointer-events:none;animation-delay:1s;}span:nth-child(3){content:'';position:absolute;display:block;width:5%;padding-bottom:5%;border-radius:50%;top:60%;left:50%;opacity:0;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);animation:pulsei 4.2s ease-out infinite;backface-visibility:hidden;pointer-events:none;animation-delay:2s;}}.FeatureSlider{padding-top:200px;padding-bottom:100px;position:relative;.image-gallery{position:relative;z-index:2;}@keyframes pulsei{0%{transform:translateX(-50%) translateY(-50%) translateZ(0) scale(1);border:1px solid rgba(0,0,0,0.5);opacity:1;width:5%;padding-bottom:5%;}100%{transform:translateX(-50%) translateY(-50%) translateZ(0) scale(1);opacity:0;width:67%;border:1px solid rgba(0,0,0,0.5);padding-bottom:67%;}}.image-gallery-slide-wrapper{width:375px;margin-left:auto;margin-right:auto;position:relative;height:749px;&::before{content:'';background-image:url(", ");position:absolute;width:100%;height:100%;top:0;left:0;z-index:1;background-repeat:no-repeat;background-size:contain;}&:after{content:'';width:calc(100% - 20px);height:calc(100% - 20px);top:50%;left:50%;transform:translate(-50%,-50%);box-shadow:0 0 68px rgba(0,0,0,1);display:block;position:absolute;border-radius:50px;}.image-gallery-swipe{padding:19px 24px 22px 23px;overflow:hidden;}}.image-gallery-thumbnails-wrapper{position:static;.image-gallery-thumbnails-container{position:absolute;width:100%;height:100%;z-index:1;top:0;left:0;.image-gallery-thumbnail{border:0;width:125px;.image-gallery-thumbnail-inner{outline:none;&:focus{outline:none;}}img{transition:all 0.35s ease;width:100px;}&:nth-child(1){position:absolute;top:-80px;left:16.666%;}&:nth-child(2){position:absolute;top:-80px;right:16.666%;}&:nth-child(3){position:absolute;top:50%;right:0;transform:translateY(-50%);}&:nth-child(4){position:absolute;bottom:-120px;right:16.666%;}&:nth-child(5){position:absolute;bottom:-120px;left:16.666%;}&:nth-child(6){position:absolute;top:50%;left:0;transform:translateY(-50%);}.image-gallery-thumbnail-label{position:relative;margin-top:10px;font-size:19px;line-height:24px;letter-spacing:-0.01em;color:#0f2137;font-family:'Open sans';top:0;text-shadow:none;transform:none;white-space:normal;width:100%;}&.active{border:0;.image-gallery-thumbnail-label{margin-top:30px;}img{transition:all 0.35s ease;transform:scale(1.4);border:0;}}}}}.image-gallery-bullets{bottom:auto;margin:0;position:absolute;width:100%;z-index:4;top:43%;right:-65px;left:auto;display:flex;justify-content:flex-end;.image-gallery-bullets-container{margin:0;padding:0;text-align:center;display:flex;flex-direction:column;width:32px;.image-gallery-bullet{appearance:none;border-radius:70px;cursor:pointer;display:inline-block;outline:none;width:19px;height:4px;background:rgb(220,226,231);border:0;box-shadow:none;padding:0;margin:0;margin-bottom:10px;transition:all 0.3s ease;&.active{background-color:rgb(26,115,232);width:32px;height:4px;}}}}}"], _assets_image_app_iphone_mockup_png__WEBPACK_IMPORTED_MODULE_1___default.a);
/* harmony default export */ __webpack_exports__["default"] = (FeatureSliderWrapper);

/***/ }),

/***/ "./containers/App/FeatureSlider/index.js":
/*!***********************************************!*\
  !*** ./containers/App/FeatureSlider/index.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_image_gallery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-image-gallery */ "react-image-gallery");
/* harmony import */ var react_image_gallery__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_image_gallery__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-image-gallery/styles/css/image-gallery.css */ "../../node_modules/react-image-gallery/styles/css/image-gallery.css");
/* harmony import */ var react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _featureSlider_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./featureSlider.style */ "./containers/App/FeatureSlider/featureSlider.style.js");
/* harmony import */ var _assets_image_app_slide_2_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../assets/image/app/slide-2.png */ "./assets/image/app/slide-2.png");
/* harmony import */ var _assets_image_app_slide_2_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_slide_2_png__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _assets_image_app_slide_1_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../assets/image/app/slide-1.png */ "./assets/image/app/slide-1.png");
/* harmony import */ var _assets_image_app_slide_1_png__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_slide_1_png__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _assets_image_app_slide_3_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../assets/image/app/slide-3.png */ "./assets/image/app/slide-3.png");
/* harmony import */ var _assets_image_app_slide_3_png__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_slide_3_png__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_image_app_slide_4_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../assets/image/app/slide-4.png */ "./assets/image/app/slide-4.png");
/* harmony import */ var _assets_image_app_slide_4_png__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_slide_4_png__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _assets_image_app_slide_5_png__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../assets/image/app/slide-5.png */ "./assets/image/app/slide-5.png");
/* harmony import */ var _assets_image_app_slide_5_png__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_slide_5_png__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_image_app_6_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../assets/image/app/6.svg */ "./assets/image/app/6.svg");
/* harmony import */ var _assets_image_app_6_svg__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_6_svg__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_image_app_1_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../assets/image/app/1.svg */ "./assets/image/app/1.svg");
/* harmony import */ var _assets_image_app_1_svg__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_1_svg__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _assets_image_app_2_svg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../assets/image/app/2.svg */ "./assets/image/app/2.svg");
/* harmony import */ var _assets_image_app_2_svg__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_2_svg__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _assets_image_app_3_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../assets/image/app/3.svg */ "./assets/image/app/3.svg");
/* harmony import */ var _assets_image_app_3_svg__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_3_svg__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _assets_image_app_4_svg__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../assets/image/app/4.svg */ "./assets/image/app/4.svg");
/* harmony import */ var _assets_image_app_4_svg__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_4_svg__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _assets_image_app_5_svg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../assets/image/app/5.svg */ "./assets/image/app/5.svg");
/* harmony import */ var _assets_image_app_5_svg__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_5_svg__WEBPACK_IMPORTED_MODULE_19__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\FeatureSlider\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }




















 // import DomainSection from '../container/Hosting/Domain';

var images = [{
  original: "".concat(_assets_image_app_slide_2_png__WEBPACK_IMPORTED_MODULE_9___default.a),
  thumbnail: "".concat(_assets_image_app_6_svg__WEBPACK_IMPORTED_MODULE_14___default.a),
  thumbnailLabel: 'Super Performance'
}, {
  original: "".concat(_assets_image_app_slide_1_png__WEBPACK_IMPORTED_MODULE_10___default.a),
  thumbnail: "".concat(_assets_image_app_1_svg__WEBPACK_IMPORTED_MODULE_15___default.a),
  thumbnailLabel: 'Search optimization'
}, {
  original: "".concat(_assets_image_app_slide_3_png__WEBPACK_IMPORTED_MODULE_11___default.a),
  thumbnail: "".concat(_assets_image_app_2_svg__WEBPACK_IMPORTED_MODULE_16___default.a),
  thumbnailLabel: 'Customer Support'
}, {
  original: "".concat(_assets_image_app_slide_1_png__WEBPACK_IMPORTED_MODULE_10___default.a),
  thumbnail: "".concat(_assets_image_app_3_svg__WEBPACK_IMPORTED_MODULE_17___default.a),
  thumbnailLabel: '100% response time'
}, {
  original: "".concat(_assets_image_app_slide_4_png__WEBPACK_IMPORTED_MODULE_12___default.a),
  thumbnail: "".concat(_assets_image_app_4_svg__WEBPACK_IMPORTED_MODULE_18___default.a),
  thumbnailLabel: 'Maintaining Milestones'
}, {
  original: "".concat(_assets_image_app_slide_5_png__WEBPACK_IMPORTED_MODULE_13___default.a),
  thumbnail: "".concat(_assets_image_app_5_svg__WEBPACK_IMPORTED_MODULE_19___default.a),
  thumbnailLabel: 'Organised Code'
}];

var FeatureSlider = function FeatureSlider(_ref) {
  var sectionSubTitle = _ref.sectionSubTitle,
      sectionTitle = _ref.sectionTitle,
      sectionHeader = _ref.sectionHeader;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureSlider_style__WEBPACK_IMPORTED_MODULE_8__["default"], {
    id: "keyfeature",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "FeatureSliderInner",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    },
    __self: this
  }, " "), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    },
    __self: this
  }, " "), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    },
    __self: this
  }, " ")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, sectionHeader, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, sectionTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "FeatureSlider",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 69
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_image_gallery__WEBPACK_IMPORTED_MODULE_2___default.a, {
    items: images,
    className: "Slider-img",
    showPlayButton: false,
    showFullscreenButton: false,
    showNav: false,
    showBullets: true,
    autoPlay: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    },
    __self: this
  }))));
}; // FeatureSlider style props


FeatureSlider.propTypes = {
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // FeatureSlider default style

FeatureSlider.defaultProps = {
  sectionHeader: {},
  sectionSubTitle: {
    content: 'WHY CHOOSE US',
    as: 'span',
    display: 'block',
    textAlign: 'center',
    fontSize: '14px',
    letterSpacing: '0.13em',
    fontWeight: '700',
    color: '#1a73e8',
    mb: '10px'
  },
  // section title default style
  sectionTitle: {
    content: 'Key Features of Our App',
    textAlign: 'center',
    fontSize: ['20px', '24px', '24px', '24px', '30px'],
    fontWeight: '400',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '0'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (FeatureSlider);

/***/ }),

/***/ "./containers/App/FeatureSliderTwo/featureSliderTwo.style.js":
/*!*******************************************************************!*\
  !*** ./containers/App/FeatureSliderTwo/featureSliderTwo.style.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var FeatureSectionTwoWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "featureSliderTwostyle__FeatureSectionTwoWrapper",
  componentId: "sc-1s4co4w-0"
})(["padding:80px 0 160px;@media (max-width:1440px){padding:40px 0 50px;}@media screen and (max-width:1100px) and (min-width:992px){padding:140px 0 60px;}@media (max-width:991px){padding:60px 0 60px;}@media (max-width:767px){padding-top:60px;}"]);
/* harmony default export */ __webpack_exports__["default"] = (FeatureSectionTwoWrapper);

/***/ }),

/***/ "./containers/App/FeatureSliderTwo/index.js":
/*!**************************************************!*\
  !*** ./containers/App/FeatureSliderTwo/index.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-reveal/Fade */ "react-reveal/Fade");
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _data_App_FeatureSliderTwo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../data/App/FeatureSliderTwo */ "./data/App/FeatureSliderTwo/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _featureSliderTwo_style__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./featureSliderTwo.style */ "./containers/App/FeatureSliderTwo/featureSliderTwo.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\FeatureSliderTwo\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }













var FeatureSection = function FeatureSection(_ref) {
  var row = _ref.row,
      col = _ref.col,
      sectionHeader = _ref.sectionHeader,
      sectionTitle = _ref.sectionTitle,
      sectionSubTitle = _ref.sectionSubTitle,
      featureTitle = _ref.featureTitle,
      featureDescription = _ref.featureDescription,
      iconStyle = _ref.iconStyle,
      contentStyle = _ref.contentStyle,
      blockWrapperStyle = _ref.blockWrapperStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureSliderTwo_style__WEBPACK_IMPORTED_MODULE_10__["default"], {
    id: "keyfeatures",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_9__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, sectionHeader, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, sectionTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    },
    __self: this
  }), _data_App_FeatureSliderTwo__WEBPACK_IMPORTED_MODULE_8__["default"].features.map(function (feature, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
      className: "col"
    }, col, {
      key: index,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 34
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_2___default.a, {
      bottom: true,
      delay: index * 120,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 35
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_7__["default"], {
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_6__["default"], {
        src: feature.image,
        alt: "Demo Image",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 37
        },
        __self: this
      }),
      wrapperStyle: blockWrapperStyle,
      iconStyle: iconStyle,
      contentStyle: contentStyle,
      title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
        content: feature.title
      }, featureTitle, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 41
        },
        __self: this
      })),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36
      },
      __self: this
    })));
  }))));
}; // FeatureSection style props


FeatureSection.propTypes = {
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  featureTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  featureDescription: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // FeatureSection default style

FeatureSection.defaultProps = {
  // section header default style
  sectionHeader: {
    mb: ['56px', '56px']
  },
  // sub section default style
  sectionSubTitle: {
    content: 'KEY FEATURES',
    as: 'span',
    display: 'block',
    textAlign: 'center',
    fontSize: '14px',
    letterSpacing: '0.13em',
    fontWeight: '700',
    color: '#1a73e8',
    mb: '10px'
  },
  // section title default style
  sectionTitle: {
    content: 'Key Features Of our App',
    textAlign: 'center',
    fontSize: ['20px', '24px', '24px', '24px', '30px'],
    fontWeight: '400',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '0'
  },
  // feature row default style
  row: {
    flexBox: true,
    flexWrap: 'wrap'
  },
  // feature col default style
  col: {
    width: [1 / 2, 1 / 2, 1 / 3, 1 / 3, 1 / 3]
  },
  // feature block wrapper default style
  blockWrapperStyle: {
    p: ['10px', '20px', '20px', '40px']
  },
  // feature icon default style
  iconStyle: {
    width: '75px',
    height: '75px',
    m: '0 auto',
    borderRadius: '50%',
    bg: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '32px',
    color: '#29cf8a',
    overflow: 'hidden',
    mb: '15px'
  },
  // feature content default style
  contentStyle: {
    textAlign: 'center'
  },
  // feature title default style
  featureTitle: {
    fontSize: ['16px', '18px'],
    fontWeight: '400',
    color: '#0f2137',
    lineHeight: '1.5',
    mb: '20px',
    letterSpacing: '-0.020em'
  },
  // feature description default style
  featureDescription: {
    fontSize: ['14px', '15px'],
    lineHeight: '1.84',
    color: '#343d48cc'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (FeatureSection);

/***/ }),

/***/ "./containers/App/Footer/footer.style.js":
/*!***********************************************!*\
  !*** ./containers/App/Footer/footer.style.js ***!
  \***********************************************/
/*! exports provided: List, ListItem, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "List", function() { return List; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListItem", function() { return ListItem; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_image_agency_footer_bg_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../assets/image/agency/footer-bg.png */ "./assets/image/agency/footer-bg.png");
/* harmony import */ var _assets_image_agency_footer_bg_png__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_image_agency_footer_bg_png__WEBPACK_IMPORTED_MODULE_1__);


var FooterWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "footerstyle__FooterWrapper",
  componentId: "sc-18eiyka-0"
})(["padding:80px 0 55px;margin-top:40px;background-color:rgb(246,249,252);@media (max-width:480px){padding:60px 0 30px;}.copyrightClass{@media (max-width:1024px){display:flex;flex-direction:column;justify-content:center;align-items:center;}.copyrightMenu{@media (max-width:1024px){margin-top:10px;margin-bottom:10px;justify-content:left;align-items:left;margin-left:0;}@media (max-width:767px){justify-content:left;align-items:left;margin-left:0;margin-top:10px;margin-bottom:10px;}}.copyrightText{@media (max-width:1100px){margin-left:0;}}}"]);
var List = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.ul.withConfig({
  displayName: "footerstyle__List",
  componentId: "sc-18eiyka-1"
})([""]);
var ListItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.li.withConfig({
  displayName: "footerstyle__ListItem",
  componentId: "sc-18eiyka-2"
})(["a{color:rgba(52,61,72,0.8);font-size:14px;line-height:36px;transition:all 0.2s ease;&:hover,&:focus{outline:0;text-decoration:none;color:#343d48;}}"]);

/* harmony default export */ __webpack_exports__["default"] = (FooterWrapper);

/***/ }),

/***/ "./containers/App/Footer/index.js":
/*!****************************************!*\
  !*** ./containers/App/Footer/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_UI_Logo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/UI/Logo */ "../../node_modules/reusecore/src/elements/UI/Logo/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _footer_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./footer.style */ "./containers/App/Footer/footer.style.js");
/* harmony import */ var _assets_image_app_logo_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../assets/image/app/logo.png */ "./assets/image/app/logo.png");
/* harmony import */ var _assets_image_app_logo_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_logo_png__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _data_App_Footer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../data/App/Footer */ "./data/App/Footer/index.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\Footer\\index.js";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }













var Footer = function Footer(_ref) {
  var row = _ref.row,
      col = _ref.col,
      colOne = _ref.colOne,
      colTwo = _ref.colTwo,
      titleStyle = _ref.titleStyle,
      logoStyle = _ref.logoStyle,
      textStyle = _ref.textStyle,
      copyrightMenu = _ref.copyrightMenu,
      copyright = _ref.copyright;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_footer_style__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, colOne, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }), _data_App_Footer__WEBPACK_IMPORTED_MODULE_10__["default"].menuWidget.map(function (widget) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
      className: "col"
    }, col, {
      key: widget.id,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
      content: widget.title
    }, titleStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_footer_style__WEBPACK_IMPORTED_MODULE_8__["List"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 34
      },
      __self: this
    }, widget.menuItems.map(function (item) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_footer_style__WEBPACK_IMPORTED_MODULE_8__["ListItem"], {
        key: "list__item-".concat(item.id),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 36
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: item.url,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 37
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
        className: "ListItem",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        },
        __self: this
      }, item.text)));
    })));
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, colTwo, {
    className: "copyrightClass",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_UI_Logo__WEBPACK_IMPORTED_MODULE_6__["default"], {
    href: "#",
    logoSrc: _assets_image_app_logo_png__WEBPACK_IMPORTED_MODULE_9___default.a,
    title: "Agency",
    logoStyle: logoStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, copyrightMenu, {
    className: "copyrightMenu",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    content: "Help"
  }, textStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    content: "Privacy"
  }, textStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    content: "Terms"
  }, textStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, copyright, {
    className: "copyrightText",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    content: "copyright 2018 @React-Next-Landing"
  }, textStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  })))))));
}; // Footer style props


Footer.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  colOne: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  colTwo: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  titleStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  textStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  logoStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // Footer default style

Footer.defaultProps = {
  // Footer row default style
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px'
  },
  // Footer col one style
  colTwo: _defineProperty({
    width: [1, '100%'],
    mt: [0, '13px'],
    mb: ['0px', 0],
    pl: ['15px', 0],
    pt: ['35px', '55px'],
    pr: ['15px', '15px', 0],
    borderTop: '1px solid',
    borderColor: 'rgba(0,0,0,0.102)',
    flexBox: true,
    flexWrap: 'wrap'
  }, "width", ['100%']),
  // Footer col two style
  colOne: {
    width: ['100%'],
    flexBox: true,
    flexWrap: 'wrap'
  },
  // Footer col default style
  col: {
    width: ['100%', '50%', '50%', '25%', '25%'],
    pl: ['15px', '0px'],
    pr: ['15px', '0px'],
    mb: '30px'
  },
  // widget title default style
  titleStyle: {
    color: '#343d48',
    fontSize: '16px',
    fontWeight: '700'
  },
  // Default logo size
  logoStyle: {
    width: 'auto',
    mb: ['15px', 0]
  },
  // widget text default style
  textStyle: {
    color: '#20201d',
    fontSize: '14px',
    mb: '10px',
    mr: '30px'
  },
  copyrightMenu: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: [0, '40px'],
    mt: '3px',
    fontWeight: '500',
    justifyContent: 'center',
    alignItems: 'center',
    mb: ['15px', 0]
  },
  copyright: {
    ml: [0, 0, 0, 'auto', 'auto'],
    color: '#20201d',
    fontSize: '14px',
    mb: '10px',
    mt: '3px',
    fontWeight: '500',
    justifyContent: 'center',
    alignItems: 'center'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (Footer);

/***/ }),

/***/ "./containers/App/LoginModal/index.js":
/*!********************************************!*\
  !*** ./containers/App/LoginModal/index.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rc_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rc-tabs */ "rc-tabs");
/* harmony import */ var rc_tabs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rc_tabs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rc_tabs_lib_TabContent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rc-tabs/lib/TabContent */ "rc-tabs/lib/TabContent");
/* harmony import */ var rc_tabs_lib_TabContent__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rc_tabs_lib_TabContent__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rc_tabs_lib_ScrollableInkTabBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rc-tabs/lib/ScrollableInkTabBar */ "rc-tabs/lib/ScrollableInkTabBar");
/* harmony import */ var rc_tabs_lib_ScrollableInkTabBar__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rc_tabs_lib_ScrollableInkTabBar__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reusecore/src/elements/Input */ "../../node_modules/reusecore/src/elements/Input/index.js");
/* harmony import */ var reusecore_src_elements_Checkbox_index__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reusecore/src/elements/Checkbox/index */ "../../node_modules/reusecore/src/elements/Checkbox/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _loginModal_style__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./loginModal.style */ "./containers/App/LoginModal/loginModal.style.js");
/* harmony import */ var rc_tabs_assets_index_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rc-tabs/assets/index.css */ "../../node_modules/rc-tabs/assets/index.css");
/* harmony import */ var rc_tabs_assets_index_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(rc_tabs_assets_index_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_image_agency_logo_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../assets/image/agency/logo.png */ "./assets/image/agency/logo.png");
/* harmony import */ var _assets_image_agency_logo_png__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_image_agency_logo_png__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_image_agency_login_bg_jpg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../assets/image/agency/login-bg.jpg */ "./assets/image/agency/login-bg.jpg");
/* harmony import */ var _assets_image_agency_login_bg_jpg__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_image_agency_login_bg_jpg__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _assets_image_agency_google_icon_jpg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../assets/image/agency/google-icon.jpg */ "./assets/image/agency/google-icon.jpg");
/* harmony import */ var _assets_image_agency_google_icon_jpg__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_assets_image_agency_google_icon_jpg__WEBPACK_IMPORTED_MODULE_16__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\LoginModal\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



















var LoginModal = function LoginModal(_ref) {
  var row = _ref.row,
      col = _ref.col,
      btnStyle = _ref.btnStyle,
      logoStyle = _ref.logoStyle,
      titleStyle = _ref.titleStyle,
      contentWrapper = _ref.contentWrapper,
      outlineBtnStyle = _ref.outlineBtnStyle,
      descriptionStyle = _ref.descriptionStyle,
      googleButtonStyle = _ref.googleButtonStyle;

  var LoginButtonGroup = function LoginButtonGroup() {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 31
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({
      className: "default",
      title: "LOGIN"
    }, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({
      title: "Forget Password",
      variant: "textButton"
    }, outlineBtnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33
      },
      __self: this
    })));
  };

  var SignupButtonGroup = function SignupButtonGroup() {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({
      className: "default",
      title: "REGISTER"
    }, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 42
      },
      __self: this
    })));
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_loginModal_style__WEBPACK_IMPORTED_MODULE_12__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
    className: "col imageCol"
  }, col, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_11__["default"], {
    className: "patternImage",
    src: _assets_image_agency_login_bg_jpg__WEBPACK_IMPORTED_MODULE_15___default.a,
    alt: "Login Banner",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
    className: "col tabCol"
  }, col, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, contentWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_11__["default"], _extends({
    src: _assets_image_agency_logo_png__WEBPACK_IMPORTED_MODULE_14___default.a
  }, logoStyle, {
    alt: "Logo",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(rc_tabs__WEBPACK_IMPORTED_MODULE_2___default.a, {
    defaultActiveKey: "loginForm",
    renderTabBar: function renderTabBar() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(rc_tabs_lib_ScrollableInkTabBar__WEBPACK_IMPORTED_MODULE_4___default.a, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        },
        __self: this
      });
    },
    renderTabContent: function renderTabContent() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(rc_tabs_lib_TabContent__WEBPACK_IMPORTED_MODULE_3___default.a, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        __self: this
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(rc_tabs__WEBPACK_IMPORTED_MODULE_2__["TabPane"], {
    tab: "LOGIN",
    key: "loginForm",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({
    content: "Welcome Folk"
  }, titleStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({
    content: "Welcome to Mate Family. Please login with your personal account information letter."
  }, descriptionStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_11__["default"], {
      src: _assets_image_agency_google_icon_jpg__WEBPACK_IMPORTED_MODULE_16___default.a,
      alt: "Google Icon",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 66
      },
      __self: this
    }),
    title: "Sign in with Google",
    iconPosition: "left",
    className: "google-login__btn"
  }, googleButtonStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_8__["default"], {
    inputType: "email",
    isMaterial: true,
    label: "Email Address",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 73
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_8__["default"], {
    inputType: "password",
    isMaterial: true,
    label: "Password",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 74
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Checkbox_index__WEBPACK_IMPORTED_MODULE_9__["default"], {
    id: "remember",
    htmlFor: "remember",
    labelText: "Remember Me",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 75
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 80
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(LoginButtonGroup, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 81
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(rc_tabs__WEBPACK_IMPORTED_MODULE_2__["TabPane"], {
    tab: "REGISTER",
    key: "registerForm",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 84
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({
    content: "Welcome Folk"
  }, titleStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 85
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({
    content: "Welcome to Mate Family. Please login with your personal account information letter."
  }, descriptionStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_11__["default"], {
      src: _assets_image_agency_google_icon_jpg__WEBPACK_IMPORTED_MODULE_16___default.a,
      alt: "Google Icon",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 91
      },
      __self: this
    }),
    title: "Sign up with Google",
    iconPosition: "left",
    className: "google-login__btn"
  }, googleButtonStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 90
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_8__["default"], {
    isMaterial: true,
    label: "Full Name",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 97
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_8__["default"], {
    inputType: "email",
    isMaterial: true,
    label: "Email Address",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 98
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_8__["default"], {
    inputType: "password",
    isMaterial: true,
    label: "Password",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 99
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 100
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(SignupButtonGroup, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 101
    },
    __self: this
  }))))))));
}; // LoginModal style props


LoginModal.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  logoStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  titleStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  hintTextStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  contentWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  descriptionStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  googleButtonStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // LoginModal default style

LoginModal.defaultProps = {
  // Team member row default style
  row: {
    flexBox: true,
    flexWrap: 'wrap'
  },
  // Team member col default style
  col: {
    width: [1, 1 / 2]
  },
  // Default logo size
  logoStyle: {
    width: '128px',
    height: 'auto',
    ml: '15px'
  },
  // Title default style
  titleStyle: {
    fontSize: ['22px', '36px', '50px'],
    fontWeight: '400',
    color: '#20201D',
    letterSpacing: '-0.025em',
    mt: '35px',
    mb: '10px'
  },
  // Description default style
  descriptionStyle: {
    color: 'rgba(52, 61, 72, 0.8)',
    fontSize: '15px',
    lineHeight: '26px',
    letterSpacing: '-0.025em',
    mb: '23px',
    ml: '1px'
  },
  // Content wrapper style
  contentWrapper: {
    pt: ['32px', '56px'],
    pl: ['17px', '32px', '38px', '40px', '56px'],
    pr: '32px',
    pb: ['32px', '56px']
  },
  // Default button style
  btnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500'
  },
  // Outline button outline style
  outlineBtnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500',
    color: 'rgb(26, 115, 232)'
  },
  // Google button style
  googleButtonStyle: {
    bg: '#ffffff',
    color: '#343D48'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (LoginModal);

/***/ }),

/***/ "./containers/App/LoginModal/loginModal.style.js":
/*!*******************************************************!*\
  !*** ./containers/App/LoginModal/loginModal.style.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);


var LoginModalWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "loginModalstyle__LoginModalWrapper",
  componentId: "uwbrf3-0"
})(["width:80%;margin:71px auto;border-radius:5px;overflow:hidden;background-color:", ";.col{position:relative;.patternImage{position:absolute;width:100%;height:100%;object-fit:cover;}@media only screen and (max-width:991px){width:100%;&.imageCol{display:none;}}}.reusecore__button{background-color:transparent;&.default{background-color:rgb(26,115,232);transition:all 0.3s ease;&:hover{box-shadow:0px 9px 20px -5px rgba(26,115,232,0.57);}}}.rc-tabs{border:0;max-width:360px;margin:30px 0 0;@media only screen and (max-width:991px){max-width:100%;}.rc-tabs-bar{margin-left:15px;}.rc-tabs-nav-container{padding:0;.rc-tabs-tab-prev,.rc-tabs-tab-next{display:none;}.rc-tabs-nav-scroll,.rc-tabs-nav{width:100%;.rc-tabs-tab{width:50%;margin-right:0;padding:13px 0;text-align:center;}}}.rc-tabs-tabpane{padding-left:15px;padding-bottom:15px;padding-right:15px;@media (min-width:1200px){min-height:560px;}}.google-login__btn{width:100%;font-size:15px;font-weight:700;margin-bottom:45px;box-shadow:0 4px 15px rgba(0,0,0,0.1);.btn-icon{position:relative;left:-22px;img{width:21px;height:auto;}}}.reusecore__input{margin-bottom:30px;&.is-material{&.is-focus{label{color:rgb(26,115,232);top:-12px;}.highlight{background-color:rgb(26,115,232);}}}label{font-weight:400;font-size:14px;color:rgba(0,0,0,0.6);top:15px;}}.reusecore__checkbox{margin:0 0 35px;label{.reusecore__field-label{font-size:13px;font-weight:400;}}}}"], Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'));
/* harmony default export */ __webpack_exports__["default"] = (LoginModalWrapper);

/***/ }),

/***/ "./containers/App/Navbar/index.js":
/*!****************************************!*\
  !*** ./containers/App/Navbar/index.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Navbar */ "../../node_modules/reusecore/src/elements/Navbar/index.js");
/* harmony import */ var reusecore_src_elements_Drawer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Drawer */ "../../node_modules/reusecore/src/elements/Drawer/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_UI_Logo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/UI/Logo */ "../../node_modules/reusecore/src/elements/UI/Logo/index.js");
/* harmony import */ var _components_HamburgMenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../components/HamburgMenu */ "./components/HamburgMenu/index.js");
/* harmony import */ var _components_ScrollSpyMenu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/ScrollSpyMenu */ "./components/ScrollSpyMenu/index.js");
/* harmony import */ var _navbar_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./navbar.style */ "./containers/App/Navbar/navbar.style.js");
/* harmony import */ var _redq_reuse_modal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @redq/reuse-modal */ "@redq/reuse-modal");
/* harmony import */ var _redq_reuse_modal__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _SearchPanel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../SearchPanel */ "./containers/App/SearchPanel/index.js");
/* harmony import */ var _LoginModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../LoginModal */ "./containers/App/LoginModal/index.js");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-icons-kit */ "react-icons-kit");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_icons_kit_ionicons_androidClose__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-icons-kit/ionicons/androidClose */ "react-icons-kit/ionicons/androidClose");
/* harmony import */ var react_icons_kit_ionicons_androidClose__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_ionicons_androidClose__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_image_app_logo_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../assets/image/app/logo.png */ "./assets/image/app/logo.png");
/* harmony import */ var _assets_image_app_logo_png__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_logo_png__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../contexts/DrawerContext */ "./contexts/DrawerContext.js");
/* harmony import */ var _data_App_MenuItems__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../data/App/MenuItems */ "./data/App/MenuItems/index.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\Navbar\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

















 // Default close button for modal

var CloseModalButton = function CloseModalButton() {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__["default"], {
    className: "modalCloseBtn",
    variant: "fab",
    onClick: function onClick() {
      return Object(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_9__["closeModal"])();
    },
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
      className: "flaticon-plus-symbol",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 28
      },
      __self: this
    }),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  });
};

var CloseModalButtonAlt = function CloseModalButtonAlt() {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__["default"], {
    className: "modalCloseBtn alt",
    variant: "fab",
    onClick: function onClick() {
      return Object(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_9__["closeModal"])();
    },
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
      className: "flaticon-plus-symbol",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36
      },
      __self: this
    }),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    },
    __self: this
  });
};

var Navbar = function Navbar(_ref) {
  var navbarStyle = _ref.navbarStyle,
      logoStyle = _ref.logoStyle,
      buttonStyle = _ref.buttonStyle;

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(_contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_15__["DrawerContext"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch; // Search modal handler


  var handleSearchModal = function handleSearchModal() {
    Object(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_9__["openModal"])({
      config: {
        className: 'search-modal',
        disableDragging: true,
        default: {
          width: '100%',
          height: '100%',
          x: 0,
          y: 0
        }
      },
      component: _SearchPanel__WEBPACK_IMPORTED_MODULE_10__["default"],
      componentProps: {},
      closeComponent: CloseModalButtonAlt,
      closeOnClickOutside: false
    });
  }; // Authentication modal handler


  var handleLoginModal = function handleLoginModal() {
    Object(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_9__["openModal"])({
      config: {
        className: 'login-modal',
        disableDragging: true,
        default: {
          width: '100%',
          height: '100%',
          x: 0,
          y: 0
        }
      },
      component: _LoginModal__WEBPACK_IMPORTED_MODULE_11__["default"],
      componentProps: {},
      closeComponent: CloseModalButton,
      closeOnClickOutside: false
    });
  }; // Toggle drawer


  var toggleHandler = function toggleHandler() {
    dispatch({
      type: 'TOGGLE'
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Navbar__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, navbarStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 87
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_navbar_style__WEBPACK_IMPORTED_MODULE_8__["Container"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 88
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_UI_Logo__WEBPACK_IMPORTED_MODULE_5__["default"], {
    href: "#",
    logoSrc: _assets_image_app_logo_png__WEBPACK_IMPORTED_MODULE_14___default.a,
    title: "Agency",
    logoStyle: logoStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 89
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__["default"], {
    variant: "textButton",
    onClick: handleSearchModal,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
      className: "flaticon-magnifying-glass",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 99
      },
      __self: this
    }),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__["default"], {
    variant: "textButton",
    onClick: handleLoginModal,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
      className: "flaticon-user",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 104
      },
      __self: this
    }),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 101
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Drawer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    width: "420px",
    placement: "right",
    drawerHandler: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_HamburgMenu__WEBPACK_IMPORTED_MODULE_6__["default"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 109
      },
      __self: this
    }),
    open: state.isOpen,
    toggleHandler: toggleHandler,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 106
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_ScrollSpyMenu__WEBPACK_IMPORTED_MODULE_7__["default"], {
    menuItems: _data_App_MenuItems__WEBPACK_IMPORTED_MODULE_16__["default"].menuItems,
    drawerClose: true,
    offset: -100,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113
    },
    __self: this
  })))));
}; // Navbar style props


Navbar.propTypes = {
  navbarStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  logoStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  buttonStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  wrapperStyle2: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
Navbar.defaultProps = {
  navbarStyle: {
    minHeight: '70px'
  },
  logoStyle: {
    width: ['100px', '140px']
  },
  buttonStyle: {
    minHeight: '70px',
    color: '#fff'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (Navbar);

/***/ }),

/***/ "./containers/App/Navbar/navbar.style.js":
/*!***********************************************!*\
  !*** ./containers/App/Navbar/navbar.style.js ***!
  \***********************************************/
/*! exports provided: Container */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Container", function() { return Container; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "navbarstyle__Container",
  componentId: "sc-1fdxde4-0"
})(["margin-left:auto;margin-right:auto;padding-left:30px;padding-right:30px;display:flex;justify-content:space-between;width:100%;align-items:center;@media (min-width:768px){max-width:750px;}@media (min-width:992px){max-width:970px;}@media (min-width:1200px){max-width:1170px;}.menuIcons{.reusecore__button{.btn-icon{color:#fff;font-size:18px;width:auto;margin:0;@media (max-width:1100px){color:rgb(26,115,232) !important;}}}}.hamburgMenu__bar{margin-left:10px;span{background-color:#fff;@media (max-width:1100px){background-color:rgb(26,115,232) !important;}}}"]);


/***/ }),

/***/ "./containers/App/PartnerHistory/index.js":
/*!************************************************!*\
  !*** ./containers/App/PartnerHistory/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Card */ "../../node_modules/reusecore/src/elements/Card/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _partnerHistory_style__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./partnerHistory.style */ "./containers/App/PartnerHistory/partnerHistory.style.js");
/* harmony import */ var _assets_image_app_google_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../assets/image/app/google.svg */ "./assets/image/app/google.svg");
/* harmony import */ var _assets_image_app_google_svg__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_google_svg__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_image_app_apple_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../assets/image/app/apple.svg */ "./assets/image/app/apple.svg");
/* harmony import */ var _assets_image_app_apple_svg__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_apple_svg__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _assets_image_app_dribbble_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../assets/image/app/dribbble.svg */ "./assets/image/app/dribbble.svg");
/* harmony import */ var _assets_image_app_dribbble_svg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_dribbble_svg__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_image_app_mailchimp_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../assets/image/app/mailchimp.svg */ "./assets/image/app/mailchimp.svg");
/* harmony import */ var _assets_image_app_mailchimp_svg__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_mailchimp_svg__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_image_app_partner_bg_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../assets/image/app/partner-bg.png */ "./assets/image/app/partner-bg.png");
/* harmony import */ var _assets_image_app_partner_bg_png__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_partner_bg_png__WEBPACK_IMPORTED_MODULE_15__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\PartnerHistory\\index.js";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }


















var PartnerHistory = function PartnerHistory(_ref) {
  var row = _ref.row,
      col = _ref.col,
      cardStyle = _ref.cardStyle,
      title = _ref.title,
      description = _ref.description,
      btnStyle = _ref.btnStyle,
      sectionSubTitle = _ref.sectionSubTitle,
      cardArea = _ref.cardArea;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_partnerHistory_style__WEBPACK_IMPORTED_MODULE_10__["default"], {
    id: "partners",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__["default"], {
    src: _assets_image_app_partner_bg_png__WEBPACK_IMPORTED_MODULE_15___default.a,
    className: "backgroungImg",
    alt: "backgroungImg",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_9__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: "col"
  }, col, {
    style: {
      flexDirection: 'column'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_8__["default"], {
    title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, title, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 40
      },
      __self: this
    })),
    description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, description, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41
      },
      __self: this
    })),
    button: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({
      title: "WORK HISTORY"
    }, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 42
      },
      __self: this
    })),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: "col"
  }, col, cardArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_partnerHistory_style__WEBPACK_IMPORTED_MODULE_10__["CounterUpArea"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    className: "card"
  }, cardStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__["default"], {
    src: _assets_image_app_google_svg__WEBPACK_IMPORTED_MODULE_11___default.a,
    alt: "Google Inc",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], {
    content: "Google Inc",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    className: "card"
  }, cardStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__["default"], {
    src: _assets_image_app_apple_svg__WEBPACK_IMPORTED_MODULE_12___default.a,
    alt: "Apple Inc",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], {
    content: "Apple",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    className: "card"
  }, cardStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__["default"], {
    src: _assets_image_app_dribbble_svg__WEBPACK_IMPORTED_MODULE_13___default.a,
    alt: "Dribble Inc",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], {
    content: "Dribble",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    className: "card"
  }, cardStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__["default"], {
    src: _assets_image_app_mailchimp_svg__WEBPACK_IMPORTED_MODULE_14___default.a,
    alt: "MailChimp Inc",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], {
    content: "MailChimp",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    },
    __self: this
  })))))));
}; // Partner style props


PartnerHistory.propTypes = {
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  cardStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // Partner default style

PartnerHistory.defaultProps = {
  // Partner section row default style
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px'
  },
  // Partner section col default style
  col: {
    pr: '15px',
    pl: '15px',
    width: [1, 1 / 2, 1 / 2, 1 / 2, 1 / 2],
    flexBox: true,
    alignSelf: 'center'
  },
  // Card default style
  cardStyle: {
    p: '53px 40px 35px',
    borderRadius: '10px',
    boxShadow: '0px 8px 20px 0px rgba(16, 66, 97, 0.07)'
  },
  // Partner section title default style
  title: {
    content: 'Your Trusted Partner For Working Together',
    fontSize: ['24px', '26px', '30px', '36px', '48px'],
    fontWeight: '300',
    color: '#0f2137',
    letterSpacing: '-0.010em',
    mb: '20px',
    maxWidth: ['100%', '100%', '100%', '490px', '490px'],
    textAlign: ['center', 'left']
  },
  // Partner section description default style
  description: {
    content: 'You can trust us for any kind of services and some of the world class companies have also trusted us .',
    fontSize: '16px',
    color: '#343d48cc',
    lineHeight: '2.1',
    mb: '33px',
    textAlign: ['center', 'left']
  },
  sectionSubTitle: _defineProperty({
    content: 'TRUSTED PARTNERS',
    as: 'span',
    display: 'block',
    textAlign: 'left',
    fontSize: '14px',
    letterSpacing: '0.13em',
    fontWeight: '700',
    color: '#1a73e8',
    mb: '10px'
  }, "textAlign", ['center', 'left']),
  // Button default style
  btnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500'
  },
  cardArea: {
    pl: [0, 0, '40px', 0, 0]
  }
};
/* harmony default export */ __webpack_exports__["default"] = (PartnerHistory);

/***/ }),

/***/ "./containers/App/PartnerHistory/partnerHistory.style.js":
/*!***************************************************************!*\
  !*** ./containers/App/PartnerHistory/partnerHistory.style.js ***!
  \***************************************************************/
/*! exports provided: CounterUpArea, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterUpArea", function() { return CounterUpArea; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var PartnerHistoryWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "partnerHistorystyle__PartnerHistoryWrapper",
  componentId: "sc-1c8jadn-0"
})(["padding:240px 0 160px;position:relative;@media (max-width:1440px){padding:200px 0 80px;}@media screen and (max-width:1100px) and (min-width:992px){padding:80px 0 60px;}@media (max-width:990px){padding:20px 0 120px;}@media (max-width:480px){padding:0px 0 60px;}.feature__block{padding-right:90px;@media (max-width:990px){padding-right:0px;}.reusecore__button{transition:all 0.3s ease;&:hover{opacity:0.85;}}}.backgroungImg{position:absolute;top:80px;right:40px;z-index:-1;pointer-events:none;@media (max-width:1600px){right:-220px;top:80px;}@media (max-width:1100px){display:none;}}"]);
var CounterUpArea = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "partnerHistorystyle__CounterUpArea",
  componentId: "sc-1c8jadn-1"
})(["display:flex;flex-wrap:wrap;padding-left:20px;@media (max-width:990px){margin-top:50px;padding-left:0;margin-left:-25px;}@media (max-width:400px){margin-left:0px;}.card{width:calc(50% - 25px);margin-left:25px;margin-bottom:27px;display:flex;flex-direction:column;justify-content:center;align-items:center;transition:box-shadow 0.3s ease-in-out;z-index:1;background:#fff;cursor:pointer;@media (max-width:480px){padding:20px;}@media (max-width:360px){width:100%;margin-left:0;}&:hover{box-shadow:0px 16px 35px 0px rgba(16,66,97,0.1);}img{height:100px;@media (max-width:1440px){height:80px;}@media (max-width:990px){height:50px;}}p{color:#172a43;font-size:20px;line-height:40px;font-weight:500;margin-bottom:7px;margin-top:30px;@media (max-width:991px){display:none;}@media (max-width:767px){display:block;}@media (max-width:460px){font-size:16px;margin-top:5px;text-align:center;}}&:nth-child(even){position:relative;top:22px;@media (max-width:400px){top:0px;}}}"]);

/* harmony default export */ __webpack_exports__["default"] = (PartnerHistoryWrapper);

/***/ }),

/***/ "./containers/App/PaymentSection/index.js":
/*!************************************************!*\
  !*** ./containers/App/PaymentSection/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-reveal/Fade */ "react-reveal/Fade");
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_reveal_Zoom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-reveal/Zoom */ "react-reveal/Zoom");
/* harmony import */ var react_reveal_Zoom__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Zoom__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reusecore/src/elements/Card */ "../../node_modules/reusecore/src/elements/Card/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _data_Hosting_data__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../data/Hosting/data */ "./data/Hosting/data.js");
/* harmony import */ var _app_style__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../app.style */ "./containers/App/app.style.js");
/* harmony import */ var _assets_image_app_mockup_png__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../assets/image/app/mockup.png */ "./assets/image/app/mockup.png");
/* harmony import */ var _assets_image_app_mockup_png__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_mockup_png__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _assets_image_app_credit_card_png__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../assets/image/app/credit-card.png */ "./assets/image/app/credit-card.png");
/* harmony import */ var _assets_image_app_credit_card_png__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_credit_card_png__WEBPACK_IMPORTED_MODULE_17__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\PaymentSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }




















var PaymentSection = function PaymentSection(_ref) {
  var sectionWrapper = _ref.sectionWrapper,
      row = _ref.row,
      col = _ref.col,
      title = _ref.title,
      description = _ref.description,
      button = _ref.button,
      textArea = _ref.textArea,
      imageArea = _ref.imageArea,
      textAreaRow = _ref.textAreaRow,
      imageAreaRow = _ref.imageAreaRow,
      imageWrapper = _ref.imageWrapper,
      imageOne = _ref.imageOne,
      imageTwo = _ref.imageTwo,
      imageWrapperOne = _ref.imageWrapperOne,
      imageWrapperTwo = _ref.imageWrapperTwo,
      sectionSubTitle = _ref.sectionSubTitle,
      btnStyle = _ref.btnStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, sectionWrapper, {
    id: "payments",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_app_style__WEBPACK_IMPORTED_MODULE_15__["PaymentCircleShape"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_13__["default"], {
    fullWidth: true,
    noGutter: true,
    className: "control-sec-container payment",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, row, imageAreaRow, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, col, imageArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({}, imageWrapper, imageWrapperOne, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default.a, {
    left: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_11__["default"], _extends({}, imageOne, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({}, imageWrapper, imageWrapperTwo, {
    className: "cardExtraImage",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default.a, {
    right: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_11__["default"], _extends({}, imageTwo, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }))))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_13__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, row, textAreaRow, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, col, textArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({}, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_12__["default"], {
    title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_8__["default"], _extends({}, title, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 69
      },
      __self: this
    })),
    description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({}, description, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 70
      },
      __self: this
    })),
    button: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "#",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 72
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 73
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_9__["default"], _extends({}, button, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 74
      },
      __self: this
    })))),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 68
    },
    __self: this
  })))));
};

PaymentSection.propTypes = {
  sectionWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  btnStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
PaymentSection.defaultProps = {
  sectionWrapper: {
    as: 'section',
    pt: ['20px', '40px', '40px', '80px', '80px'],
    pb: ['80px', '80px', '80px', '180px', '280px']
  },
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px'
  },
  textAreaRow: {
    flexDirection: 'row-reverse'
  },
  col: {
    pr: '15px',
    pl: '15px'
  },
  textArea: {
    width: [1, 1, '45%', '45%', '45%'],
    zIndex: '1'
  },
  imageArea: {
    width: [0, 0, '52%', '45%', '45%'],
    flexBox: true
  },
  imageWrapper: {
    boxShadow: 'none'
  },
  imageWrapperOne: {
    pointerEvents: 'none'
  },
  imageWrapperTwo: {
    alignSelf: 'flex-start',
    mt: ['0px', '0px', '40px', '50px', '90px'],
    ml: ['-250px', '-250px', '-180px', '-220px', '-420px'],
    pointerEvents: 'none'
  },
  imageOne: {
    src: "".concat(_assets_image_app_mockup_png__WEBPACK_IMPORTED_MODULE_16___default.a),
    alt: 'Info Image One'
  },
  imageTwo: {
    src: "".concat(_assets_image_app_credit_card_png__WEBPACK_IMPORTED_MODULE_17___default.a),
    alt: 'Info Image Two'
  },
  sectionSubTitle: {
    content: 'PAYMENT SECURITY',
    as: 'span',
    display: 'block',
    textAlign: ['center', 'left'],
    fontSize: '14px',
    letterSpacing: '0.11em',
    fontWeight: '700',
    color: '#1a73e8',
    textTransform: 'uppercase',
    mb: '10px'
  },
  title: {
    content: 'Secure Payment and Transaction System With #1 ranking',
    fontSize: ['24px', '26px', '30px', '36px', '48px'],
    fontWeight: '300',
    color: '#0f2137',
    letterSpacing: '-0.010em',
    mb: '20px',
    maxWidth: ['100%', '100%', '100%', '420px', '420px'],
    textAlign: ['center', 'left']
  },
  description: {
    content: 'Security of our customer is our basic priority and we are best at it . So no need to worry about online payment and Transaction System .',
    fontSize: '16px',
    color: '#343d48cc',
    lineHeight: '2.1',
    mb: '33px',
    maxWidth: ['100%', '100%', '100%', '440px', '440px'],
    textAlign: ['center', 'left']
  },
  button: {
    title: 'HOW IT WORKS',
    type: 'button',
    fontSize: '14px',
    fontWeight: '600',
    color: '#fff',
    borderRadius: '4px',
    pl: '22px',
    pr: '22px',
    colors: 'primaryWithBg'
  },
  btnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (PaymentSection);

/***/ }),

/***/ "./containers/App/SearchPanel/index.js":
/*!*********************************************!*\
  !*** ./containers/App/SearchPanel/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Input */ "../../node_modules/reusecore/src/elements/Input/index.js");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons-kit */ "react-icons-kit");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_kit_ionicons_iosSearchStrong__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-icons-kit/ionicons/iosSearchStrong */ "react-icons-kit/ionicons/iosSearchStrong");
/* harmony import */ var react_icons_kit_ionicons_iosSearchStrong__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_ionicons_iosSearchStrong__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _searchPanel_style__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./searchPanel.style */ "./containers/App/SearchPanel/searchPanel.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\SearchPanel\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }










var SearchPanel = function SearchPanel(_ref) {
  var titleStyle = _ref.titleStyle,
      hintStyle = _ref.hintStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_searchPanel_style__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    content: "Search Panel"
  }, titleStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Input__WEBPACK_IMPORTED_MODULE_4__["default"], {
    inputType: "email",
    iconPosition: "right",
    placeholder: "Type what you want",
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_kit__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
      icon: react_icons_kit_ionicons_iosSearchStrong__WEBPACK_IMPORTED_MODULE_6__["iosSearchStrong"],
      __source: {
        fileName: _jsxFileName,
        lineNumber: 18
      },
      __self: this
    }),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    content: "Example: \u201CApp Template\u201D \u201CApplication\u201D"
  }, hintStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    },
    __self: this
  })));
}; // SearchPanel style props


SearchPanel.propTypes = {
  titleStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  hintTextStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // SearchPanel default style

SearchPanel.defaultProps = {
  // Title default style
  titleStyle: {
    fontSize: ['24px', '30px'],
    fontWeight: '400',
    color: '#20201D',
    letterSpacing: '-0.025em',
    mb: '30px'
  },
  // hint default style
  hintStyle: {
    fontSize: '15px',
    fontWeight: '400',
    color: 'rgba(32, 32, 29, 0.55)',
    letterSpacing: '-0.025em',
    mt: '17px',
    ml: ['15px', '30px'],
    mb: '0'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (SearchPanel);

/***/ }),

/***/ "./containers/App/SearchPanel/searchPanel.style.js":
/*!*********************************************************!*\
  !*** ./containers/App/SearchPanel/searchPanel.style.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var SearchPanelWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "searchPanelstyle__SearchPanelWrapper",
  componentId: "rhsrma-0"
})(["max-width:100%;width:600px;margin:0 auto;padding:0 15px;.reusecore__input{.field-wrapper{input{border:0;border-radius:5px;height:70px;box-shadow:0 3px 20px rgba(35,49,90,0.08);color:#20201d;font-size:16px;font-weight:400;padding-left:39px;padding-right:80px;&:placholder{color:rgba(32,32,29,0.5);}}.input-icon{width:80px;height:100%;> div{svg{width:28px;height:28px;path{fill:#20201d;}}}}}}"]);
/* harmony default export */ __webpack_exports__["default"] = (SearchPanelWrapper);

/***/ }),

/***/ "./containers/App/Testimonial/index.js":
/*!*********************************************!*\
  !*** ./containers/App/Testimonial/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reusecore/src/elements/Card */ "../../node_modules/reusecore/src/elements/Card/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-icons-kit */ "react-icons-kit");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _particles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../particles */ "./containers/App/particles/index.js");
/* harmony import */ var _data_Hosting_data__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../data/Hosting/data */ "./data/Hosting/data.js");
/* harmony import */ var react_image_gallery__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-image-gallery */ "react-image-gallery");
/* harmony import */ var react_image_gallery__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_image_gallery__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-image-gallery/styles/css/image-gallery.css */ "../../node_modules/react-image-gallery/styles/css/image-gallery.css");
/* harmony import */ var react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _data_App_TestimonialSlider__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../data/App/TestimonialSlider */ "./data/App/TestimonialSlider/index.js");
/* harmony import */ var _sliderDescription__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../sliderDescription */ "./containers/App/sliderDescription/index.js");
/* harmony import */ var _assets_image_app_6_png__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../assets/image/app/6.png */ "./assets/image/app/6.png");
/* harmony import */ var _assets_image_app_6_png__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_6_png__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _assets_image_app_2_jpg__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../assets/image/app/2.jpg */ "./assets/image/app/2.jpg");
/* harmony import */ var _assets_image_app_2_jpg__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_2_jpg__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _assets_image_app_5_jpg__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../assets/image/app/5.jpg */ "./assets/image/app/5.jpg");
/* harmony import */ var _assets_image_app_5_jpg__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_5_jpg__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _assets_image_app_testi_jpg__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../../assets/image/app/testi.jpg */ "./assets/image/app/testi.jpg");
/* harmony import */ var _assets_image_app_testi_jpg__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_testi_jpg__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _assets_image_app_1_jpeg__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../assets/image/app/1.jpeg */ "./assets/image/app/1.jpeg");
/* harmony import */ var _assets_image_app_1_jpeg__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_1_jpeg__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var react_icons_kit_ikons_arrow_left__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! react-icons-kit/ikons/arrow_left */ "react-icons-kit/ikons/arrow_left");
/* harmony import */ var react_icons_kit_ikons_arrow_left__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_ikons_arrow_left__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var react_icons_kit_ikons_arrow_right__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! react-icons-kit/ikons/arrow_right */ "react-icons-kit/ikons/arrow_right");
/* harmony import */ var react_icons_kit_ikons_arrow_right__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_ikons_arrow_right__WEBPACK_IMPORTED_MODULE_25__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\Testimonial\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



























var images = [{
  thumbnail: "".concat(_assets_image_app_6_png__WEBPACK_IMPORTED_MODULE_19___default.a),
  description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_sliderDescription__WEBPACK_IMPORTED_MODULE_18__["default"], {
    data: _data_App_TestimonialSlider__WEBPACK_IMPORTED_MODULE_17__["default"].testimonials[0],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    },
    __self: undefined
  })
}, {
  thumbnail: "".concat(_assets_image_app_2_jpg__WEBPACK_IMPORTED_MODULE_20___default.a),
  description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_sliderDescription__WEBPACK_IMPORTED_MODULE_18__["default"], {
    data: _data_App_TestimonialSlider__WEBPACK_IMPORTED_MODULE_17__["default"].testimonials[1],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    },
    __self: undefined
  })
}, {
  thumbnail: "".concat(_assets_image_app_5_jpg__WEBPACK_IMPORTED_MODULE_21___default.a),
  description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_sliderDescription__WEBPACK_IMPORTED_MODULE_18__["default"], {
    data: _data_App_TestimonialSlider__WEBPACK_IMPORTED_MODULE_17__["default"].testimonials[2],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    },
    __self: undefined
  })
}, {
  thumbnail: "".concat(_assets_image_app_testi_jpg__WEBPACK_IMPORTED_MODULE_22___default.a),
  description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_sliderDescription__WEBPACK_IMPORTED_MODULE_18__["default"], {
    data: _data_App_TestimonialSlider__WEBPACK_IMPORTED_MODULE_17__["default"].testimonials[3],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: undefined
  })
}, {
  thumbnail: "".concat(_assets_image_app_1_jpeg__WEBPACK_IMPORTED_MODULE_23___default.a),
  description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_sliderDescription__WEBPACK_IMPORTED_MODULE_18__["default"], {
    data: _data_App_TestimonialSlider__WEBPACK_IMPORTED_MODULE_17__["default"].testimonials[4],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: undefined
  })
}];

var TestimonialSection = function TestimonialSection(_ref) {
  var sectionWrapper = _ref.sectionWrapper,
      row = _ref.row,
      sectionSubTitle = _ref.sectionSubTitle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, sectionWrapper, {
    className: "testimonialSlider",
    id: "testimonialSection",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_12__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_4__["default"], {
    className: "testimonialDesWrapper",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_image_gallery__WEBPACK_IMPORTED_MODULE_15___default.a, {
    items: images,
    originalClass: "Testimonial-img",
    showPlayButton: false,
    showFullscreenButton: false,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    },
    __self: this
  }))));
};

TestimonialSection.propTypes = {
  sectionWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
TestimonialSection.defaultProps = {
  sectionWrapper: {
    as: 'section',
    pt: '0px',
    pb: ['20px', '80px', '0px', '80px', '80px']
  },
  sectionSubTitle: {
    content: 'CLIENT TESTIMONIAL',
    as: 'span',
    display: 'block',
    textAlign: ['center', 'left'],
    fontSize: '14px',
    letterSpacing: '0.11em',
    fontWeight: '700',
    color: '#1a73e8',
    textTransform: 'uppercase',
    mb: '10px'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (TestimonialSection);

/***/ }),

/***/ "./containers/App/app.style.js":
/*!*************************************!*\
  !*** ./containers/App/app.style.js ***!
  \*************************************/
/*! exports provided: GlobalStyle, AppWrapper, BannerSquareShape, BannerCircleShape, PaymentCircleShape, ConditionWrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlobalStyle", function() { return GlobalStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppWrapper", function() { return AppWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BannerSquareShape", function() { return BannerSquareShape; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BannerCircleShape", function() { return BannerCircleShape; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentCircleShape", function() { return PaymentCircleShape; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConditionWrapper", function() { return ConditionWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_image_app_substract_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../assets/image/app/substract.png */ "./assets/image/app/substract.png");
/* harmony import */ var _assets_image_app_substract_png__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_substract_png__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_image_app_substract_hover_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/image/app/substract-hover.png */ "./assets/image/app/substract-hover.png");
/* harmony import */ var _assets_image_app_substract_hover_png__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_substract_hover_png__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _assets_image_app_pattern_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../assets/image/app/pattern.png */ "./assets/image/app/pattern.png");
/* harmony import */ var _assets_image_app_pattern_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_pattern_png__WEBPACK_IMPORTED_MODULE_4__);
function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  body {\n    font-family: 'Open Sans', sans-serif;\n  }\n\n  h1,\n  h2,\n  h3,\n  h4,\n  h5,\n  h6 {\n    font-family: 'Open Sans', sans-serif;\n  }\n\n  section{\n    position: relative;\n  }\n\n    .drawer {\n      .drawer-content-wrapper {\n        @media only screen and (max-width: 480px) {\n          width: 320px !important;\n        }\n        .reusecore-drawer__close {\n          position: absolute;\n          top: 20px;\n          right: 30px;\n          > button {\n            box-shadow: 0px 8px 38px 0px rgba(16, 172, 132, 0.5);\n            transition: all 0.3s ease;\n            svg {\n              width: 22px;\n              height: 22px;\n            }\n            &:hover {\n              opacity: 0.9;\n            }\n          }\n        }\n        .scrollspy__menu {\n          padding: 60px 71px;\n\n          li {\n            margin: 35px 0;\n            a {\n              display: block;\n              color: #20201d;\n              font-size: 24px;\n              font-weight: 400;\n              transition: all 0.3s ease;\n              @media only screen and (max-width: 480px) {\n                font-size: 21px;\n              }\n              &:hover {\n                color: #1a73e8;\n              }\n            }\n            &.is-current {\n              a {\n                color: #1a73e8;\n                position: relative;\n                &:before {\n                  content: '';\n                  display: block;\n                  width: 8px;\n                  height: 8px;\n                  border-radius: 50%;\n                  background-color: #1a73e8;\n                  position: absolute;\n                  top: calc(50% - 8px / 2);\n                  left: -20px;\n                }\n              }\n            }\n          }\n        }\n      }\n    }\n\n    /* Modal default style */\n    .reuseModalOverlay {\n      z-index: 99999;\n    }\n\n    button.modalCloseBtn {\n      position: fixed;\n      z-index: 999991;\n      background-color: transparent;\n      color: ", ";\n      top: 10px;\n      right: 10px;\n\n      @media(max-width: 460px){\n        top: 0;\n        right: 0;\n      }\n\n      span.btn-icon {\n        font-size: 24px;\n        transform: rotate(45deg);\n      }\n\n      &.alt {\n        background-color: ", ";\n        border-radius: 50%;\n        z-index: 999999;\n        padding: 0;\n        box-shadow: 0 8px 38px rgba(26, 115, 232, 0.5);\n        transition: all 0.3s ease;\n        top: 25px;\n        right: 30px;\n        span.btn-icon {\n          font-size: 20px;\n        }\n        &:hover {\n          opacity: 0.88;\n        }\n      }\n    }\n\n    .reuseModalHolder {\n      border: 0;\n      background-color: transparent;\n\n      \n\n      &.search-modal,\n      &.video-modal {\n        background-color: rgba(255, 255, 255, 0.96);\n        overflow-y: auto;\n\n        .innerRndComponent {\n          display: flex;\n          align-items: center;\n          justify-content: center;\n\n          iframe {\n            max-width: 700px;\n            max-height: 380px;\n            width: 100%;\n            height: 100%;\n            border-radius: 5px;\n          }\n        }\n      }\n\n      &.demo_switcher_modal {\n        border: 0;\n        background-color: rgba(16, 30, 77, 0.8);\n        .innerRndComponent {\n          border-radius: 8px;\n        }\n      }\n\n      &.video-modal {\n        background-color: transparent;\n      }\n\n      .innerRndComponent {\n        padding-right: 0;\n      }\n    }\n\n    .reuseModalCloseBtn {\n      cursor: pointer;\n    }\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }






var GlobalStyle = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["createGlobalStyle"])(_templateObject(), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#1a73e8'));
var AppWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "appstyle__AppWrapper",
  componentId: "sc-1bch034-0"
})(["position:relative;@media (max-width:1099px){overflow:hidden;}.button__wrapper{@media only screen and (max-width:480px){text-align:center;}}.reusecore__navbar{width:100%;left:0;top:0;transition:all 0.3s ease;.reusecore__button{.btn-icon{color:", ";font-size:18px;@media only screen and (max-width:1100px){color:", ";}@media only screen and (max-width:420px){font-size:14px;}}&:hover{background:transparent;box-shadow:none;}}.button__wrapper{@media only screen and (max-width:480px){text-align:center;}}.hamburgMenu__bar{margin-left:8px;@media only screen and (max-width:420px){width:40px;}> span{background-color:", ";@media only screen and (max-width:990px){background-color:", ";}}}}.sticky-nav-active{.reusecore__navbar{background-color:", ";box-shadow:0 0 20px rgba(0,0,0,0.1);padding:5px 15px;transition:all 0.2s ease;@media (max-width:1100px){padding:10px 15px 10px;}@media (max-width:991px){padding:10px 15px 10px;}@media (max-width:767px){padding:20px 15px 10px;}@media (max-width:480px){padding:5px 15px;}.reusecore__button{.btn-icon{color:", ";}}.hamburgMenu__bar > span{background-color:", ";}}}.particle{position:absolute;width:100%;height:100%;top:0;left:0;pointer-events:none;@media (max-width:990px){display:none;}}.reusecore__button{transition:all 0.3s ease;cursor:pointer;.btn-icon{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;color:rgb(26,115,232);width:35px;}&:hover{box-shadow:0px 9px 20px -5px rgba(26,115,232,0.57);background-color:rgb(26,115,232);cursor:pointer;}&.withoutBg{@media (max-width:460px){margin-top:20px;margin-left:0;border:1px solid #1a73e8;min-width:auto;}&:hover{opacity:0.85;background-color:rgb(255,255,255) !important;cursor:pointer;box-shadow:none !important;}}}.control-sec-container{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);@media (max-width:767px){position:relative;top:0%;left:0%;transform:none;display:none;}.particle{position:absolute;width:50%;height:100%;top:0;left:0;}&.payment{.particle{z-index:-1;}}}.testimonialSlider{.image-gallery-content{display:flex;flex-wrap:wrap;align-items:center;@media (max-width:767px){flex-direction:column;}.image-gallery-slide-wrapper{max-width:60%;width:60%;display:flex;flex-wrap:wrap;flex-direction:column-reverse;@media screen and (max-width:1100px) and (min-width:992px){max-width:56%;width:56%;}@media (max-width:991px){max-width:50%;width:50%;}@media (max-width:767px){max-width:100%;width:100%;}> span{display:flex;@media (max-width:480px){justify-content:center;}.image-gallery-left-nav,.image-gallery-right-nav{position:relative;top:0;transform:none;margin-top:0;}.image-gallery-left-nav{}.image-gallery-right-nav{margin-left:10px;}}.image-gallery-swipe{.image-gallery-slide{.image-gallery-description{background:transparent;bottom:0px;color:#000;position:relative;.testimonialDes{box-sizing:border-box;margin-top:-10px;max-width:550px;font-size:36px;line-height:50px;color:#0f2137;font-weight:300;-webkit-letter-spacing:-0.01em;-moz-letter-spacing:-0.01em;-ms-letter-spacing:-0.01em;letter-spacing:-0.01em;@media (max-width:991px){font-size:30px;line-height:40px;max-width:100%;}@media (max-width:768px){font-size:24px;line-height:36px;}@media (max-width:480px){font-size:20px;text-align:center;}&::before{content:'CUSTOMER OPINIONS';box-sizing:border-box;margin-bottom:10px;margin-top:0px;font-size:14px;color:#1a73e8;display:block;font-weight:700;text-align:left;-webkit-letter-spacing:0.11em;-moz-letter-spacing:0.11em;-ms-letter-spacing:0.11em;letter-spacing:0.11em;@media (max-width:480px){text-align:center;}}}.testimonialDetails{@media (max-width:480px){text-align:center;}.testimonialName{font-size:18px;line-height:33px;color:#343d48;font-weight:700;margin-bottom:-3px;}.testimonialDesignation{font-size:16px;line-height:33px;color:#343d48;font-weight:400;opacity:0.8;}}}}}.image-gallery-left-nav{padding:0;font-size:0;margin-top:-15px;width:15px;height:2px;transition:width 0.25s ease-in-out;background-image:url(", ");width:20px;height:30px;background-repeat-x:repeat;background-position:center;background-size:contain;&:hover{width:35px;background-image:url(", ");&::before{background-color:#1a73e8;}&::after{background-color:#1a73e8;}}&::before{top:11px;content:'';width:10px;height:2px;background-color:#343d48;display:block;position:absolute;transform:rotate(-36deg);transition:inherit;left:0;}&::after{content:'';width:10px;height:2px;background-color:#343d48;display:block;position:absolute;bottom:11px;transform:rotate(36deg);transition:inherit;left:0;}}.image-gallery-right-nav{padding:0;font-size:0;margin-top:-15px;width:15px;height:2px;transition:all 0.25s ease-in-out;background-image:url(", ");width:30px;height:30px;background-repeat-x:repeat;background-position:center;background-size:contain;&:hover{&::before{background-color:#1a73e8;}&::after{background-color:#1a73e8;}}&::before{top:11px;content:'';width:10px;height:2px;background-color:#1a73e8;display:block;position:absolute;transform:rotate(36deg);transition:inherit;left:20px;}&::after{content:'';width:10px;height:2px;background-color:#1a73e8;display:block;position:absolute;bottom:11px;transform:rotate(-36deg);transition:inherit;left:20px;}}}.image-gallery-thumbnails-wrapper{max-width:40%;height:520px;width:40%;@media screen and (max-width:1100px) and (min-width:992px){padding-left:25px;overflow:hidden;}@media (max-width:991px){padding-left:0px;overflow:hidden;max-width:50%;width:50%;}@media (max-width:767px){max-width:100%;width:100%;height:auto;margin-top:50px;overflow:hidden;}.image-gallery-thumbnails{overflow:initial;padding-left:30px;@media (max-width:991px){padding-left:0px;}@media (max-width:767px){overflow:hidden;}}.image-gallery-thumbnails-container{position:relative;height:520px;@media screen and (max-width:1100px) and (min-width:992px){margin-left:-20px;margin-top:15px;}@media (max-width:991px){margin-left:-25px;}@media (max-width:767px){height:auto;margin-left:0px;}img{border-radius:50%;height:100%;width:100%;@media (max-width:768px){box-shadow:none;}@media (max-width:991px){width:70px;height:70px;}@media (max-width:480px){width:70px;height:70px;}}.image-gallery-thumbnail:nth-child(1){position:absolute;top:150px;left:0;width:120px;height:120px;@media (max-width:991px){position:absolute;top:220px;left:80px;width:120px;height:120px;img{width:80px;height:80px;}}@media (max-width:767px){position:relative;top:0;left:0;width:calc(33.33% - 30px);height:auto;margin-right:30px;margin-left:10px;}img{}}.image-gallery-thumbnail:nth-child(2){position:absolute;top:0;left:180px;width:100px;height:100px;@media (max-width:991px){position:absolute;top:110px;left:160px;width:100px;height:100px;}@media (max-width:767px){position:relative;top:0;width:calc(33.33% - 30px);height:auto;margin-right:30px;left:0;}}.image-gallery-thumbnail:nth-child(3){position:absolute;top:160px;left:250px;width:70px;height:70px;@media screen and (max-width:1100px) and (min-width:992px){position:absolute;top:180px;left:220px;width:70px;height:70px;}@media (max-width:991px){position:absolute;top:200px;left:272px;width:70px;height:70px;}@media (max-width:767px){position:relative;top:0;width:calc(33.33% - 30px);height:auto;margin-right:30px;left:0;}}.image-gallery-thumbnail:nth-child(4){position:absolute;bottom:100px;left:200px;width:90px;height:90px;@media (max-width:991px){position:absolute;bottom:100px;left:240px;width:90px;height:90px;}@media (max-width:767px){position:relative;top:0;width:calc(33.33% - 30px);height:auto;margin-right:30px;left:0;}}.image-gallery-thumbnail:nth-child(5){position:absolute;bottom:20px;left:20px;width:105px;height:105px;@media screen and (max-width:1100px) and (min-width:992px){position:absolute;bottom:50px;left:20px;width:105px;height:105px;}@media (max-width:991px){position:absolute;bottom:40px;left:115px;width:105px;height:105px;}@media (max-width:767px){position:relative;top:0;width:calc(33.33% - 30px);height:auto;margin-right:30px;left:0;}}.image-gallery-thumbnail{transition:all 0.35s ease;border:0;border-radius:50%;.image-gallery-thumbnail-inner{width:100%;height:100%;}&.active{border:0;transform:scale(1.3);box-shadow:0px 18px 68px 0px rgba(22,30,54,0.25);@media (max-width:1100px){box-shadow:none;}.image-gallery-thumbnail-inner{@keyframes pulse{0%{transform:translateX(-50%) translateY(-50%) translateZ(0) scale(1);opacity:1;}100%{transform:translateX(-50%) translateY(-50%) translateZ(0) scale(1.5);opacity:0;}}@media (max-width:991px){@keyframes pulse{0%{transform:translateX(-50%) translateY(-50%) translateZ(0) scale(1);opacity:0;}100%{transform:translateX(-50%) translateY(-50%) translateZ(0) scale(1.2);opacity:0;}}}&::before{content:'';position:absolute;display:block;width:100%;height:100%;box-shadow:0 0 0 0.8px rgba(0,0,0,0.1);border-radius:50%;top:50%;left:50%;opacity:0;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);animation:pulse 2.2s ease-out infinite;backface-visibility:hidden;pointer-events:none;}&::after{content:'';position:absolute;display:block;width:100%;height:100%;box-shadow:0 0 0 0.8px rgba(0,0,0,0.1);border-radius:50%;top:50%;left:50%;opacity:0;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);animation:pulse 2.2s ease-out infinite;backface-visibility:hidden;pointer-events:none;animation-delay:1s;}}img{position:relative;@media (max-width:768px){margin:10px 0;}}}}}}}}.cardExtraImage{@media screen and (max-width:1440px) and (min-width:1100px){margin-left:-270px;margin-top:50px;}}"], Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#1a73e8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#1a73e8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#1a73e8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#1a73e8'), _assets_image_app_substract_png__WEBPACK_IMPORTED_MODULE_2___default.a, _assets_image_app_substract_hover_png__WEBPACK_IMPORTED_MODULE_3___default.a, _assets_image_app_substract_hover_png__WEBPACK_IMPORTED_MODULE_3___default.a);
var BannerSquareShape = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "appstyle__BannerSquareShape",
  componentId: "sc-1bch034-1"
})(["width:980px;height:1110px;background:#1a73e8;border-radius:50px;-webkit-transform:rotate(105deg);-ms-transform:rotate(105deg);transform:rotate(107deg);position:absolute;left:58%;top:-28%;z-index:-1;pointer-events:none;background-image:url(", ");@media (max-width:1300px){width:870px;height:1000px;transform:rotate(103deg);position:absolute;left:64%;}@media (max-width:1100px){display:none;}"], _assets_image_app_pattern_png__WEBPACK_IMPORTED_MODULE_4___default.a);
var BannerCircleShape = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "appstyle__BannerCircleShape",
  componentId: "sc-1bch034-2"
})(["width:500px;height:500px;background:#ffc845;border-radius:50%;position:absolute;left:55%;top:47%;z-index:-1;transform:translateY(-50%);pointer-events:none;@media (max-width:1300px){width:400px;height:400px;left:63%;}@media (max-width:1100px){width:400px;height:400px;left:60%;}@media (max-width:991px){width:345px;height:345px;left:54%;}@media (max-width:767px){display:none;}"]);
var PaymentCircleShape = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "appstyle__PaymentCircleShape",
  componentId: "sc-1bch034-3"
})(["width:700px;height:700px;background:#ffc845;border-radius:50%;position:absolute;left:5%;top:47%;z-index:-1;transform:translateY(-50%);pointer-events:none;@media (max-width:1440px){width:550px;height:550px;}@media (max-width:1100px){width:450px;height:450px;}@media (max-width:991px){width:350px;height:350px;}@media (max-width:767px){display:none;}"]);
var ConditionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "appstyle__ConditionWrapper",
  componentId: "sc-1bch034-4"
})(["position:relative;"]);


/***/ }),

/***/ "./containers/App/particles/index.js":
/*!*******************************************!*\
  !*** ./containers/App/particles/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_particles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-particles-js */ "react-particles-js");
/* harmony import */ var react_particles_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_particles_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_image_app_img_1_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../assets/image/app/img-1.png */ "./assets/image/app/img-1.png");
/* harmony import */ var _assets_image_app_img_1_png__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_img_1_png__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_image_app_img_3_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../assets/image/app/img-3.png */ "./assets/image/app/img-3.png");
/* harmony import */ var _assets_image_app_img_3_png__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_img_3_png__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _assets_image_app_img_4_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../assets/image/app/img-4.png */ "./assets/image/app/img-4.png");
/* harmony import */ var _assets_image_app_img_4_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_img_4_png__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_image_app_img_5_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../assets/image/app/img-5.png */ "./assets/image/app/img-5.png");
/* harmony import */ var _assets_image_app_img_5_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_img_5_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_image_app_img_6_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../assets/image/app/img-6.png */ "./assets/image/app/img-6.png");
/* harmony import */ var _assets_image_app_img_6_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_img_6_png__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_image_app_img_8_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../assets/image/app/img-8.png */ "./assets/image/app/img-8.png");
/* harmony import */ var _assets_image_app_img_8_png__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_img_8_png__WEBPACK_IMPORTED_MODULE_7__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\particles\\index.js";









var ParticlesComponent = function ParticlesComponent() {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_particles_js__WEBPACK_IMPORTED_MODULE_1___default.a, {
    className: "particle",
    params: {
      particles: {
        number: {
          value: 30,
          density: {
            enable: true,
            value_area: 1599.4515164189945
          }
        },
        shape: {
          type: ['images'],
          images: [{
            src: "".concat(_assets_image_app_img_1_png__WEBPACK_IMPORTED_MODULE_2___default.a),
            width: 50,
            height: 53
          }, {
            src: "".concat(_assets_image_app_img_3_png__WEBPACK_IMPORTED_MODULE_3___default.a),
            width: 50,
            height: 53
          }, {
            src: "".concat(_assets_image_app_img_4_png__WEBPACK_IMPORTED_MODULE_4___default.a),
            width: 20,
            height: 23
          }, {
            src: "".concat(_assets_image_app_img_5_png__WEBPACK_IMPORTED_MODULE_5___default.a),
            width: 20,
            height: 23
          }, {
            src: "".concat(_assets_image_app_img_6_png__WEBPACK_IMPORTED_MODULE_6___default.a),
            width: 50,
            height: 53
          }, {
            src: "".concat(_assets_image_app_img_8_png__WEBPACK_IMPORTED_MODULE_7___default.a),
            width: 50,
            height: 53
          }]
        },
        opacity: {
          value: 0.17626369048095938,
          random: false,
          anim: {
            enable: false,
            speed: 1,
            opacity_min: 0.1,
            sync: false
          }
        },
        size: {
          value: 11,
          random: true,
          anim: {
            enable: false,
            speed: 40,
            size_min: 0.8,
            sync: false
          }
        },
        line_linked: {
          enable: false,
          distance: 150,
          color: '#ffffff',
          opacity: 0.4,
          width: 1
        },
        move: {
          enable: true,
          speed: 3,
          direction: 'none',
          random: false,
          straight: false,
          out_mode: 'out',
          bounce: false,
          attract: {
            enable: false,
            rotateX: 600,
            rotateY: 1200
          }
        }
      },
      interactivity: {
        detect_on: 'canvas',
        events: {
          onhover: {
            enable: true,
            mode: 'repulse'
          },
          onclick: {
            enable: true,
            mode: 'push'
          },
          resize: true
        },
        modes: {
          grab: {
            distance: 400,
            line_linked: {
              opacity: 1
            }
          },
          bubble: {
            distance: 400,
            size: 40,
            duration: 2,
            opacity: 8,
            speed: 3
          },
          repulse: {
            distance: 200,
            duration: 0.4
          },
          push: {
            particles_nb: 4
          },
          remove: {
            particles_nb: 2
          }
        }
      },
      retina_detect: true
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    },
    __self: this
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (ParticlesComponent);

/***/ }),

/***/ "./containers/App/sliderDescription/index.js":
/*!***************************************************!*\
  !*** ./containers/App/sliderDescription/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\App\\sliderDescription\\index.js";


var sliderDes = function sliderDes(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
    className: "testimonialDes",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 5
    },
    __self: this
  }, props.data.description), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "testimonialDetails",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
    className: "testimonialName",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 7
    },
    __self: this
  }, props.data.name), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "testimonialDesignation",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 8
    },
    __self: this
  }, props.data.designation)));
};

/* harmony default export */ __webpack_exports__["default"] = (sliderDes);

/***/ }),

/***/ "./contexts/DrawerContext.js":
/*!***********************************!*\
  !*** ./contexts/DrawerContext.js ***!
  \***********************************/
/*! exports provided: DrawerContext, DrawerProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrawerContext", function() { return DrawerContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrawerProvider", function() { return DrawerProvider; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\contexts\\DrawerContext.js";

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var initialState = {
  isOpen: false
};

function reducer(state, action) {
  switch (action.type) {
    case 'TOGGLE':
      return _objectSpread({}, state, {
        isOpen: !state.isOpen
      });

    default:
      return state;
  }
}

var DrawerContext = react__WEBPACK_IMPORTED_MODULE_0___default.a.createContext({});
var DrawerProvider = function DrawerProvider(_ref) {
  var children = _ref.children;

  var _useReducer = Object(react__WEBPACK_IMPORTED_MODULE_0__["useReducer"])(reducer, initialState),
      _useReducer2 = _slicedToArray(_useReducer, 2),
      state = _useReducer2[0],
      dispatch = _useReducer2[1];

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(DrawerContext.Provider, {
    value: {
      state: state,
      dispatch: dispatch
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    },
    __self: this
  }, children);
};

/***/ }),

/***/ "./data/App/FeatureSection/index.js":
/*!******************************************!*\
  !*** ./data/App/FeatureSection/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var data = {
  features: [{
    id: 1,
    icon: 'flaticon-atom',
    title: 'App Development',
    description: 'If you have to develop a mobile app, this is the most appropriate time. '
  }, {
    id: 2,
    icon: 'flaticon-trophy',
    title: 'UI/UX Design',
    description: 'We provide the best UI/UX Design by following the latest trends of the market.'
  }, {
    id: 3,
    icon: 'flaticon-conversation',
    title: 'Wireframing Task',
    description: ' We respect our customer opinions and deals with them. '
  }]
};
/* harmony default export */ __webpack_exports__["default"] = (data);

/***/ }),

/***/ "./data/App/FeatureSliderTwo/index.js":
/*!********************************************!*\
  !*** ./data/App/FeatureSliderTwo/index.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _assets_image_app_6_svg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../assets/image/app/6.svg */ "./assets/image/app/6.svg");
/* harmony import */ var _assets_image_app_6_svg__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_6_svg__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_image_app_1_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../assets/image/app/1.svg */ "./assets/image/app/1.svg");
/* harmony import */ var _assets_image_app_1_svg__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_1_svg__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_image_app_2_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../assets/image/app/2.svg */ "./assets/image/app/2.svg");
/* harmony import */ var _assets_image_app_2_svg__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_2_svg__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_image_app_3_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../assets/image/app/3.svg */ "./assets/image/app/3.svg");
/* harmony import */ var _assets_image_app_3_svg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_3_svg__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _assets_image_app_4_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../assets/image/app/4.svg */ "./assets/image/app/4.svg");
/* harmony import */ var _assets_image_app_4_svg__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_4_svg__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_image_app_5_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../assets/image/app/5.svg */ "./assets/image/app/5.svg");
/* harmony import */ var _assets_image_app_5_svg__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_image_app_5_svg__WEBPACK_IMPORTED_MODULE_5__);






var data = {
  features: [{
    id: 1,
    image: _assets_image_app_6_svg__WEBPACK_IMPORTED_MODULE_0___default.a,
    title: 'Super Performance'
  }, {
    id: 2,
    image: _assets_image_app_1_svg__WEBPACK_IMPORTED_MODULE_1___default.a,
    title: 'Search Optimization'
  }, {
    id: 3,
    image: _assets_image_app_2_svg__WEBPACK_IMPORTED_MODULE_2___default.a,
    title: 'Customer Support'
  }, {
    id: 4,
    image: _assets_image_app_3_svg__WEBPACK_IMPORTED_MODULE_3___default.a,
    title: '100% Response Time'
  }, {
    id: 5,
    image: _assets_image_app_4_svg__WEBPACK_IMPORTED_MODULE_4___default.a,
    title: 'Maintaining Milestones'
  }, {
    id: 6,
    image: _assets_image_app_5_svg__WEBPACK_IMPORTED_MODULE_5___default.a,
    title: 'Organised Code'
  }]
};
/* harmony default export */ __webpack_exports__["default"] = (data);

/***/ }),

/***/ "./data/App/Footer/index.js":
/*!**********************************!*\
  !*** ./data/App/Footer/index.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var data = {
  menuWidget: [{
    id: 1,
    title: 'About Us',
    menuItems: [{
      id: 1,
      url: '#',
      text: 'Support Center'
    }, {
      id: 2,
      url: '#',
      text: 'Customer Support'
    }, {
      id: 3,
      url: '#',
      text: 'About Us'
    }, {
      id: 4,
      url: '#',
      text: 'Copyright'
    }, {
      id: 5,
      url: '#',
      text: 'Popular Campaign'
    }]
  }, {
    id: 2,
    title: 'Our Information',
    menuItems: [{
      id: 1,
      url: '#',
      text: 'Return Policy'
    }, {
      id: 2,
      url: '#',
      text: 'Privacy Policy'
    }, {
      id: 3,
      url: '#',
      text: 'Terms & Conditions'
    }, {
      id: 4,
      url: '#',
      text: 'Site Map'
    }, {
      id: 5,
      url: '#',
      text: 'Store Hours'
    }]
  }, {
    id: 3,
    title: 'My Account',
    menuItems: [{
      id: 1,
      url: '#',
      text: 'Press inquiries'
    }, {
      id: 2,
      url: '#',
      text: 'Social media directories'
    }, {
      id: 3,
      url: '#',
      text: 'Images & B-roll'
    }, {
      id: 4,
      url: '#',
      text: 'Permissions'
    }, {
      id: 5,
      url: '#',
      text: 'Speaker requests'
    }]
  }, {
    id: 4,
    title: 'Policy',
    menuItems: [{
      id: 1,
      url: '#',
      text: 'Application security'
    }, {
      id: 2,
      url: '#',
      text: 'Software principles'
    }, {
      id: 3,
      url: '#',
      text: 'Unwanted software policy'
    }, {
      id: 4,
      url: '#',
      text: 'Responsible supply chain'
    }]
  }]
};
/* harmony default export */ __webpack_exports__["default"] = (data);

/***/ }),

/***/ "./data/App/MenuItems/index.js":
/*!*************************************!*\
  !*** ./data/App/MenuItems/index.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var data = {
  menuItems: [{
    label: 'Our Services',
    path: '#services',
    offset: '100'
  }, {
    label: 'Control Remotely',
    path: '#control',
    offset: '100'
  }, {
    label: 'Key Features',
    path: '#keyfeature',
    offset: '0'
  }, {
    label: 'Partners',
    path: '#partners',
    offset: '-100'
  }, {
    label: 'Payments',
    path: '#payments',
    offset: '100'
  }, {
    label: 'Testimonial',
    path: '#testimonialSection',
    offset: '100'
  }]
};
/* harmony default export */ __webpack_exports__["default"] = (data);

/***/ }),

/***/ "./data/App/TestimonialSlider/index.js":
/*!*********************************************!*\
  !*** ./data/App/TestimonialSlider/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var data = {
  testimonials: [{
    id: 1,
    description: 'Best working experience  with this amazing team & in future, we want to work together',
    name: 'David Justin',
    designation: 'Founder of Dumpy'
  }, {
    id: 2,
    description: 'Impressed with master class support of the team and really look forward for the future.',
    name: 'Roman Ul Oman',
    designation: 'Co-founder of QatarDiaries'
  }, {
    id: 3,
    description: 'I have bought more than 10 themes on ThemeForest, and this is the first one I review. Wow! Amazing React Theme',
    name: 'Caroleane Mina',
    designation: 'Director of Beauty-queen'
  }, {
    id: 4,
    description: 'Really, really well made! Love that each component is handmade and customised. Great Work',
    name: 'Kyle More',
    designation: 'Co-founder of Softo'
  }, {
    id: 5,
    description: 'It written well. The author has a firm understanding of React and other technologies. It been consistently updated. Great product. Thank you.',
    name: 'Keith Berlin',
    designation: 'Co-founder of Antinio'
  }]
};
/* harmony default export */ __webpack_exports__["default"] = (data);

/***/ }),

/***/ "./data/Hosting/data.js":
/*!******************************!*\
  !*** ./data/Hosting/data.js ***!
  \******************************/
/*! exports provided: FEATURES_DATA, FAQ_DATA, SERVICES_DATA, MENU_ITEMS, FOOTER_WIDGET, MONTHLY_PRICING_TABLE, YEARLY_PRICING_TABLE, TESTIMONIALS, DOMAIN_NAMES, DOMAIN_PRICE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FEATURES_DATA", function() { return FEATURES_DATA; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FAQ_DATA", function() { return FAQ_DATA; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SERVICES_DATA", function() { return SERVICES_DATA; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MENU_ITEMS", function() { return MENU_ITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FOOTER_WIDGET", function() { return FOOTER_WIDGET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MONTHLY_PRICING_TABLE", function() { return MONTHLY_PRICING_TABLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YEARLY_PRICING_TABLE", function() { return YEARLY_PRICING_TABLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TESTIMONIALS", function() { return TESTIMONIALS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOMAIN_NAMES", function() { return DOMAIN_NAMES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOMAIN_PRICE", function() { return DOMAIN_PRICE; });
/* harmony import */ var _images__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./images */ "./data/Hosting/images.js");
 // Feature Section Content

var FEATURES_DATA = [{
  title: 'Domain Registration & Web Hosting',
  description: 'We have support team for 24/7 operation. They provide help and ongoing assistance at any time.',
  icon: 'flaticon-trophy violate',
  animation: true
}, {
  title: 'Website Design & Development',
  description: 'Transferring from another host? Our expert support team is standing by to transfer your site.',
  icon: 'flaticon-startup yellow',
  animation: true
}, {
  title: 'Dedicated Server & Cloud Hosting',
  description: 'LiteSpeed Web Server is a high-performance HTTP server and known for its high performance.',
  icon: 'flaticon-creative green',
  animation: true
}]; // FAQ Section Content

var FAQ_DATA = [{
  id: 1,
  expend: true,
  title: 'How to contact with Customer Service?',
  description: 'Our Customer Experience Team is available 7 days a week and we offer 2 ways to get in contact.Email and Chat . We try to reply quickly, so you need not to wait too long for a response!. '
}, {
  id: 2,
  title: 'App installation failed, how to update system information?',
  description: 'Please read the documentation carefully . We also have some online  video tutorials regarding this issue . If the problem remains, Please Open a ticket in the support forum . '
}, {
  id: 3,
  title: 'Website reponse taking time, how to improve?',
  description: 'At first, Please check your internet connection . We also have some online  video tutorials regarding this issue . If the problem remains, Please Open a ticket in the support forum .'
}, {
  id: 4,
  title: 'New update fixed all bug and issues?',
  description: 'We are giving the update of this theme continuously . You will receive an email Notification when we push an update. Always try to be updated with us .'
}]; // Service Section Content

var SERVICES_DATA = [{
  title: 'Development Server ',
  description: 'Get Lightspeed Development Server for your website and fly in the web',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconOne"])
}, {
  title: 'Web Protection',
  description: 'Best Protection and some tools are provided with our Web servers .',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconTwo"])
}, {
  title: 'E-commerce Shop',
  description: 'You can build any kind of E-commerce Shop with payment security tools',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconThree"])
}, {
  title: 'Money Back Guarantee',
  description: 'We have provided 30 days money back guarantee for our customer',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconFour"])
}, {
  title: 'Client Satisfaction',
  description: 'Client Satisfaction is our first priority and We are best at it',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconFive"])
}, {
  title: '24/7 Online Support',
  description: 'A Dedicated support team is always ready to provide best support ',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconSix"])
}];
var MENU_ITEMS = [{
  label: 'Home',
  path: '#banner_section',
  offset: '70'
}, {
  label: 'Feature',
  path: '#feature_section',
  offset: '70'
}, {
  label: 'Service',
  path: '#service_section',
  offset: '70'
}, {
  label: 'Testimonial',
  path: '#testimonial_section',
  offset: '70'
}, {
  label: 'FAQ',
  path: '#faq_section',
  offset: '70'
}, {
  label: 'Contact',
  path: '#contact_section',
  offset: '70'
}];
var FOOTER_WIDGET = [{
  title: 'About Us',
  menuItems: [{
    url: '#',
    text: 'Support Center'
  }, {
    url: '#',
    text: 'Customer Support'
  }, {
    url: '#',
    text: 'About Us'
  }, {
    url: '#',
    text: 'Copyright'
  }, {
    url: '#',
    text: 'Popular Campaign'
  }]
}, {
  title: 'Our Information',
  menuItems: [{
    url: '#',
    text: 'Return Policy'
  }, {
    url: '#',
    text: 'Privacy Policy'
  }, {
    url: '#',
    text: 'Terms & Conditions'
  }, {
    url: '#',
    text: 'Site Map'
  }, {
    url: '#',
    text: 'Store Hours'
  }]
}, {
  title: 'My Account',
  menuItems: [{
    url: '#',
    text: 'Press inquiries'
  }, {
    url: '#',
    text: 'Social media directories'
  }, {
    url: '#',
    text: 'Images & B-roll'
  }, {
    url: '#',
    text: 'Permissions'
  }, {
    url: '#',
    text: 'Speaker requests'
  }]
}, {
  title: 'Policy',
  menuItems: [{
    url: '#',
    text: 'Application security'
  }, {
    url: '#',
    text: 'Software principles'
  }, {
    url: '#',
    text: 'Unwanted software policy'
  }, {
    url: '#',
    text: 'Responsible supply chain'
  }]
}];
var MONTHLY_PRICING_TABLE = [{
  freePlan: true,
  name: 'Basic Account',
  description: 'For Small teams or group who need to build website ',
  price: '$0',
  priceLabel: 'Only for first month',
  buttonLabel: 'CREATE FREE ACCOUNT',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '1,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: 'eCommerce Store '
  }, {
    content: '30+ Webmaster Tools'
  }]
}, {
  name: 'Business Account',
  description: 'For Mediums teams or group who need to build website ',
  price: '$9.87',
  priceLabel: 'Per month & subscription yearly',
  buttonLabel: 'START FREE TRIAL',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '1,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: 'eCommerce Store '
  }, {
    content: '30+ Webmaster Tools'
  }]
}, {
  name: 'Premium Account',
  description: 'For Large teams or group who need to build website ',
  price: '$12.98',
  priceLabel: 'Per month & subscription yearly',
  buttonLabel: 'START FREE TRIAL',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '1,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: 'eCommerce Store '
  }, {
    content: '30+ Webmaster Tools'
  }]
}];
var YEARLY_PRICING_TABLE = [{
  freePlan: true,
  name: 'Basic Account',
  description: 'For a single client or team who need to build website ',
  price: '$0',
  priceLabel: 'Only for first month',
  buttonLabel: 'CREATE FREE ACCOUNT',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '1,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: 'eCommerce Store '
  }, {
    content: '30+ Webmaster Tools'
  }]
}, {
  name: 'Business Account',
  description: 'For Small teams or group who need to build website ',
  price: '$6.00',
  priceLabel: 'Per month & subscription yearly',
  buttonLabel: 'START FREE TRIAL',
  url: '#',
  listItems: [{
    content: 'Unlimited secure storage'
  }, {
    content: '2,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: '24/7 phone support'
  }, {
    content: '50+ Webmaster Tools'
  }]
}, {
  name: 'Premium Account',
  description: 'For Large teams or group who need to build website ',
  price: '$9.99',
  priceLabel: 'Per month & subscription yearly',
  buttonLabel: 'START FREE TRIAL',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '3,000s of Templates Ready'
  }, {
    content: 'Advanced branding'
  }, {
    content: 'Knowledge base support'
  }, {
    content: '80+ Webmaster Tools'
  }]
}];
var TESTIMONIALS = [{
  review: 'Best working experience  with this amazing team & in future, we want to work together',
  name: 'Denny Hilguston',
  designation: 'CEO of Dell Co.',
  avatar: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["AuthorOne"])
}, {
  review: 'Impressed with master class support of the team and really look forward for the future.',
  name: 'Justin Albuz',
  designation: 'Co Founder of IBM',
  avatar: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["AuthorTwo"])
}, {
  review: 'I have bought more than 10 themes on ThemeForest, and this is the first one I review.',
  name: 'Milly Cristiana',
  designation: 'Manager of Hp co.',
  avatar: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["AuthorThree"])
}];
var DOMAIN_NAMES = [{
  label: '.com',
  value: 'com'
}, {
  label: '.net',
  value: 'net'
}, {
  label: '.org',
  value: 'org'
}, {
  label: '.co',
  value: 'co'
}, {
  label: '.edu',
  value: 'edu'
}, {
  label: '.me',
  value: 'me'
}];
var DOMAIN_PRICE = [{
  content: '.com $9.26'
}, {
  content: '.sg $7.91'
}, {
  content: '.space $12.54'
}, {
  content: '.info $9.13'
}, {
  content: '& much more',
  url: '#'
}];

/***/ }),

/***/ "./data/Hosting/images.js":
/*!********************************!*\
  !*** ./data/Hosting/images.js ***!
  \********************************/
/*! exports provided: IconOne, IconTwo, IconThree, IconFour, IconFive, IconSix, AuthorOne, AuthorTwo, AuthorThree */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _assets_image_hosting_icon1_svg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../assets/image/hosting/icon1.svg */ "./assets/image/hosting/icon1.svg");
/* harmony import */ var _assets_image_hosting_icon1_svg__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon1_svg__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconOne", function() { return _assets_image_hosting_icon1_svg__WEBPACK_IMPORTED_MODULE_0___default.a; });
/* harmony import */ var _assets_image_hosting_icon2_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../assets/image/hosting/icon2.svg */ "./assets/image/hosting/icon2.svg");
/* harmony import */ var _assets_image_hosting_icon2_svg__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon2_svg__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconTwo", function() { return _assets_image_hosting_icon2_svg__WEBPACK_IMPORTED_MODULE_1___default.a; });
/* harmony import */ var _assets_image_hosting_icon3_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../assets/image/hosting/icon3.svg */ "./assets/image/hosting/icon3.svg");
/* harmony import */ var _assets_image_hosting_icon3_svg__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon3_svg__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconThree", function() { return _assets_image_hosting_icon3_svg__WEBPACK_IMPORTED_MODULE_2___default.a; });
/* harmony import */ var _assets_image_hosting_icon4_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/image/hosting/icon4.svg */ "./assets/image/hosting/icon4.svg");
/* harmony import */ var _assets_image_hosting_icon4_svg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon4_svg__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconFour", function() { return _assets_image_hosting_icon4_svg__WEBPACK_IMPORTED_MODULE_3___default.a; });
/* harmony import */ var _assets_image_hosting_icon5_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../assets/image/hosting/icon5.svg */ "./assets/image/hosting/icon5.svg");
/* harmony import */ var _assets_image_hosting_icon5_svg__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon5_svg__WEBPACK_IMPORTED_MODULE_4__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconFive", function() { return _assets_image_hosting_icon5_svg__WEBPACK_IMPORTED_MODULE_4___default.a; });
/* harmony import */ var _assets_image_hosting_icon6_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../assets/image/hosting/icon6.svg */ "./assets/image/hosting/icon6.svg");
/* harmony import */ var _assets_image_hosting_icon6_svg__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon6_svg__WEBPACK_IMPORTED_MODULE_5__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconSix", function() { return _assets_image_hosting_icon6_svg__WEBPACK_IMPORTED_MODULE_5___default.a; });
/* harmony import */ var _assets_image_hosting_author_1_jpg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../assets/image/hosting/author-1.jpg */ "./assets/image/hosting/author-1.jpg");
/* harmony import */ var _assets_image_hosting_author_1_jpg__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_author_1_jpg__WEBPACK_IMPORTED_MODULE_6__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "AuthorOne", function() { return _assets_image_hosting_author_1_jpg__WEBPACK_IMPORTED_MODULE_6___default.a; });
/* harmony import */ var _assets_image_hosting_author_2_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../assets/image/hosting/author-2.jpg */ "./assets/image/hosting/author-2.jpg");
/* harmony import */ var _assets_image_hosting_author_2_jpg__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_author_2_jpg__WEBPACK_IMPORTED_MODULE_7__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "AuthorTwo", function() { return _assets_image_hosting_author_2_jpg__WEBPACK_IMPORTED_MODULE_7___default.a; });
/* harmony import */ var _assets_image_hosting_author_3_jpg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../assets/image/hosting/author-3.jpg */ "./assets/image/hosting/author-3.jpg");
/* harmony import */ var _assets_image_hosting_author_3_jpg__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_author_3_jpg__WEBPACK_IMPORTED_MODULE_8__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "AuthorThree", function() { return _assets_image_hosting_author_3_jpg__WEBPACK_IMPORTED_MODULE_8___default.a; });
// Service Icons





 //Testimonial reviewers image






/***/ }),

/***/ "./pages/app.js":
/*!**********************!*\
  !*** ./pages/app.js ***!
  \**********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_stickynode__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-stickynode */ "react-stickynode");
/* harmony import */ var react_stickynode__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_stickynode__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _theme_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../theme/app */ "./theme/app/index.js");
/* harmony import */ var _containers_App_app_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../containers/App/app.style */ "./containers/App/app.style.js");
/* harmony import */ var _assets_css_style__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../assets/css/style */ "./assets/css/style.js");
/* harmony import */ var _containers_App_Navbar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../containers/App/Navbar */ "./containers/App/Navbar/index.js");
/* harmony import */ var _containers_App_Banner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../containers/App/Banner */ "./containers/App/Banner/index.js");
/* harmony import */ var _containers_App_FeatureSection__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../containers/App/FeatureSection */ "./containers/App/FeatureSection/index.js");
/* harmony import */ var _containers_App_Control__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../containers/App/Control */ "./containers/App/Control/index.js");
/* harmony import */ var _containers_App_Testimonial__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../containers/App/Testimonial */ "./containers/App/Testimonial/index.js");
/* harmony import */ var _containers_App_PartnerHistory__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../containers/App/PartnerHistory */ "./containers/App/PartnerHistory/index.js");
/* harmony import */ var _containers_App_PaymentSection__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../containers/App/PaymentSection */ "./containers/App/PaymentSection/index.js");
/* harmony import */ var _containers_App_Footer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../containers/App/Footer */ "./containers/App/Footer/index.js");
/* harmony import */ var _containers_App_FeatureSlider__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../containers/App/FeatureSlider */ "./containers/App/FeatureSlider/index.js");
/* harmony import */ var _containers_App_FeatureSliderTwo__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../containers/App/FeatureSliderTwo */ "./containers/App/FeatureSliderTwo/index.js");
/* harmony import */ var react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react-image-gallery/styles/css/image-gallery.css */ "../../node_modules/react-image-gallery/styles/css/image-gallery.css");
/* harmony import */ var react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../contexts/DrawerContext */ "./contexts/DrawerContext.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\pages\\app.js";

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }






















function getSize() {
  return {
    innerHeight: window.innerHeight,
    innerWidth: window.innerWidth,
    outerHeight: window.outerHeight,
    outerWidth: window.outerWidth
  };
}

function useWindowSize() {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(getSize()),
      _useState2 = _slicedToArray(_useState, 2),
      windowSize = _useState2[0],
      setWindowSize = _useState2[1];

  function handleResize() {
    setWindowSize(getSize());
  }

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(function () {
    window.addEventListener('resize', handleResize);
    return function () {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  return windowSize;
}

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var size = false && useWindowSize();
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(styled_components__WEBPACK_IMPORTED_MODULE_3__["ThemeProvider"], {
    theme: _theme_app__WEBPACK_IMPORTED_MODULE_5__["appTheme"],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("title", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }, "App | A react next landing page"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "Description",
    content: "React next landing page",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "theme-color",
    content: "#ec5555",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "stylesheet",
    href: "/static/css/flaticon.css",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    href: "https://fonts.googleapis.com/css?family=Open+Sans:300,400,700",
    rel: "stylesheet",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_assets_css_style__WEBPACK_IMPORTED_MODULE_7__["ResetCSS"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_app_style__WEBPACK_IMPORTED_MODULE_6__["GlobalStyle"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_app_style__WEBPACK_IMPORTED_MODULE_6__["AppWrapper"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 73
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_stickynode__WEBPACK_IMPORTED_MODULE_4___default.a, {
    top: 0,
    innerZ: 9999,
    activeClass: "sticky-nav-active",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 74
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_19__["DrawerProvider"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 75
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_Navbar__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_Banner__WEBPACK_IMPORTED_MODULE_9__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 79
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_FeatureSection__WEBPACK_IMPORTED_MODULE_10__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 80
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_Control__WEBPACK_IMPORTED_MODULE_11__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 81
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_app_style__WEBPACK_IMPORTED_MODULE_6__["ConditionWrapper"], {
    id: "keyfeature",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 82
    },
    __self: this
  }, size.innerWidth > 1100 ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_FeatureSlider__WEBPACK_IMPORTED_MODULE_16__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    },
    __self: this
  }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_FeatureSliderTwo__WEBPACK_IMPORTED_MODULE_17__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_PartnerHistory__WEBPACK_IMPORTED_MODULE_13__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 85
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_PaymentSection__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_Testimonial__WEBPACK_IMPORTED_MODULE_12__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 87
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_App_Footer__WEBPACK_IMPORTED_MODULE_15__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 88
    },
    __self: this
  }))));
});

/***/ }),

/***/ "./theme/app/colors.js":
/*!*****************************!*\
  !*** ./theme/app/colors.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var colors = _defineProperty({
  transparent: 'transparent',
  labelColor: '#767676',
  inactiveField: '#f2f2f2',
  inactiveButton: '#b7dbdd',
  inactiveIcon: '#EBEBEB',
  primaryHover: '#006b70',
  secondary: '#ff5b60',
  secondaryHover: '#FF282F',
  yellow: '#fdb32a',
  yellowHover: '#F29E02',
  borderColor: '#dadada',
  black: '#000000',
  white: '#ffffff',
  primary: '#1A73E8',
  headingColor: '#0f2137',
  quoteText: '#343d48',
  textColor: 'rgba(52, 61, 72, 0.8)',
  linkColor: '#2b9eff'
}, "transparent", 'transparent');

/* harmony default export */ __webpack_exports__["default"] = (colors);

/***/ }),

/***/ "./theme/app/index.js":
/*!****************************!*\
  !*** ./theme/app/index.js ***!
  \****************************/
/*! exports provided: appTheme */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appTheme", function() { return appTheme; });
/* harmony import */ var _colors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./colors */ "./theme/app/colors.js");

var appTheme = {
  breakpoints: [480, 768, 990, 1440],
  space: [0, 5, 10, 15, 20, 25, 30, 40, 56, 71, 91],
  fontSizes: [12, 14, 15, 16, 20, 24, 36, 48, 55, 60, 81],
  fontWeights: [300, 400, 500, 600, 700, 800, 900],
  height: [12, 24, 36, 48],
  width: [12, 24, 36, 48],
  lineHeights: {
    solid: 1,
    title: 1.25,
    copy: 1.5
  },
  letterSpacings: {
    normal: 'normal',
    tracked: '0.1em',
    tight: '-0.05em',
    mega: '0.25em'
  },
  fonts: {
    roboto: '"Open Sans", sans-serif'
  },
  borders: [0, '1px solid', '2px solid', '4px solid'],
  radius: [0, 3, 5, 10, 15, 20, 25, 50, 60, '50%'],
  colors: _colors__WEBPACK_IMPORTED_MODULE_0__["default"],
  colorStyles: {
    primary: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      '&:hover': {
        color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primaryHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primaryHover
      }
    },
    secondary: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
      '&:hover': {
        color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover
      }
    },
    warning: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellow,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellow,
      '&:hover': {
        color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellowHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellowHover
      }
    },
    error: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
      '&:hover': {
        color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary
      }
    },
    primaryWithBg: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primaryHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primaryHover
      }
    },
    secondaryWithBg: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover
      }
    },
    warningWithBg: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellow,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellow,
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellowHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellowHover
      }
    },
    errorWithBg: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary
      }
    }
  },
  buttonStyles: {
    textButton: {
      border: 0,
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      padding: 0,
      height: 'auto',
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].transparent
    },
    outlined: {
      borderWidth: '1px',
      borderStyle: 'solid',
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].transparent
    },
    fab: {
      border: '0',
      width: '40px',
      height: '40px',
      padding: 0,
      borderRadius: '50%',
      justifyContent: 'center',
      'span.btn-icon': {
        paddingLeft: 0
      }
    },
    extendedFab: {
      border: '0',
      minWidth: '50px',
      height: '40px',
      borderRadius: '50px',
      justifyContent: 'center'
    }
  }
};

/***/ }),

/***/ 5:
/*!****************************!*\
  !*** multi ./pages/app.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./pages/app.js */"./pages/app.js");


/***/ }),

/***/ "@redq/reuse-modal":
/*!************************************!*\
  !*** external "@redq/reuse-modal" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@redq/reuse-modal");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/link":
/*!****************************!*\
  !*** external "next/link" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/link");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "rc-drawer":
/*!****************************!*\
  !*** external "rc-drawer" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rc-drawer");

/***/ }),

/***/ "rc-tabs":
/*!**************************!*\
  !*** external "rc-tabs" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rc-tabs");

/***/ }),

/***/ "rc-tabs/lib/ScrollableInkTabBar":
/*!**************************************************!*\
  !*** external "rc-tabs/lib/ScrollableInkTabBar" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rc-tabs/lib/ScrollableInkTabBar");

/***/ }),

/***/ "rc-tabs/lib/TabContent":
/*!*****************************************!*\
  !*** external "rc-tabs/lib/TabContent" ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rc-tabs/lib/TabContent");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-anchor-link-smooth-scroll":
/*!**************************************************!*\
  !*** external "react-anchor-link-smooth-scroll" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-anchor-link-smooth-scroll");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-dom");

/***/ }),

/***/ "react-icons-kit":
/*!**********************************!*\
  !*** external "react-icons-kit" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit");

/***/ }),

/***/ "react-icons-kit/ikons/arrow_left":
/*!***************************************************!*\
  !*** external "react-icons-kit/ikons/arrow_left" ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/ikons/arrow_left");

/***/ }),

/***/ "react-icons-kit/ikons/arrow_right":
/*!****************************************************!*\
  !*** external "react-icons-kit/ikons/arrow_right" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/ikons/arrow_right");

/***/ }),

/***/ "react-icons-kit/ionicons/androidClose":
/*!********************************************************!*\
  !*** external "react-icons-kit/ionicons/androidClose" ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/ionicons/androidClose");

/***/ }),

/***/ "react-icons-kit/ionicons/email":
/*!*************************************************!*\
  !*** external "react-icons-kit/ionicons/email" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/ionicons/email");

/***/ }),

/***/ "react-icons-kit/ionicons/iosSearchStrong":
/*!***********************************************************!*\
  !*** external "react-icons-kit/ionicons/iosSearchStrong" ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/ionicons/iosSearchStrong");

/***/ }),

/***/ "react-icons-kit/md/ic_arrow_forward":
/*!******************************************************!*\
  !*** external "react-icons-kit/md/ic_arrow_forward" ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/md/ic_arrow_forward");

/***/ }),

/***/ "react-image-gallery":
/*!**************************************!*\
  !*** external "react-image-gallery" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-image-gallery");

/***/ }),

/***/ "react-particles-js":
/*!*************************************!*\
  !*** external "react-particles-js" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-particles-js");

/***/ }),

/***/ "react-reveal/Fade":
/*!************************************!*\
  !*** external "react-reveal/Fade" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-reveal/Fade");

/***/ }),

/***/ "react-reveal/Zoom":
/*!************************************!*\
  !*** external "react-reveal/Zoom" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-reveal/Zoom");

/***/ }),

/***/ "react-scrollspy":
/*!**********************************!*\
  !*** external "react-scrollspy" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-scrollspy");

/***/ }),

/***/ "react-stickynode":
/*!***********************************!*\
  !*** external "react-stickynode" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-stickynode");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),

/***/ "styled-system":
/*!********************************!*\
  !*** external "styled-system" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-system");

/***/ })

/******/ });
//# sourceMappingURL=app.js.map