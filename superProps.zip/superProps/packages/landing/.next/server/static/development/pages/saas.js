module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 6);
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../node_modules/@glidejs/glide/dist/css/glide.core.min.css":
/*!****************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/@glidejs/glide/dist/css/glide.core.min.css ***!
  \****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "../../node_modules/rc-drawer/assets/index.css":
/*!************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/rc-drawer/assets/index.css ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "../../node_modules/react-accessible-accordion/dist/fancy-example.css":
/*!***********************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/react-accessible-accordion/dist/fancy-example.css ***!
  \***********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Box/index.js":
/*!*********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Box/index.js ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Box\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var BoxWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('div')(_base__WEBPACK_IMPORTED_MODULE_4__["base"], Object(_base__WEBPACK_IMPORTED_MODULE_4__["themed"])('Box'), function (props) {
  return props.flexBox && Object(styled_components__WEBPACK_IMPORTED_MODULE_2__["css"])({
    display: 'flex'
  }, styled_system__WEBPACK_IMPORTED_MODULE_3__["flexWrap"], styled_system__WEBPACK_IMPORTED_MODULE_3__["flexDirection"], styled_system__WEBPACK_IMPORTED_MODULE_3__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_3__["justifyContent"], Object(_base__WEBPACK_IMPORTED_MODULE_4__["themed"])('FlexBox'));
});

var Box = function Box(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ["children"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(BoxWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }), children);
};

/* harmony default export */ __webpack_exports__["default"] = (Box);
Box.propTypes = {
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any.isRequired,

  /** Using this props we can convert our Box Component to a Flex Container or Component */
  flexBox: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  as: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['div', 'article', 'section', 'address', 'header', 'footer', 'nav', 'main']),
  width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontSize: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  color: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  flex: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  order: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  alignSelf: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  display: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  border: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderTop: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderRight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderBottom: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderLeft: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderColor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))])
};
Box.defaultProps = {
  as: 'div'
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Button/button.style.js":
/*!*******************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Button/button.style.js ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _theme_customVariant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../theme/customVariant */ "../../node_modules/reusecore/src/theme/customVariant.js");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  /* button default style */\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  color: ", ";\n  background-color: ", ";\n  min-height: ", "px;\n  min-width: ", "px;\n  border-radius: ", "px;\n  font-family: inherit;\n  font-size: ", "px;\n  font-weight: ", ";\n  text-decoration: none;\n  text-transform: capitalize;\n  padding-top: ", "px;\n  padding-bottom: ", "px;\n  padding-left: ", "px;\n  padding-right: ", "px;\n  border: 0;\n  transition: all 0.3s ease;\n  span.btn-text {\n    padding-left: ", "px;\n    padding-right: ", "px;\n  }\n  span.btn-icon {\n    display: flex;\n    > div {\n      display: flex !important;\n    }\n  }\n\n  &:focus {\n    outline: none;\n  }\n\n  /* Material style goes here */\n  &.is-material {\n    box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 3px 1px -2px rgba(0, 0, 0, 0.12);\n  }\n\n  /* When button on loading stage */\n  &.is-loading {\n    .btn-text {\n      padding-left: ", "px;\n      padding-right: ", "px;\n    }\n  }\n\n  /* Style system support */\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }





var ButtonStyle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button(_templateObject(), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#028489'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('heights.3', '48'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('widths.3', '48'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radius.0', '3'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.4', '16'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.4', '500'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.2', '8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.2', '8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.4', '15'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.4', '15'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.1', '4'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.1', '4'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.2', '8'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('space.2', '8'), styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], _theme_customVariant__WEBPACK_IMPORTED_MODULE_2__["buttonStyle"], _theme_customVariant__WEBPACK_IMPORTED_MODULE_2__["colorStyle"], _theme_customVariant__WEBPACK_IMPORTED_MODULE_2__["sizeStyle"], _base__WEBPACK_IMPORTED_MODULE_3__["base"]); // prop types can also be added from the style functions

ButtonStyle.propTypes = _objectSpread({}, styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_1__["variant"].propTypes);
ButtonStyle.displayName = 'ButtonStyle';
/* harmony default export */ __webpack_exports__["default"] = (ButtonStyle);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Button/index.js":
/*!************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Button/index.js ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./button.style */ "../../node_modules/reusecore/src/elements/Button/button.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Button\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var Button = function Button(_ref) {
  var type = _ref.type,
      title = _ref.title,
      icon = _ref.icon,
      disabled = _ref.disabled,
      iconPosition = _ref.iconPosition,
      onClick = _ref.onClick,
      loader = _ref.loader,
      isMaterial = _ref.isMaterial,
      isLoading = _ref.isLoading,
      className = _ref.className,
      props = _objectWithoutProperties(_ref, ["type", "title", "icon", "disabled", "iconPosition", "onClick", "loader", "isMaterial", "isLoading", "className"]);

  // Add all classs to an array
  var addAllClasses = ['reusecore__button']; // isLoading prop checking

  if (isLoading) {
    addAllClasses.push('is-loading');
  } // isMaterial prop checking


  if (isMaterial) {
    addAllClasses.push('is-material');
  } // className prop checking


  if (className) {
    addAllClasses.push(className);
  } // Checking button loading state


  var buttonIcon = isLoading !== false ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  }, " ", loader) : icon && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "btn-icon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }, icon); // set icon position

  var position = iconPosition || 'right';
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_button_style__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    type: type,
    className: addAllClasses.join(' '),
    icon: icon,
    disabled: disabled,
    "icon-position": position,
    onClick: onClick
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }), position === 'left' && buttonIcon, title && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "btn-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }, title), position === 'right' && buttonIcon);
};

Button.propTypes = {
  /** ClassName of the button */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Add icon */
  type: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['button', 'submit', 'reset']),

  /** Add icon */
  icon: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Add loader */
  loader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Add Material effect */
  isMaterial: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Button Loading state */
  isLoading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Button Loading state */
  loaderColor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** If true button will be disabled */
  disabled: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Adjust your icon and loader position [if you use loader] */
  iconPosition: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['left', 'right']),

  /** Variant change button shape */
  variant: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['textButton', 'outlined', 'fab', 'extendedFab']),

  /** primary || secondary || warning || error  change text and border color.
   *  And primaryWithBg || secondaryWithBg || warningWithBg || errorWithBg change text, border and background color */
  colors: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['primary', 'secondary', 'warning', 'error', 'primaryWithBg', 'secondaryWithBg', 'warningWithBg', 'errorWithBg']),

  /**
   * Gets called when the user clicks on the button
   */
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};
Button.defaultProps = {
  disabled: false,
  isMaterial: false,
  isLoading: false,
  type: 'button'
};
/* harmony default export */ __webpack_exports__["default"] = (Button);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Card/index.js":
/*!**********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Card/index.js ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _theme_customVariant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../theme/customVariant */ "../../node_modules/reusecore/src/theme/customVariant.js");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Card\\index.js";

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var CardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('div')(_base__WEBPACK_IMPORTED_MODULE_5__["base"], styled_system__WEBPACK_IMPORTED_MODULE_3__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_3__["borderColor"], styled_system__WEBPACK_IMPORTED_MODULE_3__["borderRadius"], styled_system__WEBPACK_IMPORTED_MODULE_3__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundImage"], styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundSize"], styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundPosition"], styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundRepeat"], styled_system__WEBPACK_IMPORTED_MODULE_3__["opacity"], _theme_customVariant__WEBPACK_IMPORTED_MODULE_4__["cards"], Object(_base__WEBPACK_IMPORTED_MODULE_5__["themed"])('Card'));

var Card = function Card(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ["children"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(CardWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    },
    __self: this
  }), children);
};

Card.propTypes = _objectSpread({
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any
}, styled_system__WEBPACK_IMPORTED_MODULE_3__["borders"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["borderColor"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["borderRadius"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["boxShadow"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundImage"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundSize"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundPosition"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["backgroundRepeat"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_3__["opacity"].propTypes, _theme_customVariant__WEBPACK_IMPORTED_MODULE_4__["cards"].propTypes);
Card.defaultProps = {
  boxShadow: '0px 20px 35px rgba(0, 0, 0, 0.05)'
};
/* harmony default export */ __webpack_exports__["default"] = (Card);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Drawer/index.js":
/*!************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Drawer/index.js ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rc-drawer */ "rc-drawer");
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rc_drawer__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rc_drawer_assets_index_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rc-drawer/assets/index.css */ "../../node_modules/rc-drawer/assets/index.css");
/* harmony import */ var rc_drawer_assets_index_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rc_drawer_assets_index_css__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Drawer\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var Drawer = function Drawer(_ref) {
  var className = _ref.className,
      children = _ref.children,
      closeButton = _ref.closeButton,
      drawerHandler = _ref.drawerHandler,
      toggleHandler = _ref.toggleHandler,
      open = _ref.open,
      props = _objectWithoutProperties(_ref, ["className", "children", "closeButton", "drawerHandler", "toggleHandler", "open"]);

  // Add all classs to an array
  var addAllClasses = ['reusecore__drawer']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(rc_drawer__WEBPACK_IMPORTED_MODULE_2___default.a, _extends({
    open: open,
    onMaskClick: toggleHandler,
    className: addAllClasses.join(' ')
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "reusecore-drawer__close",
    onClick: toggleHandler,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    __self: this
  }, closeButton), children), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "reusecore-drawer__handler",
    style: {
      display: 'inline-block'
    },
    onClick: toggleHandler,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    },
    __self: this
  }, drawerHandler));
};

Drawer.propTypes = {
  /** ClassName of the Drawer */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Used to render icon, button, text or any elements inside the closeButton prop. */
  closeButton: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** Set drawer width. Default value is 300px. */
  width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Set drawer position left || right || top || bottom. */
  placement: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['left', 'right', 'top', 'bottom']),

  /** drawerHandler could be button, icon, string or any component */
  drawerHandler: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element.isRequired
};
Drawer.defaultProps = {
  width: '300px',
  handler: false,
  level: null
};
/* harmony default export */ __webpack_exports__["default"] = (Drawer);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Heading/index.js":
/*!*************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Heading/index.js ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Heading\\index.js";

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var HeadingWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('p')(_base__WEBPACK_IMPORTED_MODULE_4__["base"], styled_system__WEBPACK_IMPORTED_MODULE_3__["fontFamily"], styled_system__WEBPACK_IMPORTED_MODULE_3__["fontWeight"], styled_system__WEBPACK_IMPORTED_MODULE_3__["textAlign"], styled_system__WEBPACK_IMPORTED_MODULE_3__["lineHeight"], styled_system__WEBPACK_IMPORTED_MODULE_3__["letterSpacing"], Object(_base__WEBPACK_IMPORTED_MODULE_4__["themed"])('Heading'));

var Heading = function Heading(_ref) {
  var content = _ref.content,
      props = _objectWithoutProperties(_ref, ["content"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(HeadingWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }), content);
};

/* harmony default export */ __webpack_exports__["default"] = (Heading);
Heading.propTypes = _objectSpread({
  content: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  as: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']),
  mt: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  mb: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontFamily: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontWeight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  textAlign: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  lineHeight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  letterSpacing: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))])
}, _base__WEBPACK_IMPORTED_MODULE_4__["base"].propTypes);
Heading.defaultProps = {
  as: 'h2',
  mt: 0,
  mb: '1rem',
  fontWeight: 'bold'
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Image/index.js":
/*!***********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Image/index.js ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Image\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var ImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('img')({
  display: 'block',
  maxWidth: '100%',
  height: 'auto'
}, _base__WEBPACK_IMPORTED_MODULE_3__["base"], Object(_base__WEBPACK_IMPORTED_MODULE_3__["themed"])('Image'));

var Image = function Image(_ref) {
  var src = _ref.src,
      alt = _ref.alt,
      props = _objectWithoutProperties(_ref, ["src", "alt"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ImageWrapper, _extends({
    src: src,
    alt: alt
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    },
    __self: this
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (Image);
Image.propTypes = {
  src: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  alt: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired
};
Image.defaultProps = {
  m: 0
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Link/index.js":
/*!**********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Link/index.js ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Link\\index.js";

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var LinkWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('a')({
  textDecoration: 'none'
}, _base__WEBPACK_IMPORTED_MODULE_3__["base"], Object(_base__WEBPACK_IMPORTED_MODULE_3__["themed"])('Link'));

var Link = function Link(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ["children"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(LinkWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    },
    __self: this
  }), children);
};

/* harmony default export */ __webpack_exports__["default"] = (Link);
Link.propTypes = _objectSpread({
  as: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object]),
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any.isRequired
}, _base__WEBPACK_IMPORTED_MODULE_3__["base"].propTypes);
Link.defaultProps = {
  as: 'a',
  m: 0,
  display: 'inline-block'
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Navbar/index.js":
/*!************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Navbar/index.js ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _navbar_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./navbar.style */ "../../node_modules/reusecore/src/elements/Navbar/navbar.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Navbar\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var Navbar = function Navbar(_ref) {
  var className = _ref.className,
      children = _ref.children,
      navbarStyle = _ref.navbarStyle,
      props = _objectWithoutProperties(_ref, ["className", "children", "navbarStyle"]);

  // Add all classs to an array
  var addAllClasses = ['reusecore__navbar']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_navbar_style__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: addAllClasses.join(' ')
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    },
    __self: this
  }), children);
};

Navbar.propTypes = {
  /** ClassName of the Navbar. Default class is reusecore__navbar*/
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Used to render menu, logo, button or any component that
   * you want to show in navbar. */
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,
  width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  space: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  borderRadius: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  boxShadow: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  color: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  display: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  alignItems: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  justifyContent: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  flexDirection: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  flexWrap: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
};
/** Navbar default proptype */

Navbar.defaultProps = {};
/* harmony default export */ __webpack_exports__["default"] = (Navbar);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Navbar/navbar.style.js":
/*!*******************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Navbar/navbar.style.js ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  /* Navbar default style goes here */\n  display: flex;\n  align-items: center;\n  min-height: 56px;\n  padding: 10px 16px;\n  \n  /* Style system supported prop */\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n  ", "\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }



var NavbarStyle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.nav(_templateObject(), styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexDirection"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexWrap"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"]);
NavbarStyle.displayName = 'NavbarStyle';
/* harmony default export */ __webpack_exports__["default"] = (NavbarStyle);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/Text/index.js":
/*!**********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/Text/index.js ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base */ "../../node_modules/reusecore/src/elements/base.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\Text\\index.js";

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var TextWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('p')(_base__WEBPACK_IMPORTED_MODULE_4__["base"], styled_system__WEBPACK_IMPORTED_MODULE_3__["fontFamily"], styled_system__WEBPACK_IMPORTED_MODULE_3__["fontWeight"], styled_system__WEBPACK_IMPORTED_MODULE_3__["textAlign"], styled_system__WEBPACK_IMPORTED_MODULE_3__["lineHeight"], styled_system__WEBPACK_IMPORTED_MODULE_3__["letterSpacing"], Object(_base__WEBPACK_IMPORTED_MODULE_4__["themed"])('Text'));

var Text = function Text(_ref) {
  var content = _ref.content,
      props = _objectWithoutProperties(_ref, ["content"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(TextWrapper, _extends({}, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }), content);
};

/* harmony default export */ __webpack_exports__["default"] = (Text);
Text.propTypes = _objectSpread({
  content: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  as: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  mt: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  mb: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontFamily: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  fontWeight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  textAlign: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  lineHeight: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))]),
  letterSpacing: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number]))])
}, _base__WEBPACK_IMPORTED_MODULE_4__["base"].propTypes);
Text.defaultProps = {
  as: 'p',
  mt: 0,
  mb: '1rem'
};

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/UI/Logo/index.js":
/*!*************************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/UI/Logo/index.js ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../Link */ "../../node_modules/reusecore/src/elements/Link/index.js");
/* harmony import */ var _Image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\node_modules\\reusecore\\src\\elements\\UI\\Logo\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var Logo = function Logo(_ref) {
  var logoWrapperStyle = _ref.logoWrapperStyle,
      logoStyle = _ref.logoStyle,
      titleStyle = _ref.titleStyle,
      withAchor = _ref.withAchor,
      anchorProps = _ref.anchorProps,
      logoSrc = _ref.logoSrc,
      title = _ref.title,
      props = _objectWithoutProperties(_ref, ["logoWrapperStyle", "logoStyle", "titleStyle", "withAchor", "anchorProps", "logoSrc", "title"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Link__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, props, logoWrapperStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    },
    __self: this
  }), withAchor ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", _extends({}, anchorProps, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 19
    },
    __self: this
  }), logoSrc ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Image__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    src: logoSrc,
    alt: title
  }, logoStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21
    },
    __self: this
  })) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Text__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    content: title
  }, titleStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    },
    __self: this
  }))) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, logoSrc ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Image__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    src: logoSrc,
    alt: title
  }, logoStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  })) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Text__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    content: title
  }, titleStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    __self: this
  }))));
};

Logo.propTypes = {
  logoSrc: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  logoWrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  logoStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  titleStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  withAchor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  anchorProps: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
Logo.defaultProps = {
  logoWrapperStyle: {
    display: 'inline-block',
    mr: '1rem',
    'a:hover,a:focus': {
      textDecoration: 'none'
    }
  },
  titleStyle: {
    display: 'inline-block',
    fontSize: '2rem',
    lineHeight: 'inherit',
    whiteSpace: 'nowrap'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (Logo);

/***/ }),

/***/ "../../node_modules/reusecore/src/elements/base.js":
/*!****************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/elements/base.js ***!
  \****************************************************************************************************/
/*! exports provided: themed, base */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "themed", function() { return themed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "base", function() { return base; });
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_0__);
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/** this is our Base Component every components must be Extend it */

var themed = function themed(key) {
  return function (props) {
    return props.theme[key];
  };
};
var base = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["compose"])(function () {
  return {
    boxSizing: 'border-box'
  };
}, styled_system__WEBPACK_IMPORTED_MODULE_0__["space"], styled_system__WEBPACK_IMPORTED_MODULE_0__["width"], styled_system__WEBPACK_IMPORTED_MODULE_0__["minWidth"], styled_system__WEBPACK_IMPORTED_MODULE_0__["maxWidth"], styled_system__WEBPACK_IMPORTED_MODULE_0__["height"], styled_system__WEBPACK_IMPORTED_MODULE_0__["minHeight"], styled_system__WEBPACK_IMPORTED_MODULE_0__["maxHeight"], styled_system__WEBPACK_IMPORTED_MODULE_0__["fontSize"], styled_system__WEBPACK_IMPORTED_MODULE_0__["color"], styled_system__WEBPACK_IMPORTED_MODULE_0__["flex"], styled_system__WEBPACK_IMPORTED_MODULE_0__["order"], styled_system__WEBPACK_IMPORTED_MODULE_0__["alignSelf"], styled_system__WEBPACK_IMPORTED_MODULE_0__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_0__["borderColor"], styled_system__WEBPACK_IMPORTED_MODULE_0__["display"]);
base.propTypes = _objectSpread({}, styled_system__WEBPACK_IMPORTED_MODULE_0__["display"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["space"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["borders"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["borderColor"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["width"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["height"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["fontSize"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["color"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["flex"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["order"].propTypes, styled_system__WEBPACK_IMPORTED_MODULE_0__["alignSelf"].propTypes);

/***/ }),

/***/ "../../node_modules/reusecore/src/theme/customVariant.js":
/*!**********************************************************************************************************!*\
  !*** D:/RedQ Projects/Next Landing/react-next-landing/node_modules/reusecore/src/theme/customVariant.js ***!
  \**********************************************************************************************************/
/*! exports provided: cards, buttonStyle, colorStyle, sizeStyle */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cards", function() { return cards; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buttonStyle", function() { return buttonStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorStyle", function() { return colorStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sizeStyle", function() { return sizeStyle; });
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_0__);

var buttonStyle = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["variant"])({
  key: 'buttonStyles'
});
var colorStyle = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["variant"])({
  key: 'colorStyles',
  prop: 'colors'
});
var sizeStyle = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["variant"])({
  key: 'sizeStyles',
  prop: 'size'
});
var cards = Object(styled_system__WEBPACK_IMPORTED_MODULE_0__["variant"])({
  key: 'cards'
});


/***/ }),

/***/ "./assets/css/style.js":
/*!*****************************!*\
  !*** ./assets/css/style.js ***!
  \*****************************/
/*! exports provided: ResetCSS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetCSS", function() { return ResetCSS; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  ::selection {\n    background: #333333;\n    color: #ffffff;\n  }\n\n  html {\n    box-sizing: border-box;\n    -ms-overflow-style: scrollbar;\n  }\n\n  *,\n  *::before,\n  *::after {\n    box-sizing: inherit;\n  }\n\n  * {\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n  }\n\n  html,\n  html a,\n  h1,\n  h2,\n  h3,\n  h4,\n  h5,\n  h6,\n  a,\n  p,\n  li,\n  dl,\n  th,\n  dt,\n  input,\n  textarea,\n  span,\n  div {\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n    text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.004);\n  }\n\n  body {\n    margin: 0;\n    padding: 0;\n    overflow-x: hidden;\n    -webkit-tap-highlight-color: transparent;\n  }\n\n  ul {\n    margin: 0;\n    padding: 0;\n  }\n\n  li {\n    list-style-type: none;\n  }\n\n  a {\n    text-decoration: none;\n  }\n\n  a:hover {\n    text-decoration: none;\n  }\n\n  // modal default style\n  .reuseModalOverlay {\n    z-index: 99999;\n  }\n\n  .reuseModalHolder {\n    padding: 0;\n    &.demo_switcher_modal {\n      border: 0;\n      background-color: rgba(16, 30, 77, 0.9);\n      .innerRndComponent {\n        border-radius: 8px;\n      }\n    }\n  }\n\n  button.modalCloseBtn {\n    position: fixed;\n    z-index: 999991;\n    background-color: transparent;\n    top: 10px;\n    right: 10px;\n    min-width: 34px;\n    min-height: 34px;\n    padding: 0;\n    span.btn-icon {\n      font-size: 22px;\n      transform: rotate(45deg);\n    }\n\n    &.alt {\n      border-radius: 50%;\n      z-index: 999999;\n      padding: 0;\n      transition: all 0.3s ease;\n      top: 25px;\n      right: 30px;\n      min-width: 40px;\n      min-height: 40px;\n\n      span.btn-icon {\n        font-size: 20px;\n      }\n\n      &:hover {\n        opacity: 0.88;\n      }\n    }   \n  }\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }



var ResetCSS = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["createGlobalStyle"])(_templateObject());

/***/ }),

/***/ "./assets/image/agency/client/denny.png":
/*!**********************************************!*\
  !*** ./assets/image/agency/client/denny.png ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/denny-79245e1dee73f32d5d6b1c5749129db6.png";

/***/ }),

/***/ "./assets/image/hosting/author-1.jpg":
/*!*******************************************!*\
  !*** ./assets/image/hosting/author-1.jpg ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4QlQaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzEzOCA3OS4xNTk4MjQsIDIwMTYvMDkvMTQtMDE6MDk6MDEgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiLz4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSJ3Ij8+/+0ALFBob3Rvc2hvcCAzLjAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/bAIQAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQICAgICAgICAgICAwMDAwMDAwMDAwEBAQEBAQECAQECAgIBAgIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMD/90ABAAI/+4ADkFkb2JlAGTAAAAAAf/AABEIADsAOwMAEQABEQECEQH/xACdAAABBAMBAQAAAAAAAAAAAAAIAwYJCgAEBwUBAQABBQEBAQAAAAAAAAAAAAAHAAEEBQYDAggQAAEFAAEDAwMCAwcFAAAAAAMBAgQFBgcACBESEyEJFCIVMRZBURcjMnGBkcFDUmGh0REAAgECBQIEAwUIAwAAAAAAAQIDBBEABRIhMQZBEyJRYRRxgQcjMkKhFSRSkbHB0fBicuH/2gAMAwAAARECEQA/AL/HSwsZ0sLGdLCwH/dt3o8U9oeZhXG5kLYW9qaMKBQw51bFPHjS5gq4NzbPmygljVK2EgYGe0M5zne1gxr+bmQavMKejssh+9PC9/n7D+/6XOUZHWZuzGEaYE/E54B9B6m2/YAcni8UdR9XzXcgcog4vymj4xy3KtMC6nQ+Mb/JXZ87zHWjdJOGPlNZI0kK1rNXT18F73QR+82X5d4Vq+GpSTZ9PH5gq+H6jf6HfbGuXoqltvJJfuNtQ97W3B9e3fBFdtn1me3zlbnQXbHzBIruC+aLcUJuIrNhMn56q39wVHNs8rnS6uupvutPTmRrCR4ppoyOf4aT1IiOn0WcR1FhMAhNrEG6knge3pvsfW+2KPNelamhTxqYmWMAki1mAHJt+YW3NtwN7W3xMl1dYymPnhP6J/t0sLH/0L/HSwsZ0sLGdLCxXM7k+3/kXv8AdJzPS7rjbH3PCR9fZU3G1htbB5bjbWeHvZNbF1NVBqkipicPlrCOgoEuROfPtJbHuZGYFrjOGOay5jV1sk1MqEBiEJ5IU254UA7XPPp3B26bTJcqy2GGtlkWQorSqouAXAaxvu7EWNgLLtcjYGK3kD6LnKm719C3TugWtvQ3H3dZyfl4e1425JpraSd0m0umJB0MrByWOmRwuhywLFkF9K++v5eHVMFVXxzmKpRhEeQBc39h8+CTbGtqY8jkphPSOrSgbFiALc7t+IbfiAF+2O0d1n09O8yD23aCBsbSFyRQ0BKyxrtBYuz1xpo+iioraHdQcVQxITKPa1VmQQg2lXOjS1Vr58tWkanqmwR5hTP4k8TLl7G19Sk78XUcX/Tv2xSNU5BXXipKhTmQXVp0OF8ttQV2G9gfTcbC9jiwF9KLnzkLuF7H+INNzFbNveaMhCmcZcuXCka+RbbnDGSqnXMxEENUkXkBI8xXv/vDodDPRriKxpIy2qWspFlBuRcH1uPX3I3wEeocuOWZrJT6QsRsy240sL7ewNx9MSN9T8UuP//Rv3odf+1OnAvhYUQn/j/jpsLHham3j02cu7OVYwqcUWtlKyysCuFEiyijUMJxXMRSuUkwg2MYNHFI9yNY1z3Ii8p5oqeIyzukcQ5ZiFUXNhcnbkgYk0dJU11StLRxSTVDXsiKWYgAs1lAJ2UEnsACTsCRX4p/qxcWdvnAuU1e17Xu4DPVRq4dnIyuxkca5vmLxe3ZYQdNoOG5WkdqM9Xa+wJ9xWkkEVs4JmKNyv8AcRmSZqSgnbKgwmzJF8RwA2hVfdWZgh0huQTz6YJUWVZnnYXNUKw5W8gijfylnZPKUjBlUOym4spuO9tr9Ad9bT6ckrOStRX7BdJsqAE8234XzlUf+3bjEtPYhpr6JyDx/a/phsnKp7gyQyulSWAfM8BE8j3sR1cZpWljf4CRjIbhlZNBXkMsjMEYMPMtmvYbgEECxjyeQmeiGaRxvDYMkiyFtXDI0SK0qFG8j64wA3BIIJIGT3h9u/cbxZ/C/FPKrafYcr1Jy4PjrZwXY3lLTS6Mf61aZzGUOiWMHYaQNZDcQ1bVFlWIQI56i9vy9O8qy5hl8vwCyMLgMlgXW25/CWBBt2Nx6W3xW+F+w84hTODCsmk6ZAWETahYX1Kji17+ZdJ/iFiMEV2C08qi4A96bnpuXn3nIvI1tOorOlJnrGBJHojU7mTak0eLIiySMqWvehGI5Vd5+UVOtLkkckVAolUrIWYkEWIN7cfTGN6mnjqM1Z4WV4hGgDA3BGkG4IuDzg1fef8A0b/7/wDvVvjOlwMf/9K/Y1qeEXpybbDDc4U6bD4Y3Jtaa3453NdFNBjTZGVu/wBOl2ddFtoMG0DAMessJNbNa+LMZX2AhmRj08Ko0/b90r81p/issnp7qC8TAEgMAbbHSbg2Nj9MX3S1d+zeo6GuIkZI6mMsqO0bumoB0DqQy60JW4PB9MRD8+VPEtXQ4DI3WwzWh19xArM/mcbrsdP5I5Qk1kQzb6ylzrOHoaMmn4048+8LYFBo1NVwYEVoBKQijGQcdRZlk7SxmpWOTNm0poQyLK4FvM3h7FIxd2L7ACy3JAJ06AyPqJKapegeamyFdUnit4Jpo3OrTGqTKzCeU2iTwBr1Nrk0opIZXPvB/ZfneG+3kFbs8OfKccZPV1rYM2bR2Or5Z4y5FvqG82/I5hPqruRZPoOQvs9JOWdAk1YklzByWAc5phTc+znIY8oiM06GJShUxlfEAXYyohuAqhrup3CE3N1sYvSHTHWsvUlUYaWQTSB1l8ZXaAO24ppZAVu8ukrHIhOqVVZQVckb8j6fvbPMpcX97naqr4ny8m/2krPwdNcHnF5JuMHO4uwPIXHkHPSodBxTK4/x2utZILfOHBaznnjDYQYhvVzUtJl0KPXJPK9TU6dcgbQSo3Vh4ZAPYkg+ZRbcE4p89zLP56uPLZqaBaekDeDEYgyhjs8ZMwLXa5QBh90SWFmtc++ybMcrUmL1U3lBLLNMZb1mExfFbNAHUYvDZLi+EbKVF9hLs0SNoJlXybWjj3J/1Z57Fhi+kpHKnVz0UuezU1RX5+8nxMs2lYy4dFWO6q8RAB0zCzkNdhwTtiL9sL9B0D5T030NHTyU9HRGWetWJ4KiolqysrU9VGXdA+XkNTK0NkYAsBvg0/canx6mf69bTQ2AqSp7HH//0731Fq6rQRmTKm0iy4z/AD6CiIxzXeFVP6/Py1epstM8Rs6m+Icc4kF1bDhSUvz5MxU8fHhEXz/t5646B6Y66z67YSdMR6KwjGkG5Fa8bkRWEY74exzXeWq17fKKip4VF6fwlIscISlWDA7g4hf5X4GvS9zu43nG+3NhOXcBFz9urUIAGY5a4jsUnFr+MdfPLQaCyxVUYBzjgW1KFJkC0gIQgpACnE4M1OUR0XWdVNKzp4kIZGU25O3KkeSzLaxBte298fTPT/VBruhaDLJFiem+IKOZI/F8JttUnhh08QP5WcF1bSfKwK2Ij0OY5a3+g5Cy/C3ENXw7uuQKK4rtNznyZy32y9wWIp4tgR0KXorTi/LcY0nImjkxRlK8dCqUUK1IRPekDRjnpGjy/LJJXekkVDICZTeBzIL2PlEasmrffnfa5G5PztqzLsnWpzeejkgpJUWljipswgdjpJHhSGreCy2X8RYKRY2BOCC7BeMoubST201e8vthS4exey600mUE84FdWPPbTg1YwLJrctAkTSRQw60amDWrKPFC54ozVWv6Dy56itkomaQU2t7b3styQEP/ABBUE25Jt3wP/tV6i/doc4eOL43w4/KRsWNt3HLXs3fzALfkYm4rIUSkrYdTAUzIUESiChzvkGd6nvKUhzv/ACKYxiOc5fj5X4RE8Ih9pqaOlgWnhFo0Fh3x8uV+YVOZVkldVEGeVrmwAHoAAOABYAegxue41f8AqN/1VP8An56729sQyT64/9S0rnqvkCiIkcDJUMjlVXpEkvCxy+VVF9Kt9KOX/L562BzLK5xrD+X3GMstPVodNvN7YJLJ8jchQWgrLTPkvzOaiA+18rO9CfHrP7bPaRnlP8bvSnn916hzRUEoMscgVRyTsMTEarjskiXPtzjqS8hS4AxluqdkF0gqBDGbNEdwFRikMW0lD9UWAOOxi+pqOI//AC6oqqqpIvLATI3c8KPr3+mLSCnnfzSgIvpyf5dsA13EaLklJUfuW4oylBr9rxtnLmgm8Y2Mx1XD5Z42PKizrXKx7uQwg4GjqZLks6uQYTxOKwgXIjTfAx6nq5IatsyVVcxQX0kXuASSLcnY/pce5f6GhhmolymZ3jSeqPnU2KsRZTfgbi3HffbcRSbT6sGs3NVrMV2qdh3JFbz3plDTTNxybnY/GnHfHUiz8w7K9Nu2vOuon0sFSvjxa8D3DN7au9CeU6wT9cZbU0rSRQxJK5sCvmkvxsoAsDwC1rdh3Bmn6DrKaWKOarqJIYQLq9ljK8gEkkue5CDfubXBNrtmtK/sp4CLs+QrWBoeV9o6K+ZBqnNjxr3Sr7jYmTykIvmd/C1CGQp7CaRpJEoxCSDqpSjalr0jVVCymSn8kw0n2Qb3v699vzE298YLr6KkZPCqTqgFxxvI1hx73sN/wgX7EEkMZ3eWfIVDWxIF9mc9yIsURZdZovNbn7p0hz3B+0sn/hRS2sVEe0vrjI5PQrmPRVU25TnlI5EWaKQP415H/Ze4+W49DgAZjlNUl3oSDb8p/sfb359ceBadzvOVJYS6m1x0iPYQTODIGPPXcwXqTw5hAy6+JMgygGE5r2EEV43scjmr4Xrdx0GXTRiWGRWiYXBDCxH874yElbWROY5UZZAbEFTt+mP/1bNtb3G2+l0UaoqYInS7K2BWVjXOc5XlM9G/LRr5QIWo4r1T5QTHL/Lq/TIaanpi8reRVLMfYf7/ADxQNmkks4SNfMzWA9T/AL+mE9P3oUWbkaKPXzqN+apWoKdeWDpLXTHV0L3pd0jAFHEnPm2EhgIsMjvy9TBtRXI9Vwk+Ya3OgWhB2B7D19z642MVCVRdW8h5I/p8sI1XOIrmut7DQ2sqROFVQaeX7w/aDnLfSebM9WyIFGwQlqadwYznIikEUz0Xw5FVOHxFwS5ubW+V/wDGOogsQFG17/MD/wBwK/cH3dbDiup0IIeIk8jZHUx1h1EOh09RlNRx9Okx0HItK+bfBNTXdNLOJFa0rmEUv7enw5rs3n1C+ZRMIZDHMU0huQPe3+MbDpbM1yidTPGJKdZNduCSO199vn9D6Q9UHdvzBnrmbWZLgyBe6aRLIdNTyty7SWudiEkfl70mmwsVk6fLC5/qQIH+0j/xd4Reh3l32cLTzeJW1jyte/lQC5PuSbfMDbBZzj7V3royKGiSG4A8zM1gB2AC/qeMEnmIHIu7eu05z2kzSa24gtiEsZsWLn6rL0pCpJdmsHmg+1Gz0AKoiIVqe64ie81HE8EQm0NBS0EAgpUCR9/Un1JO5PufpbAazPMavMqn4ircu42F+APRRwB7D6k46hVTc5KvvtZsm2kie77ePdgIaVbyHR3tcKPcNerUmQyDGrFlhVkpXeHGEVE9Sz1sT7Yq2DDccc4OzK8h8iQM9VRajZXBascb1V76eXdza1YZSENHSJIgSGRXjaIiJ4a1qsVFa5EciokkFgLDERvDvvzj/9aYLiifNhTbaVGklHJh5XRvinV3uFjkIsOI4wnk9bmG+2kPYj0/NEevhU89aXqZ3TJpdJtdkB+RO4xnMkVTmMdx+Vj9bc4Abh60sLurjht5ZbII9nS2CCmKhxul07Nzd1pSseitOkW1rAGRr0cxXib5RU8oopUf1/zgmvsygdx/W2C84amTLDgDBWs6XJl2Ottbe+0k2QcpZFzbygqc86aR7lUhCGM53j4aiu+ETpA/dg9zfDSgCpZRwuw9hhvbtEsGSQT/ADMjgMBgY0pVPGG0YFViMjFVwE9Pn4/Hrw42xKi4HvjhBqOjzjFmUNJTU82cAjZs6uqa+LOlNInqe080MZsojXORFVFf/LrxYLfTtzj2WZ9nJIwhjTyLWUZ1nJlWCseo2JMknkNG1o1c322FI5g3NVfhyIjk/r10j3G+OE2xAHGGvr7CdFuaUMaWcA5M5ozoIrhuKz1/LXvaqEVHePn5+f59P6fPDL3+WCKp7m0r6quiw5po8dsOORo2KnhCSRtknf5cjnK4pzOe5VX5Vy9TVA0jEQqpJJAvfH//2Q=="

/***/ }),

/***/ "./assets/image/hosting/author-2.jpg":
/*!*******************************************!*\
  !*** ./assets/image/hosting/author-2.jpg ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/author-2-4a2ad16560ffa781d0f410f1bfa3bf55.jpg";

/***/ }),

/***/ "./assets/image/hosting/author-3.jpg":
/*!*******************************************!*\
  !*** ./assets/image/hosting/author-3.jpg ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4QlQaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzEzOCA3OS4xNTk4MjQsIDIwMTYvMDkvMTQtMDE6MDk6MDEgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiLz4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSJ3Ij8+/+0ALFBob3Rvc2hvcCAzLjAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/bAIQAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQICAgICAgICAgICAwMDAwMDAwMDAwEBAQEBAQECAQECAgIBAgIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMD/90ABAAH/+4ADkFkb2JlAGTAAAAAAf/AABEIADcANwMAEQABEQECEQH/xACaAAADAAMBAQAAAAAAAAAAAAAICQoFBgcCBAEAAgMBAQEBAAAAAAAAAAAABgcEBQgDAgEJEAABBAEDAgYABQMEAwAAAAABAgMEBQYHCBESIQAJExQiMRUWQVFhCjJxIySBgpGh0REAAQIEBQEHAgQGAwAAAAAAAQIDAAQFEQYSITFBUQcTIjJhcYEIFCNykcEVM0KhsdFD4fH/2gAMAwAAARECEQA/ALFm1Hnjk/FX7n6B+z4sxvFQryn2jKMda1IQk8qPPAKwkAdyVKUohKEJHcqPYDue3cdgBYqWQlsAkk7D3MQVrCLcqJAAG+sAnqNvcgs5S7hGjlbByyXEsTVSMmkqL8GZYtKLUhqjiEoYcrmHQUe6e6/VWklDZT3IFWMZNslLNM82chS90kW2B631g1puE3X099NrFsoIQfMLncjpxHLtcdRd5OXYvX43tgzOtZ1ckSIzdlOVApPyTjrjriG3IFvZT62wkWlq96nKWoyG4kJtCnZTqUpS0uFK1+ovBRbcRmuNL+kSnqJT0qCENrSba30v6iCR0wlbvNG8KsLDdLkGGbgGaijasn8s0hxNjDM1Nozx+L1ULT1MpVXkFXDipcdZmiXClygjkRhyAb6UxAW0hioj8S9yrix2/tFZNUJwKK5MnYeHn9PWChosiq8po6jJqGWZtNf10a1rJSkLaW9DlthxpTjSiS04kHhSeTwfokcEkrLzUw0HmSC0RfTUawNPtuMult+4dvrfTWMiVq7J5PBJP2eew8dI5x//0LE21J6j+5BT/wBifFoELUcqPOdveKUuN28Xl5gEPMS1qudKtFqzHsdtFUdtqna2NBa3bTxiyq3CaiA1MyNuFKQQ5CfuPcsw1vJ+aWXHEo+ahyKY5qq6XTUfbHxPED5B8X/UEODqc1PT7n3KcxZ1sNdxof8AfSE96MZjYy3Sigaaq64pVEfyWzcVBltwEpCFRoMZP+4roL7hAUy0fdSh8XHEpJQUc5OOXCf+PNf5h4S9PQ54ilKVqTlGov8APMOZ22S6CkhwqyhdadcC2pFo7Os4cObLffSgvSp0NC5NlFjoCAmPEQhIZR9lRJJvaROd473bdyrfb94qKpSw14ikhYBg5tQ8fq9RcAu8ZuHm3ccySnsae8ZMixoocjHpkd2DdMsTatbdxLYfiSVNuvIdjhSFek2S6sAFDzofRcXvtqLbQIoKg+SrcRyfRikr8Fxh7AqKW7NxTEpLcLGnyCiHXwnYzK/y3RwiB+FY3jzKWmIMPuIrQKAe3gwwm+p2XVLq2QbfpAdiuXS08maRsRcx1xLg6h0nj7+1BX6f+vBVAz3iOsf/0bCEr+ZV34HI4/n9+PrxboWErCjwYG1pK0FA3IhHHnQ5ZEpU6Kx7WeivpK3EM5y+0lPgqYhxYd9WV7lgWxwuXPY+LcNhPJdkOpJHwB8KztJU42zLS58WQqUSNjfa3MNzs0aC1zMw3YvrCUgHi3m/URPJcbo9epOQUdRjml2oekGBY6+E4887YYpLjZ9F62G40vLorkZ7Jos7JHZKn40iG+GmOhDLoT1JAVcwlpEkJpDqVrzAFsA5k35JOlgdNNztDppMkV1QMTMo+kBJUHLpyaenm2hs+rWf667N9xWh9PFha+ZXD1LxDArC7xXSaHpzDZcl5EpsWsyXd6iNQaluTSLcQHkv2DPUAAByO82TExJznclxDJ0N1A2IIvYWufT39Im1VyTn5Bx6WbLq0qKcqbAjre+nr7Q7/cvuAx7b9oXpvuczleo1Pgc3ONMcDyxvMqKNQZbiMvU20bw6BluZ0lVLl01eMBdlPOve0MiGA76zBUpQdJxNklSXkEFohIvtrbXT4MKF+VCSZZ3K3PBKlEDxAJBTzYa+IcDW4417vppNe/J8pLiKtlpGYZKmiXTyPcw5GKuyGpmPSQ8Cr1FyqmUy8pfJLjjqlH9ADPBrSgl9Z2Ssj39RCxxg+ltLUr5nFp3G3+439qR8vmo8/p/48F8CEf/Sr6bc44HH0rjnnxYrF0EbaRQIICgTteFaebttUyLcttsTe4HWv3Ge6Pzhkox+GnmXk2Aty4lvltZGT1JU/Jq01aZzTKeVOhLiQCrjwF4ypKqtTS62pQmWspAABCgDre+o06Qb4Iq7dIqyG1KHcOKNyTYgkaWGx101iYHMdxiXrfSh/KhXxqPGbCsvm6GXbV1Q9ldTWXMYPvQXJiQJVXRlKVyWUFCgVJKlJH2ikBbodV3SUOJsFAEnQKuDr1IjXiJlbyZeWlVrW5MAoRZsrAJTqTkNwLbE6E6RQZvT3ZRNRdONGNwODsVKtNKe5qqLUTFcgscMmyssr5ZqG6bIMLrWpf5lauWWlOuy6lsSlGG2h0pBSVG3qs21UmmppDXdrSEpVa9rja1+CP7+8QKBRJjDVQfo1U8anApxKyhSCOCLKJCrHXMLW24uS+8y6Dhetuy7Qzba8rJFZFuZ1a0v070moMXpZFo/Z51jdXP1D9xfvMx3YmM4Ri9BRyrK1tpnRDitR2wpQU62lRm4Jicp7EtT2wpZtmubbW26nxAkD/ANk+tUlSa3PTFbXmVkUEG3C9r20A/DIB/ci5h4HhzGnuC4XgkWV+IIxDF6HHnrEIKPxOVT1MKrk2BSr5p92qGFAKPV08c9/pp0WTVTqamWXq+tAK/RXIHX5jPtcmU1GqKmEaMIcOQb3Txvt8RvMccLQOCAkK7n+e/8eLKK+P/TrvQs/ZP2ST2/n/54stxA8ekZOLIU26282oBxs9SSQCn4/aVJUOlaVpHBSeQQe/bx5ycJA10N9dDofm2x4jyRay0hRUk5hY63Go/85iUzzJdh7+iG4TAs40heTi+Bag5RcZlpVZy4SZlNgOpE0E6laOrkOK9BqpyKvcFtVx3SpDsFx5kpX7bgJXFVBdotWW9Tmr094WspRvm8xNz/AIjVXZXimTxDJIplcb711sDPlu2oN3yjIUEFCr7qG40hv+mG3yFrhpzovk24yLX59n+FvRbfB4z1VXxqyglV8dESKjTvBaxpiloW3oqQm1ti2Zlg2S068lnho07riqjLJlFpQ2pB0Sk6qG5JI6GCurT8jSqm41RmHGacBYqcUp1ZPB7xwlVgNLC3WGTsYxGrzjM+fXQVXNBT3FfRTQyDKoIeRCExk0OtkdfDCLxmtjNSFNpSpxhoNc+nyCzcEpljIPqKCJpgpy3JNr7kjm/EZ07SFPuVNhIXmlXQSq2hNuL72F9vWPtLXHPHHHJ4HSBx3/f9ePB6q+Y33hYpSlaQvrHkNhJBI4H+f48fI9d2mP/Uqgz7V7TTSxiM9qFnVBinvG1vQ4U+SuRczWknn1IdHXtS7V1pSe6XC0G1foonsPtQrlDo3jqTpSUi9uDbiIlOodWrBCadKPWJtmJ0F+T6DmJ7fNE/qM8I2d2UHRvarpbF1k1yu8ZbyG1zHVZNtj+mmllfZyHmsdku4dVus5BqBdXEaI9KRFenVUWMwWlver6hbFnh1bOIkicklEyYcSSb2AFxpyfEL6WsbWJG8cK5T5mhPGXmiW5nulaDcnLuOAR+/MKnv98G6vfxopo3qFuG1Dj3q7SfdZlAwzCaGBgWDYHYTLiZTRBieP1HW+1MqqiC02mZNlzJiw46r1B6hT4QHaNWJqbr8zTgpQkpdzwi5tfLY252vueY0T2b0SVp1FlqhLLJqLyPGv8ArKM1xmItfW3A1iiTyq8jyfE4LNDf2uQ5BJsAzKl299Kn28xcVaE+0iKsJy3n24oA+LKVJbT99PPhe4emVNVa5Uc3vDLxUhM1SAuwKgLE8k9TB+eYxvMxrZVtgzvWxyNVXWoEJ+vxbSXC7Rx72eX6jZE8lqoqrRER1mcaGthtSJ9gppbam48YgKBUOdGdmlKqGKMZylHp5UWnSfuEjYpB8JV1yjbpGZu0F1ml4UmqnNhOZgXaUb3CiNUp9VHe+mUE7gAir5ZXmhQ/MLj6t09xpLF0kzHRdnFXb52pyqTk2LZGMnkz4QNUixroVzUOQ5FeVFD630Lbc+KwRwXf2mYVpXZ7NSy/4i263PTBYSle6VDn83UwksD1ar4zS+pmnOJLUsCQny5+SnpDWeUqUnpUlaSCQUnqSf8ACh2PgGYclpi/2ay4BveCV9qZl7CdQG1ekf/VIvGru8zubb53qBPm3mV5bcvy7m0muokS3H5MrqRGbWlxTcavgoWGY0ds+jHZQlCRwO+VqzOz9QedqM+bulBAF9NdI1fQZCRlJRFIkbpb2PzET277JrzW7dJuE1JRELEa51JyuHTx1Psp9pjmKIZxeihoQt4KbDcSsbV0kAAqUeOT43TgXDrNNw5T6MkjK20Hr+q0i4PXUmMY43rS53EczPPg5XVlq35TofS6QmLFvLt0hg3OznabkUjGsYt6uTo5iPuI1hUVnqSFsGbCmiaE9AkOKnxXep3+9ZAVz+vjJPaBJAYwn2x5e+JEa2wIuXODZFaRZ1LWvx6+8PF0uxYYrBC8ZYiUYU2236UZtAQx3CgWyOogJ6uwH9oHgakmVy7wW1bvSbA+8T5qfRMoVLu/yRvvEofnIbxcy3CbhLHRapkLVpntVnXFMf8AREOTlmsORxo0TKMlsTKcTKfi4/Vtpq4IIS2E+u6gKLoV4/Qj6XsFnD2HqhjeZWFTs6stnmyWjlT7aHi0Yj+oLFLdbxDI4RlklMnJt94DtcuAqN9r6jS8d1/p+MousLtt5Vy80v2VrK0hZlNB5tbxLjeXzI6UKS8opaaSByP1IH/AD9WNS7lqgOtgFRmZ87ckJg7+munfcsVh5ZsWzIgfBUDt7RYrt3sa/UKBNYsDISpIDzCPkFNoHHcOAq4Uvp7j9vGd8IPVBcwoySsqcvJht44apyGU/dpClZ+nr7R//9k="

/***/ }),

/***/ "./assets/image/hosting/footer-bg.png":
/*!********************************************!*\
  !*** ./assets/image/hosting/footer-bg.png ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/footer-bg-61e61976e8a4ea1e4ff698142517ef3a.png";

/***/ }),

/***/ "./assets/image/hosting/icon1.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon1.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4OC44NyA4MS40MyI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiMwZjIxMzc7fS5jbHMtMntmaWxsOiNlYjRkNGI7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5WZWN0b3IgU21hcnQgT2JqZWN0PC90aXRsZT48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xNDEuNTQsMTgzaC03N2ExLjUsMS41LDAsMCwxLTEuNS0xLjV2LTUxYTEuNSwxLjUsMCwwLDEsMS41LTEuNUgxMTNhMS41LDEuNSwwLDEsMSwwLDNINjZ2NDhoNzRWMTUzYTEuNSwxLjUsMCwwLDEsMywwdjI4LjVBMS41LDEuNSwwLDAsMSwxNDEuNTQsMTgzWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYzLjA0IC0xMjAuNTcpIi8+PHBvbHlnb24gY2xhc3M9ImNscy0yIiBwb2ludHM9IjE0Ljk3IDQ4Ljk0IDEzLjI1IDQ3LjEyIDM2Ljg2IDI0Ljg1IDQ4LjU1IDM1LjQ3IDg0LjA4IDIuNzQgODUuNzcgNC41OCA0OC41NiAzOC44NiAzNi44OSAyOC4yNSAxNC45NyA0OC45NCIvPjxwb2x5Z29uIGNsYXNzPSJjbHMtMiIgcG9pbnRzPSI4Ni42NCA3LjE0IDg4Ljg3IDAgODEuNTcgMS42NCA4Ni42NCA3LjE0Ii8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMTAzLjU0LDE5Ni41QTEuNSwxLjUsMCwwLDEsMTAyLDE5NVYxODJhMS41LDEuNSwwLDAsMSwzLDB2MTNBMS41LDEuNSwwLDAsMSwxMDMuNTQsMTk2LjVaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjMuMDQgLTEyMC41NykiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0xMTgsMjAySDg5YTEuNSwxLjUsMCwwLDEsMC0zaDI5YTEuNSwxLjUsMCwxLDEsMCwzWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYzLjA0IC0xMjAuNTcpIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/hosting/icon2.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon2.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA4MC4yOCA4Ni4zMyI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiMwZjIxMzc7fS5jbHMtMntmaWxsOiNlYjRkNGI7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5WZWN0b3IgU21hcnQgT2JqZWN0MTwvdGl0bGU+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNDc0Ljg2LDIwMC44OGExLjM0LDEuMzQsMCwwLDEtLjUxLS4xMWMtMTUuNTYtNi45Mi0yNy0xNy0zMy0yOS05LjEzLTE4LjI3LTYuNDEtNDYuMzMtNi4yOS00Ny41MmExLjI2LDEuMjYsMCwwLDEsLjYtLjk0LDEuMjMsMS4yMywwLDAsMSwxLjEyLS4wOSwyMy40OSwyMy40OSwwLDAsMCw4Ljg2LDEuNjJjMTIuMjcsMCwyNC41NS03LjY0LDI2Ljc0LTkuNjlhMi4xOCwyLjE4LDAsMCwxLDEuNDUtLjU2LDIuMywyLjMsMCwwLDEsMS4yNi40NGMzLjkyLDIuNzMsMTYuNzEsOS44MSwyOC43Myw5LjgxYTIzLjc2LDIzLjc2LDAsMCwwLDktMS42MiwxLjIzLDEuMjMsMCwwLDEsMS4xMi4wOSwxLjI3LDEuMjcsMCwwLDEsLjYsMWMuMTEsMS4xOCwyLjUsMjkuMDktNi4zMiw0Ny40OS05Ljc1LDIwLjM0LTI3LjE1LDI2LjkyLTMyLjg3LDI5LjA5QTEuMzIsMS4zMiwwLDAsMSw0NzQuODYsMjAwLjg4Wm0tMzcuNDUtNzQuODFjLS40Myw2LjI2LTEuNDMsMjkuMzYsNi4xNyw0NC41NCw3LjE5LDE0LjM4LDIwLjksMjMsMzEuMzIsMjcuNjcsNS45My0yLjI2LDIyLTguNzUsMzEtMjcuNjUsNy4zNC0xNS4zMSw2LjU2LTM4LjI5LDYuMTktNDQuNTVhMjcuMTYsMjcuMTYsMCwwLDEtOC4zLDEuMjJjLTEyLjQ5LDAtMjUuNjktNy4yLTMwLTEwLjE0LTMuNjMsMy4xNy0xNi4xNCwxMC4xNC0yOC4yLDEwLjE0QTI2LjYxLDI2LjYxLDAsMCwxLDQzNy40MSwxMjYuMDdaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDM0LjU4IC0xMTQuNTUpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNDc1LjE5LDE3Ni41MmEyMS4zMiwyMS4zMiwwLDEsMSwyMS4zMi0yMS4zMkEyMS4zNCwyMS4zNCwwLDAsMSw0NzUuMTksMTc2LjUyWm0wLTQwLjE0QTE4LjgyLDE4LjgyLDAsMSwwLDQ5NCwxNTUuMiwxOC44NCwxOC44NCwwLDAsMCw0NzUuMTksMTM2LjM4WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQzNC41OCAtMTE0LjU1KSIvPjxwb2x5Z29uIGNsYXNzPSJjbHMtMiIgcG9pbnRzPSIzOS4wOSA1MC41NSAyOS4xNSAzOS41MSAzMS4wMSAzNy44MyAzOC45NiA0Ni42NyA1MC40NyAzMS45NCA1Mi40NCAzMy40OCAzOS4wOSA1MC41NSIvPjwvc3ZnPg=="

/***/ }),

/***/ "./assets/image/hosting/icon3.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon3.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA3NS41IDgwLjIxIj48ZGVmcz48c3R5bGU+LmNscy0xe2ZpbGw6I2ViNGQ0Yjt9LmNscy0ye2ZpbGw6IzBmMjEzNzt9PC9zdHlsZT48L2RlZnM+PHRpdGxlPlZlY3RvciBTbWFydCBPYmplY3QyPC90aXRsZT48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik00NzMuMzksMzcxLjQ1YTQuMjEsNC4yMSwwLDAsMS0xLjI3LS4yQTcuNTcsNy41NywwLDAsMSw0NzAsMzcwbC05LjA5LTguNTZhNy43NSw3Ljc1LDAsMCwxLDAtMTEuMzVMNDYxLDM1MGE4LjYxLDguNjEsMCwwLDEsMTEuNzYsMGwuNTQuNTEuNTQtLjUxYTguNjEsOC42MSwwLDAsMSwxMS43NywwbC4xNC4xM2E3Ljc1LDcuNzUsMCwwLDEsMCwxMS4zNWwtOS4zMiw4Ljg2YTYuNTcsNi41NywwLDAsMS0xLjgxLDFBMy44LDMuOCwwLDAsMSw0NzMuMzksMzcxLjQ1Wm0tNi40OC0yMS4zMmE2LDYsMCwwLDAtNC4xNywxLjY0bC0uMTQuMTRhNS4yNSw1LjI1LDAsMCwwLDAsNy43Mmw5LDguNWE1LjM2LDUuMzYsMCwwLDAsMS4yNC43NCwxLjY1LDEuNjUsMCwwLDAsMSwwLDQuMTMsNC4xMywwLDAsMCwxLjA1LS41N2w5LjE4LTguNzNhNS4yNSw1LjI1LDAsMCwwLDAtNy43MmwtLjE0LS4xM2E2LjEsNi4xLDAsMCwwLTguMzIsMGwtMi4yNiwyLjE1LTIuMjctMi4xNEE2LDYsMCwwLDAsNDY2LjkxLDM1MC4xM1oiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MzQuNzkgLTMwNC41NCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00MzkuNTQsMzMxLjMyYTEuMjQsMS4yNCwwLDAsMS0xLTJsMTcuMzktMjQuMWExLjI1LDEuMjUsMCwwLDEsMiwxLjQ2bC0xNy4zOSwyNC4xQTEuMjQsMS4yNCwwLDAsMSw0MzkuNTQsMzMxLjMyWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQzNC43OSAtMzA0LjU0KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTUwNi4yNCwzMzEuNWExLjI1LDEuMjUsMCwwLDEtMS0uNTRMNDg4LjMyLDMwNi41YTEuMjUsMS4yNSwwLDAsMSwyLjA2LTEuNDJsMTYuODksMjQuNDZhMS4yNSwxLjI1LDAsMCwxLTEsMloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MzQuNzkgLTMwNC41NCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00NTMsMzg0Ljc2Yy0xLjE5LDAtNS4yMS0uMjItNy40Ni0zLTEuMzctMS42Ny0yLjE1LTYuNjYtMi4yOS03LjY0bC02LjQyLTMxLjUxYTEuMjUsMS4yNSwwLDAsMSwyLjQ1LS41bDYuNDMsMzEuNThjLjMzLDIuMjMsMS4wOCw1LjY1LDEuNzYsNi40OSwxLjgsMi4yLDUuNzYsMiw1LjgsMmg0MC40OXMzLjE0LDAsNC44MS0xLjk1YTEwLjE5LDEwLjE5LDAsMCwwLDEuODUtNC43Mmw1LjY3LTMxLjQ0YTEuMjUsMS4yNSwwLDEsMSwyLjQ2LjQ0TDUwMi45MiwzNzZhMTIuNjQsMTIuNjQsMCwwLDEtMi40NCw2Yy0yLjQyLDIuNzctNi41MiwyLjgtNi42OSwyLjhINDUzWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQzNC43OSAtMzA0LjU0KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTUwOSwzMzcuNzVINDM2YTEuMjUsMS4yNSwwLDEsMSwwLTIuNWg3M2ExLjI1LDEuMjUsMCwwLDEsMCwyLjVaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDM0Ljc5IC0zMDQuNTQpIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/hosting/icon4.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon4.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5My4zNyA4NS4wOSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiMwZjIxMzc7fS5jbHMtMntmaWxsOiNlYjRkNGI7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5WZWN0b3IgU21hcnQgT2JqZWN0MzwvdGl0bGU+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMjc5LjM1LDIwMmEyLjMyLDIuMzIsMCwwLDEtLjU4LS4wOGwuNTgtMi4xNC0uNjIsMi4xM2EyLjIyLDIuMjIsMCwxLDEsMS4wNy00LjNsLjEzLDBhMi4yMiwyLjIyLDAsMCwxLS41OCw0LjM2Wm0tMTAtNC4xMWEyLjI0LDIuMjQsMCwwLDEtMS4wOC0uMjlsLS4xMy0uMDhhMi4yLDIuMiwwLDEsMSwxLjIxLjM3Wm0tOC41NS02LjU1YTIuMTksMi4xOSwwLDAsMS0xLjU1LS42NWwwLDBhMi4yNiwyLjI2LDAsMCwxLDAtMy4xNSwyLjIxLDIuMjEsMCwwLDEsMy4xMSwwbC4wNi4wNmEyLjIzLDIuMjMsMCwwLDEtMS41NywzLjhabS02LjU5LTguNTRhMi4xNywyLjE3LDAsMCwxLTEuODgtMS4wOWwtLjA1LS4wOWEyLjIyLDIuMjIsMCwwLDEsMy44Ni0yLjE5LDIuMjQsMi4yNCwwLDAsMS0xLjkzLDMuMzdabS00LjEzLTEwYTIuMTgsMi4xOCwwLDAsMS0yLjExLTEuNmwwLS4wOWEyLjIyLDIuMjIsMCwxLDEsNC4yOC0xLjE1LDIuMjUsMi4yNSwwLDAsMS0xLjU0LDIuNzZBMi42MiwyLjYyLDAsMCwxLDI1MC4xMiwxNzIuODhabTc5LjY4LTIxLjQ2YTIuMjEsMi4yMSwwLDAsMS0yLjEzLTEuNjQsMi4yNCwyLjI0LDAsMCwxLDEuNTQtMi43NiwyLjE4LDIuMTgsMCwwLDEsMi43MSwxLjUybDAsLjA5YTIuMiwyLjIsMCwwLDEtMi4xNSwyLjc5Wm0tNC4xNC05Ljk0YTIuMiwyLjIsMCwwLDEtMS44OC0xbC0uMDctLjEzYTIuMjIsMi4yMiwwLDEsMSwzLjg0LTIuMjFsLTEuOTIsMS4xLDEuOTMtMS4wN2EyLjIxLDIuMjEsMCwwLDEtLjc1LDNBMi4xNywyLjE3LDAsMCwxLDMyNS42NiwxNDEuNDhaTTMxOS4xLDEzM2EyLjIxLDIuMjEsMCwwLDEtMS41NS0uNjNsLS4wOC0uMDhhMi4yMiwyLjIyLDAsMCwxLDMuMTQtMy4xM2wuMDUsMGEyLjIyLDIuMjIsMCwwLDEtMS41NiwzLjhabS04LjU0LTYuNTRhMi4yLDIuMiwwLDAsMS0xLjE1LS4zMiwyLjIyLDIuMjIsMCwwLDEtLjg0LTMsMi4yLDIuMiwwLDAsMSwzLS44NGwuMTMuMDdhMi4yMiwyLjIyLDAsMCwxLTEuMTUsNC4xMlptLTkuOTUtNC4xMWEyLDIsMCwwLDEtLjUzLS4wN2wtLjE0LDBhMi4yMiwyLjIyLDAsMCwxLDEuMTctNC4yOGwtLjU4LDIuMTQuNjItMi4xM2EyLjIyLDIuMjIsMCwwLDEtLjU0LDQuMzdaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQyLjk3IC0xMTcuNTIpIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMjQ4LjU3LDE2MS4zMWExLjI1LDEuMjUsMCwwLDEtMS4yNS0xLjI1LDQyLjU5LDQyLjU5LDAsMCwxLDQyLjU1LTQyLjU0LDEuMjUsMS4yNSwwLDAsMSwwLDIuNSw0MC4wOSw0MC4wOSwwLDAsMC00MC4wNSw0MEExLjI1LDEuMjUsMCwwLDEsMjQ4LjU3LDE2MS4zMVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yNDIuOTcgLTExNy41MikiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0yODkuODcsMjAyLjYxYTEuMjUsMS4yNSwwLDAsMSwwLTIuNSw0MC4wOSw0MC4wOSwwLDAsMCw0MC00MC4wNSwxLjI1LDEuMjUsMCwwLDEsMi41LDBBNDIuNTksNDIuNTksMCwwLDEsMjg5Ljg3LDIwMi42MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yNDIuOTcgLTExNy41MikiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0zMzUuMDksMTY1LjE0YTEuMjUsMS4yNSwwLDAsMS0xLS40OGwtMy0zLjc4LTQsMy4zM2ExLjI1LDEuMjUsMCwwLDEtMS42LTEuOTJsNS00LjE2YTEuMywxLjMsMCwwLDEsLjkzLS4yOCwxLjI2LDEuMjYsMCwwLDEsLjg1LjQ3bDMuNzcsNC43OWExLjI2LDEuMjYsMCwwLDEtMSwyWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Mi45NyAtMTE3LjUyKSIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTI0OC4yMiwxNjQuNDFoLS4wOWExLjMxLDEuMzEsMCwwLDEtLjg3LS40NGwtNC00Ljc5YTEuMjUsMS4yNSwwLDAsMSwxLjkyLTEuNjFsMy4xOCwzLjgxLDQtMy41NUExLjI1LDEuMjUsMCwxLDEsMjU0LDE1OS43bC01LDQuNEExLjI2LDEuMjYsMCwwLDEsMjQ4LjIyLDE2NC40MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yNDIuOTcgLTExNy41MikiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0yOTAsMTYyaC00Ljg5YTguMyw4LjMsMCwwLDEtOC4xMS04LjQ1VjE1MmE3Ljg2LDcuODYsMCwwLDEsOC4xMS03Ljk1SDMwMHYzSDI4NS4xNUE0Ljg3LDQuODcsMCwwLDAsMjgwLDE1MnYxLjZhNS4zMSw1LjMxLDAsMCwwLDUuMTEsNS40NUgyOTBaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQyLjk3IC0xMTcuNTIpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNMjk0LjMxLDE3N0gyNzh2LTNoMTYuMjdhNiw2LDAsMCwwLDUuNzMtNS42MnYtMS41OWMwLTIuNjQtMi41Ny00Ljc5LTUuNzMtNC43OUgyODl2LTNoNS4yN2M0Ljg5LDAsOC43MywzLjQyLDguNzMsNy43OXYxLjU5QTksOSwwLDAsMSwyOTQuMzEsMTc3WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Mi45NyAtMTE3LjUyKSIvPjxyZWN0IGNsYXNzPSJjbHMtMiIgeD0iNDQuMDciIHk9IjIyLjQ4IiB3aWR0aD0iMyIgaGVpZ2h0PSI1Ii8+PHJlY3QgY2xhc3M9ImNscy0yIiB4PSI0NC4wNyIgeT0iNTcuNDgiIHdpZHRoPSIzIiBoZWlnaHQ9IjUiLz48L3N2Zz4="

/***/ }),

/***/ "./assets/image/hosting/icon5.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon5.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5My43IDk3Ljg5Ij48ZGVmcz48c3R5bGU+LmNscy0xe2ZpbGw6IzBmMjEzNzt9LmNscy0ye2ZpbGw6I2ViNGQ0Yjt9PC9zdHlsZT48L2RlZnM+PHRpdGxlPlZlY3RvciBTbWFydCBPYmplY3Q0PC90aXRsZT48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik04NS4wOSwzNjMuNzVINzZhMy43LDMuNywwLDAsMS0zLjctMy43VjMzMmEzLjcsMy43LDAsMCwxLDMuNy0zLjdoOS4xYTMuNywzLjcsMCwwLDEsMy43LDMuN3YyOC4xQTMuNywzLjcsMCwwLDEsODUuMDksMzYzLjc1Wm0tOS4xLTMzYTEuMiwxLjIsMCwwLDAtMS4yLDEuMnYyOC4xYTEuMiwxLjIsMCwwLDAsMS4yLDEuMmg5LjFhMS4yLDEuMiwwLDAsMCwxLjItMS4yVjMzMmExLjIsMS4yLDAsMCwwLTEuMi0xLjJaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTIuOTkgLTI5My4xMSkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik05NC40MywzMzMuODZhMS4yNSwxLjI1LDAsMCwxLS41NS0yLjM3Yy4wNSwwLDQuMy0yLjEzLDUuNzgtNS4xbC40MS0uODFhMTkuNjQsMTkuNjQsMCwwLDAsMi42Ni04LjE3Yy4wOS0yLDItMy42Myw0LjM1LTMuNzJzNS4yNywxLjQzLDUuODEsNmMuNCwzLjQzLS41MSw3Ljk1LTEuNTEsMTEuNTlIMTIyYTEuMjUsMS4yNSwwLDEsMSwwLDIuNUgxMDhsLjQ5LTEuNjFjMS41NC01LjEsMi4yMS05LjQzLDEuODktMTIuMTktLjI5LTIuNDItMS41LTMuODYtMy4yNC0zLjc2LTEsMC0xLjkxLjYzLTIsMS4zM2EyMiwyMiwwLDAsMS0yLjkyLDkuMmwtLjQuNzljLTEuODcsMy43My02LjcyLDYuMTItNi45Miw2LjIyQTEuMjMsMS4yMywwLDAsMSw5NC40MywzMzMuODZaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTIuOTkgLTI5My4xMSkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0xMjIuMTEsMzQxLjloLTEuMjlhMS4yNSwxLjI1LDAsMCwxLDAtMi41aC43M2MxLjI2LDAsMS43OCwwLDIuNTktLjc0YTMuNDEsMy40MSwwLDAsMCwuMzUtMy4yOGMtLjQ4LTEuMTUtMS42MS0xLjctMy4zNy0xLjY0YTEuMjEsMS4yMSwwLDAsMS0xLjI5LTEuMiwxLjI0LDEuMjQsMCwwLDEsMS4yLTEuMjljMy43OS0uMTUsNS4yNCwxLjkxLDUuNzYsMy4xNWE1LjgzLDUuODMsMCwwLDEtLjkyLDYuMDdBNC44Niw0Ljg2LDAsMCwxLDEyMi4xMSwzNDEuOVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi45OSAtMjkzLjExKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTEyMSwzNDkuMTJsLS43NiwwYy0uMzEsMC0uNjQsMC0xLDBhMS4yNSwxLjI1LDAsMSwxLS4xMi0yLjVjLjQsMCwuOCwwLDEuMTksMCwxLjE0LDAsMS43MSwwLDIuMzEtLjU1YTIuMzUsMi4zNSwwLDAsMCwuNDktMS44OSwxLjI1LDEuMjUsMCwwLDEsMi40OC0uMzMsNC43Miw0LjcyLDAsMCwxLTEuMjEsNEE0LjQ4LDQuNDgsMCwwLDEsMTIxLDM0OS4xMloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi45OSAtMjkzLjExKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTExOS4zMiwzNTZsLS43NiwwYy0uMzIsMC0uNjQsMC0xLDBhMS4yNSwxLjI1LDAsMCwxLS4xMS0yLjVjLjQsMCwuNzksMCwxLjE4LDAsMS4xNC4wNSwxLjcyLjA1LDIuMzEtLjU1YTIuMzEsMi4zMSwwLDAsMCwuNTEtMS43NywxLjI1LDEuMjUsMCwxLDEsMi40OS0uMjIsNC42NCw0LjY0LDAsMCwxLTEuMjMsMy43NkE0LjQ4LDQuNDgsMCwwLDEsMTE5LjMyLDM1NloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi45OSAtMjkzLjExKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTExNy42OSwzNjIuMDljLS4yNywwLS41MywwLS43NywwLS43LDAtMjQuMjUsMC0yNC43OSwwaDBhMS4yMywxLjIzLDAsMCwxLS4wNi0yLjQ2Yy40NiwwLDI0Ljc0LDAsMjQuODgsMGguMWMxLjE0LjA1LDEuNzIuMDUsMi4zMS0uNTVhMS44OSwxLjg5LDAsMCwwLC41MS0xLjE5LDEuMjUsMS4yNSwwLDAsMSwyLjQ5LjI2LDQuMzgsNC4zOCwwLDAsMS0xLjIzLDIuN0E0LjQ1LDQuNDUsMCwwLDEsMTE3LjY5LDM2Mi4wOVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi45OSAtMjkzLjExKSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTExNCwzMzMuNzVoLTdhMS4yNSwxLjI1LDAsMCwxLDAtMi41aDdhMS4yNSwxLjI1LDAsMSwxLDAsMi41WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUyLjk5IC0yOTMuMTEpIi8+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNODIuMSwzNTYuNjJhMS4zNCwxLjM0LDAsMSwxLTEuMzQtMS4zM0ExLjM0LDEuMzQsMCwwLDEsODIuMSwzNTYuNjJaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTIuOTkgLTI5My4xMSkiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik05OS4xMSwzOTFIOTljLTMuMTIsMC01LjQyLTMuMTEtNy42NS01Ljg4LTEuNTctMS45NS0zLjE5LTQuMDYtNC43OC00LjYxcy00LjEyLDAtNi42Mi41N2EyNS41OSwyNS41OSwwLDAsMS01LjYzLjg5LDYuMTcsNi4xNywwLDAsMS0zLjgyLTEuMTJjLTIuNDMtMS44My0yLjYyLTUuNDYtMi44LTktLjEzLTIuNTQtLjI2LTUuMTgtMS4yNy02LjYxUzYzLjE3LDM2Myw2MC45LDM2MmMtMy4zMi0xLjM4LTYuNzQtMi44MS03LjY3LTUuODVTNTQuMzMsMzUwLDU2LjMsMzQ3YzEuMzUtMi4wNywyLjc1LTQuMiwyLjc4LTUuODNzLTEuMzMtNC0yLjY1LTYuMThjLTEuODItMy0zLjY5LTYuMTEtMi43LTlzNC40MS00LjIxLDcuNzEtNS40N2MyLjM2LS45LDQuOC0xLjgzLDUuODMtMy4yczEuMjItMy45MiwxLjQzLTYuNDFjLjI5LTMuNTUuNTktNy4yMiwzLjE0LTlhNS44MSw1LjgxLDAsMCwxLDMuNDMtMSwyMy40NiwyMy40NiwwLDAsMSw1LjgzLDEuMDljMi41Mi42OCw1LjIxLDEuMzIsNi44LjgzczMuNDYtMi41NCw1LjE1LTQuNWMyLjI1LTIuNiw0LjU4LTUuMjksNy41My01LjI5LDMuMTkuMDUsNS41LDIuOTIsNy43Myw1LjY5LDEuNTYsMiwzLjE4LDQsNC43Nyw0LjUyczQuMTIsMCw2LjYyLS42MmEyNi4yNywyNi4yNywwLDAsMSw1LjYzLS45MSw2LjE2LDYuMTYsMCwwLDEsMy44MiwxLjExYzIuNDMsMS44MywyLjYyLDUuNDUsMi44LDksLjEzLDIuNTQuMjYsNS4xNywxLjI3LDYuNnMzLjI5LDIuMzIsNS41NywzLjI3YzMuMzEsMS4zOCw2Ljc0LDIuODEsNy42Nyw1Ljg1cy0xLjExLDYuMTQtMy4wOCw5LjE0Yy0xLjM1LDIuMDctMi43NSw0LjItMi43OCw1LjgzczEuMzQsNCwyLjY1LDYuMThjMS44MiwzLDMuNyw2LjExLDIuNzEsOXMtNC40Miw0LjIxLTcuNzIsNS40N2MtMi4zNi45LTQuOCwxLjgzLTUuODMsMy4ycy0xLjIyLDMuOTItMS40Miw2LjQxYy0uMjksMy41NS0uNTksNy4yMi0zLjE1LDlhNS44MSw1LjgxLDAsMCwxLTMuNDMsMSwyMy40NiwyMy40NiwwLDAsMS01LjgzLTEuMDljLTIuNTItLjY3LTUuMjEtMS4zMi02Ljc5LS44My0xLjczLjUzLTMuNDcsMi43My01LjE2LDQuNjhDMTA0LjM4LDM4OC4xMiwxMDIuMDUsMzkxLDk5LjExLDM5MVpNODUsMzc3LjdhNy4zNiw3LjM2LDAsMCwxLDIuMzkuMzZjMi4yNy43OCw0LjEyLDMuMDgsNS45MSw1LjMxczMuNzYsNC43Myw1LjcsNC43NnYwYzIsMCwzLjc4LTIuMjUsNS42Ny00LjQzczMuOTItNC41MSw2LjMzLTUuMjVhNy4yOCw3LjI4LDAsMCwxLDIuMTYtLjMsMjQuMTQsMjQuMTQsMCwwLDEsNiwxLjExLDIyLjE2LDIyLjE2LDAsMCwwLDUuMTksMSwzLjQyLDMuNDIsMCwwLDAsMi0uNTFjMS41OS0xLjExLDEuODQtNC4xOSwyLjA4LTcuMTZzLjQ4LTUuNzksMS45Mi03LjcxLDQuMjUtMyw2Ljk0LTQsNS42Mi0yLjE0LDYuMjQtMy45NC0xLTQuMzctMi40OC02Ljg4LTMuMDUtNS0zLTcuNTEsMS42NC00LjgsMy4xOS03LjE2YzEuNjUtMi41MiwzLjM2LTUuMTIsMi43OC03cy0zLjQ3LTMuMTEtNi4yNS00LjI3Yy0yLjYtMS4wOS01LjMtMi4yMi02LjY1LTQuMTVzLTEuNTctNS0xLjcyLTcuOS0uMy02LTEuOC03LjA5YTMuNzUsMy43NSwwLDAsMC0yLjMyLS42MSwyMy44NywyMy44NywwLDAsMC01LjA2Ljg1LDI2LjE1LDI2LjE1LDAsMCwxLTUuNjIuOSw3LjI2LDcuMjYsMCwwLDEtMi4zOC0uMzZjLTIuMjgtLjc4LTQuMTMtMy4wOC01LjkxLTUuMzFzLTMuOC00LjczLTUuNzUtNC43NmgwYy0xLjg0LDAtMy43OSwyLjI1LTUuNjcsNC40M3MtMy45LDQuNTEtNi4zMSw1LjI1YTcuMjgsNy4yOCwwLDAsMS0yLjE2LjMsMjQuMjIsMjQuMjIsMCwwLDEtNi0xLjExLDIyLDIyLDAsMCwwLTUuMTgtMSwzLjQyLDMuNDIsMCwwLDAtMiwuNTFjLTEuNTksMS4xMS0xLjg0LDQuMTktMi4wOCw3LjE2cy0uNDgsNS43OS0xLjkyLDcuNzEtNC4yNSwzLTYuOTQsNC01LjYyLDIuMTQtNi4yNCwzLjk0LDEsNC4zNywyLjQ4LDYuODgsMyw1LDMsNy41MS0xLjY0LDQuOC0zLjE5LDcuMTZjLTEuNjUsMi41Mi0zLjM2LDUuMTItMi43Nyw3czMuNDYsMy4xMSw2LjI0LDQuMjdjMi42LDEuMDksNS4zLDIuMjIsNi42NSw0LjE1czEuNTcsNSwxLjcyLDcuOS4zMSw2LDEuOCw3LjA5YTMuNzcsMy43NywwLDAsMCwyLjMyLjYxLDIzLjg3LDIzLjg3LDAsMCwwLDUuMDYtLjg1QTI2LjI1LDI2LjI1LDAsMCwxLDg1LDM3Ny43WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUyLjk5IC0yOTMuMTEpIi8+PC9zdmc+"

/***/ }),

/***/ "./assets/image/hosting/icon6.svg":
/*!****************************************!*\
  !*** ./assets/image/hosting/icon6.svg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyBpZD0iw5HDq8Ouw6lfMSIgZGF0YS1uYW1lPSLDkcOrw67DqSAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA3Ni40NyA3Ny43NSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNlYjRkNGI7fS5jbHMtMntmaWxsOiMwZjIxMzc7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5WZWN0b3IgU21hcnQgT2JqZWN0NTwvdGl0bGU+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNNjM3LjY1LDMzMC43OWMwLTQuMDgsMy44OC01LjM0LDcuMzMtNS4zNHM3LjM2LDEuNDUsNy4zOSw1LjU4YzAsMy45MS0zLjk0LDUuNS03LjMzLDUuNS0yLjgsMC02LC42OS02LDR2Mi45M2gxMy4xOXYxLjQySDYzNy41NHYtNC4zMmMwLTQuMjQsMy45MS01LjM0LDcuNDQtNS4zNCwyLjQ5LDAsNi0uOTMsNi00LjE2cy0zLjM5LTQuMy02LTQuMy01Ljg4Ljg4LTUuODgsNC4wNloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02MTQuNTggLTMwMS43NCkiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik02NjcuNTEsMzI1LjY5djEzLjM2aDIuNDF2MS40OGgtMi40MXY0LjMySDY2NnYtNC4zMkg2NTQuM2wtLjMxLTEuNzgsMTEuMDktMTMuMDZabS0xLjQ3LDEuMS0xMC40NiwxMi4yNkg2NjZaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjE0LjU4IC0zMDEuNzQpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNjc1LjIzLDMxOS41MmMtMy41Ny0xMC0xMS44My0xNS43OC0yMi42Ni0xNS43OHMtMTkuMDgsNS43NS0yMi42NSwxNS43OGwtMS44OC0uNjdjMy44Ny0xMC44OCwxMi44MS0xNy4xMSwyNC41My0xNy4xMXMyMC42Nyw2LjIzLDI0LjU0LDE3LjExWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxNC41OCAtMzAxLjc0KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTY3OSwzMjkuODVoLTJjMC0xMi41OC03LjYzLTI2LjExLTI0LjQtMjYuMTFzLTI0LjQsMTMuNTMtMjQuNCwyNi4xMWgtMmMwLTEzLjU0LDguMjYtMjguMTEsMjYuNC0yOC4xMVM2NzksMzE2LjMxLDY3OSwzMjkuODVaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjE0LjU4IC0zMDEuNzQpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNjgyLjIyLDM0OC4xM0g2NzdWMzI4Ljg1aDUuMjdjNC44NS4wOSw4Ljc3LDQuMzgsOC43Nyw5LjY0cy0zLjk1LDkuNTktOC44Myw5LjY0Wm0tMy4yMS0yaDMuMTJjMy44MiwwLDYuOTItMy40Myw2LjkyLTcuNjRzLTMuMS03LjY0LTYuOTItNy42NEg2NzlaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjE0LjU4IC0zMDEuNzQpIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNjI4LjE3LDM0OC4xM0g2MjNjLTQuNjMtLjA1LTguMzgtNC4zNi04LjM4LTkuNjRzMy43Mi05LjU1LDguMzItOS42NGg1LjI3Wm0tNS4xMi0xNy4yOGMtMy41NywwLTYuNDcsMy40My02LjQ3LDcuNjRzMi45LDcuNjQsNi40Nyw3LjY0aDMuMTJWMzMwLjg1WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxNC41OCAtMzAxLjc0KSIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTY0NC4yOCwzNzJjLTEzLjE5LTUuODMtMTguMTEtMTguNjUtMTguMTEtMjUuMzZoMmMwLDYuMjEsNC41OSwxOC4wOCwxNi45MiwyMy41M1oiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02MTQuNTggLTMwMS43NCkiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik02NTMuNTMsMzc5LjQ5YTMuODUsMy44NSwwLDAsMS0xLjI3LS4yMmwtNi0yLjExYy0yLjMyLS44Mi0zLjQyLTMuNy0yLjQ3LTYuNDRhNS4xOSw1LjE5LDAsMCwxLDQuNjctMy43MSwzLjk0LDMuOTQsMCwwLDEsMS4yNy4yMmw2LjA1LDIuMTFhNC4xMyw0LjEzLDAsMCwxLDIuNSwyLjU5LDUuNzgsNS43OCwwLDAsMSwwLDMuODVBNS4xOSw1LjE5LDAsMCwxLDY1My41MywzNzkuNDlaTTY0OC40MSwzNjlhMy4yNiwzLjI2LDAsMCwwLTIuNzgsMi4zN2MtLjU5LDEuNywwLDMuNDQsMS4yNCwzLjg5bDYsMi4xMWMxLjI3LjQ1LDIuODItLjYxLDMuNC0yLjI2YTMuOCwzLjgsMCwwLDAsMC0yLjUxLDIuMTUsMi4xNSwwLDAsMC0xLjI4LTEuMzhMNjQ5LDM2OS4xMkExLjgzLDEuODMsMCwwLDAsNjQ4LjQxLDM2OVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02MTQuNTggLTMwMS43NCkiLz48L3N2Zz4="

/***/ }),

/***/ "./assets/image/saas/banner/bannerObject1.png":
/*!****************************************************!*\
  !*** ./assets/image/saas/banner/bannerObject1.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/bannerObject1-7b4f73bff849e81f64abc3ef3ece17b7.png";

/***/ }),

/***/ "./assets/image/saas/banner/bannerObject2.png":
/*!****************************************************!*\
  !*** ./assets/image/saas/banner/bannerObject2.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/bannerObject2-e1cd33de4f0d1f2a364cca4bf87b2422.png";

/***/ }),

/***/ "./assets/image/saas/illustration.png":
/*!********************************************!*\
  !*** ./assets/image/saas/illustration.png ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/illustration-e1d13505283e080ef19f77dc7566e00a.png";

/***/ }),

/***/ "./assets/image/saas/logo.png":
/*!************************************!*\
  !*** ./assets/image/saas/logo.png ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/logo-b73048211d7a9a05b4c449061f130c5f.png";

/***/ }),

/***/ "./assets/image/saas/map.png":
/*!***********************************!*\
  !*** ./assets/image/saas/map.png ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/map-40ffdb360205f038eec59b94bd1010ed.png";

/***/ }),

/***/ "./assets/image/saas/particles/particle-1.png":
/*!****************************************************!*\
  !*** ./assets/image/saas/particles/particle-1.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAXCAYAAADgKtSgAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGAGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEzLTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgeG1wOkNyZWF0ZURhdGU9IjIwMTktMDEtMTBUMTM6MDA6MDcrMDY6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTktMDEtMTBUMTM6MDA6MDcrMDY6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDE5LTAxLTEwVDEzOjAwOjA3KzA2OjAwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjVmNmNkZTQyLTlmY2EtNGZhMC04ZGUxLWEyMTg1NGQ3NDcyYiIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOmRhNzE2MzE3LTNhNjItZjM0Yi05OGJkLTkwOGRlZDcwNjI0MyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjZhNTM4NGRiLTU2NmEtNDc0Zi05NzI1LTg5NjEyNjYzMzY5OSIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NmE1Mzg0ZGItNTY2YS00NzRmLTk3MjUtODk2MTI2NjMzNjk5IiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAwOjA3KzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NWY2Y2RlNDItOWZjYS00ZmEwLThkZTEtYTIxODU0ZDc0NzJiIiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAwOjA3KzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4Rn/yhAAACM0lEQVRIiZ3Vu2tUQRQG8F8uV4sIPmIhBgTRgBo1UfG9orZi658g2Fhc/xIXa21sFTuxjeJbfFwIi4oGq0QLI4KmSJbVYua6s5vdmM0HA3PPzPnOOXPnfDO0NHFdH+zEOezAAj7gGebTTXlZ9POX97GP4xKy+L0Rx3AUDTzBbF/WFcjX4WJCnGII++OYiUE+D0J+CBvi/CduYitqGIsBYBd2NSfrX/EYjbwsWh2ZdJ15hqsYid8P8CJZ3xaDHOhR2Q88xbu8LJb02DCeEC/gTdf6N9zDjRh0MVnbIhxn0Zys7++V+RVsj/OpOFbCMI7HMZzYW7idZr47IV7Ey/8Qw0JeFlO4Lhzhz2jPcDYlryXzt8KxrAp5WSzlZfECtxLzaEU+Kvx9QklPV0vchZFkvliRp1lPa5c3KFKe91mMNh4Nf4TGGBjNyfo2oQ8qnucZTmk3xifhuq0FtYSnkZfFfIY9yYa1Zr1JaKwOngzrE2OH4g2A09oNOZOXxWxFnqrbZZzoCrgimpP1YRxOTP+qz/BIuH4Eab2AAud1dl0/HE+SmcvL4p9KZviCu/iVOAxH8msx2OY+xOsi+bKsaUtuAx+F8k4LIlQ5nxAeimmhub4m/ke0q5uPPMvIoYlXeC3c+5q21mSYwEHhcXiC7zGRCs+69bzXY9GKWU4LknBGWxqGhEYZ6/L5jXfdRP3e0AozcYzGSvZZ/ga0cL96IAYhrzCLO4JUnMRe4YbM4WFeFl96Of0FkzOGScuEADsAAAAASUVORK5CYII="

/***/ }),

/***/ "./assets/image/saas/particles/particle-2.png":
/*!****************************************************!*\
  !*** ./assets/image/saas/particles/particle-2.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAYAAADE6YVjAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGAGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEzLTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgeG1wOkNyZWF0ZURhdGU9IjIwMTktMDEtMTBUMTM6MDA6NTYrMDY6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTktMDEtMTBUMTM6MDA6NTYrMDY6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDE5LTAxLTEwVDEzOjAwOjU2KzA2OjAwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmY4YTA5YTUyLTY3ZDEtNGNlZC1hMWMxLWNjMzcxMjhlYTE5OSIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjkwYjk2NDM0LTk4ZjgtZjE0Mi04YjdiLWZiYzI5OGM3YWU4NyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOmVkM2RlMjc2LWU0NTEtNDhhMy1iZGI1LTNjY2EzMTI5MThiMSIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZWQzZGUyNzYtZTQ1MS00OGEzLWJkYjUtM2NjYTMxMjkxOGIxIiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAwOjU2KzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZjhhMDlhNTItNjdkMS00Y2VkLWExYzEtY2MzNzEyOGVhMTk5IiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAwOjU2KzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4SIEDCAAACI0lEQVRIia3WTUtVURQG4MdzFbqYRVkYlGVNoshw0CSMwAJHBRX0EwoqamiNmlbTiIL6ETVoEGIfRB/TMFGaaGFBQRpxCwU/arD38Wzl6i29LxxYZ5113nfvtTZr7Yau63+sgEbsRRf2oBVlTGECo3iHD5hdiaQaMnTjJDZW+V7GjvgcRQVP8KKaWDWRNpyPBP+KFpzFYTzA15VEOnAFzYlvAm8wEu1fWI+t6MQhIY3iwq7iNsZygoakJttwTUgFzOARnmNuhV2U0INTaIq+KdzMd5QlgecSgQpuYaCGgPh9IMZXoq8spLyUihxX1GAWdzFeg3wpxuN/eeG3R16ZsMXeJPihcDRXg9H4f45eNGVC8Vqic1KowVrwLPKIvAdzkRyv1a5BLcxHnhwHMuxKHCNrFMgxnNgdGTYnju91EvmW2JsyxbGF33USSXnKGaYTR7P6IOWZzhQnAbbUSaQtsX9k+Jg49tVJZH9ij2UYShzdii6wWuRjIsdQhkFFz9mMY2sU6VGc2AoGM6Hb9idBp4UpuBrsxpnkvR8zeWqe4nO0G3ER7f8p0I5Lihn1JfIu5H9OmGhT8b0FfUIXLdUgL8W4PkUPnML9yLtoaBFazOUkmGIyDgtDaBobVJ+MhDrckZzapSKEol3Azho7qIZx3IsLW0C1i8QkbuAITqh+W1mKn3iMV0IXXoTlrkTzeIm3Qko6hVS2Yp2Qsgl8wvv4zCy3gr/TBXWxkywiXgAAAABJRU5ErkJggg=="

/***/ }),

/***/ "./assets/image/saas/particles/particle-3.png":
/*!****************************************************!*\
  !*** ./assets/image/saas/particles/particle-3.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAASCAYAAAC0EpUuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGAGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEzLTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgeG1wOkNyZWF0ZURhdGU9IjIwMTktMDEtMTBUMTM6MDE6NDIrMDY6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTktMDEtMTBUMTM6MDE6NDIrMDY6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDE5LTAxLTEwVDEzOjAxOjQyKzA2OjAwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjEwYThhZjdiLWUxOGYtNDRmOS1hNzg0LWFkMzk5OTMwZWVjOCIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOmIyODhmNDdjLTAzZmEtNTY0Ni05NGNkLTMwYTQyYzU1NTk3ZCIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjgwNmZlYzM0LWQ2ZTEtNDcyNi05MjJkLWVkOWE1YzEzZjBiNyIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ODA2ZmVjMzQtZDZlMS00NzI2LTkyMmQtZWQ5YTVjMTNmMGI3IiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAxOjQyKzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6MTBhOGFmN2ItZTE4Zi00NGY5LWE3ODQtYWQzOTk5MzBlZWM4IiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAxOjQyKzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4ljSKRAAABS0lEQVQ4ja3Tv0pcURDH8U+uq5ZiuIWxSSEYIVWqLTaglSjiC9jl5XyAy8UUa9YHCCYs2sRGERExneAiFrsWO4vHy/5xYae5v5n5zZfDmXM//N/fO8C62cW/DCszBMKnDK0ZQ1s1tPENn6N4gcMpIOn1XaOdoYef6EZj3fvv+Evi7eIoL8peFoU7nCbmHdQmAGvhG8RpXpR3kCXFE3RCf0RjArSB5dCdmFeFdnCc5N+xNAK4FP1B/MqLcnCgN1D4i9vQ89geAd2NvvD/SZtVaA9H8YWvWKt41rCR+vOi7KWGKhRu9J9Zeqq50HORD6KdF+VNFTAMCk08hc5RD12PXPSbw4ZHQR8l28QmVrGV1E7C924o/MZ96EX8wELk99EfGuOgXW+XNp/00j9wKihc4bxSO8PluKFJUPrLeA79bMRypoU+eH0NzcjHxgsLtUxOm5qSqgAAAABJRU5ErkJggg=="

/***/ }),

/***/ "./assets/image/saas/particles/particle-4.png":
/*!****************************************************!*\
  !*** ./assets/image/saas/particles/particle-4.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAGAGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEzLTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgeG1wOkNyZWF0ZURhdGU9IjIwMTktMDEtMTBUMTM6MDI6MjQrMDY6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTktMDEtMTBUMTM6MDI6MjQrMDY6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDE5LTAxLTEwVDEzOjAyOjI0KzA2OjAwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmJiODg1MTE5LTUxNGItNGQ0YS04M2Q4LTNkNWMwMzE4MGFhYyIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjA4ZWQyYjJmLTZlZjktYzg0Yi04NDJlLTJmMzRlNWZlYzY3MSIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjY3MGFiOTU2LTI1ODktNDNiZi1iMDI5LWUxZjdjZjAzMDRlZCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NjcwYWI5NTYtMjU4OS00M2JmLWIwMjktZTFmN2NmMDMwNGVkIiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAyOjI0KzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6YmI4ODUxMTktNTE0Yi00ZDRhLTgzZDgtM2Q1YzAzMTgwYWFjIiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAyOjI0KzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7iscQUAAAC10lEQVRYhb3XW4jUdRQH8M9uq4Y3DImQ9UFIuqBdMCSFHqQiehAEyQdpC0IkrVRCRbogUT74kFoaTUX4oAWB5IMGPXSBgrDAxMva2hIRUoj2kC5rgrnawznLTNvOzv8/jnNg+H/nzPmf8/2f/+9cpqOnd8AoMg67MRHPYFSjVkhXHf396El8Bi/cKAKddfTH0J94Fea3m8BlPJf4JryX17YRgK/wceJ5eL7dBGA9zid+A90tijseCzC+EYGzeCnxVOxoQfBHcAKHUGlEAD7AD4mX4fEmA9+GvfgSd6RuahECV0UlXMnv7+DmEoE78SxOqZb2EHZiRRECcBS7Et+OVwvedx++E1U0LXWH8SDWYaAoAdiM3xNvwF1j2E7G9gy2IHUXsDaD/zhsWIbAoGANE1BBxyh2S9GHF1U77Se4W2Txaq1xGQKwH58lXqT6TmEWDuJTzEzdL3gMy0VL/5+UJQBr8HfibeJ0b8JJLE79ZbyOe/HFWM7qDaOx5Ld0vhW3iqecXPP716KN/1zEWTMZgD24mHg4+Dk8jUeLBm+GQAdWiE42qUZ/EfeIRnOtjMMyBObiW3yI6akbzOsksbiUliIEJor3fQQP1QTeiNn4M3WbRSW0lMBicbo3iTUNDmAO3hTDamMN0V0jHTRLoBv7RF3PSt1pLMnP6RrbPfimhvDS6yHQJbpdH55I3RXxtHPE04+Ua1gtah/e9t+yLExgvhi7b2FK6g7hAZHmQfWlL0kSXfC1MgSmiBH7vVi9iC1olTh0xwv62oJfE68Tk7AQgYrY94az8ZGYdO8bMTgayCXV9b0r/Tassk7VjtYvuthT4nQ3I5+LwwsLsbLRDR09vQPjRLqOqx6k65Fu/CR2yL9ENs/VM+7EP2JxaEVw+AOvJL5FTMy60uwwaiQV1a3nSTzcbgJDYhEdEgPsXfFfoG0EiAxUEt+pTlk2s5CUkZcxQzSxo6MZ/Av4qY3UFBHrKQAAAABJRU5ErkJggg=="

/***/ }),

/***/ "./assets/image/saas/particles/particle-5.png":
/*!****************************************************!*\
  !*** ./assets/image/saas/particles/particle-5.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAACXBIWXMAAAsTAAALEwEAmpwYAAAF8WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEzLTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgeG1wOkNyZWF0ZURhdGU9IjIwMTktMDEtMTBUMTM6MDMrMDY6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTktMDEtMTBUMTM6MDMrMDY6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDE5LTAxLTEwVDEzOjAzKzA2OjAwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjQ0N2I3NmExLWZkZTgtNDI3MC04ODRhLTFhMmYxOTZiYmZhNiIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOmYxMjU1NGU4LTE4YjEtZGQ0Ni1hNThjLWUzYjk0NmEwMTU1YyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjcwYjk5MjM2LTQyNmEtNDk5ZC1iMTYyLTlmYjQxNDJjOWE0YiIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NzBiOTkyMzYtNDI2YS00OTlkLWIxNjItOWZiNDE0MmM5YTRiIiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAzKzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NDQ3Yjc2YTEtZmRlOC00MjcwLTg4NGEtMWEyZjE5NmJiZmE2IiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAzKzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6djlKbAAABaElEQVQ4jZ3UT0tWQRTH8c8d2gjGQy/gEQIJX4K4KfyzbBe6Eqqdyyjc2DIXgeHS5SNom2gj7VKjiODBVyBtggq38mAgtuhpMefq5XoFr7/NzDlzznfm3jNnimF/ToOmsRDjWPh+4hPeYb+eUNRAE9jAgyZ6RZ+xhMPScauyeB8fcDvsP9jDj7DvYhajsdEBHuJLFTSBnYD8wxusYlA7SQcreB6xO5jEYUKBXgQN8RjLDRDhW46YYeT0UCTMBBXWsdUAqGsLazGfxEzCfDhO8eoakFKrkQPzSS4xuaTHLUADF9dgOqEbxvcWkFJlTjfh7AaAS0o4ivm9G+SPx/g7yReLXL07LSAdlG3xLeFtGCN42QK0EjmwnfAR/XA8w+I1IIt4EfM+dpN8Q5/I5Sywiddx9Lo6sbYZsQM8xbDa/W2aFk5UmrbpGem5aJmr1I+vaHxGxMKUXI1HciW7+Itf+Ir32JV/ybn+A++eUzAelEAkAAAAAElFTkSuQmCC"

/***/ }),

/***/ "./assets/image/saas/particles/particle-6.png":
/*!****************************************************!*\
  !*** ./assets/image/saas/particles/particle-6.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAbCAYAAABvCO8sAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGAGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEzLTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgeG1wOkNyZWF0ZURhdGU9IjIwMTktMDEtMTBUMTM6MDM6NDQrMDY6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTktMDEtMTBUMTM6MDM6NDQrMDY6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDE5LTAxLTEwVDEzOjAzOjQ0KzA2OjAwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjQ1Mjk3Y2IxLTk2MGEtNDEzNC1iMzNkLTRlYjgwZWJjNjAzNiIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjdiYjMzYWRkLTY4N2EtNmM0YS04ZmFmLTRlYzhiMThmMzY3NCIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjZlYzUwNGZmLTUzMGQtNDMwMi05ZjJkLTYyMDk3NTQ3OGRkZSIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NmVjNTA0ZmYtNTMwZC00MzAyLTlmMmQtNjIwOTc1NDc4ZGRlIiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAzOjQ0KzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NDUyOTdjYjEtOTYwYS00MTM0LWIzM2QtNGViODBlYmM2MDM2IiBzdEV2dDp3aGVuPSIyMDE5LTAxLTEwVDEzOjAzOjQ0KzA2OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4IbxF+AAACV0lEQVRIibWWPWgUQRTHf6tnIgaJnhEdsQinkLOJ8btx7cTCQuwEbcRO0mihoIagGLCxEgSxsbCxEcHWytEuGsTicgG/lQXRwfMIISB3FjPLvWz2dm7vkgcLb/8z83579+bNm2D7y99k2AAw7vwHwJ/khCgsZq1fZgXP+EngqPN3AteAei5CwtZ4xg8IfxiYBDasFnAjUE5oI8B1oH81gGNivA40nT8KXMWfjtxA+Xc+Ax6J90PAZc/6XMAgAXwDPAWeCC0ExpU2wUoAS8Am5xvgo/MfA8/FvOPAhZUAHhT+DK38ATwEXoj3U0qbs70C9wt/OjHWBO4Br4R2RmlzulugLIcG8C5lTgO4m/iY80qbE90A9wp9lvYnyz/gDvDevQfARaXNsbxAmb+3WYuBRWAKqIp4l5Q2RzoFBmTnb5lFYXEeuAV8dlIBuKK0Ge0EWAI2O79Gqxx80L/YczZyUh8wobQZ8QFlsU+ztBx8UAPcAH45aT1wU2kz3CnQl7806E8HrTlpALittNmRBkyWw0xeoIP+ACaAeScNAlNKm61JoCyHKj002igsfsLmdNFJQw46KFtMnnJINaXNNmzPLAN7WNrCFHAuFgJgnxj0lgOwDtittImDl2nt8HZWj4ElIL4N1YAPKZO3iMBlYBf+JtwAvgEV7In0Ol6Q7H1rXcCyeIY8wcFulFnxVKOwuCAnpAHHsI22zxO8CXx3gSvAHPA1CouZtVvA1oq8LLW7aC5gd++c+AX1bu6l/dhNk7RIBK4AX7A56ckK2CvEfeCwCxpDahnrurb/7GOVLT6LtEwAAAAASUVORK5CYII="

/***/ }),

/***/ "./assets/image/saas/partner.png":
/*!***************************************!*\
  !*** ./assets/image/saas/partner.png ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/partner-e55db5b2b7dadf7ce40e3aa054ff0fab.png";

/***/ }),

/***/ "./assets/image/saas/saas-banner.jpg":
/*!*******************************************!*\
  !*** ./assets/image/saas/saas-banner.jpg ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/saas-banner-86cc97d93fd238ea62407d1a850a7467.jpg";

/***/ }),

/***/ "./assets/image/saas/saasvisitor1.png":
/*!********************************************!*\
  !*** ./assets/image/saas/saasvisitor1.png ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/saasvisitor1-0e0190dc3ab7bae49a369f8cb7d9d257.png";

/***/ }),

/***/ "./assets/image/saas/testimonial/client-1.jpg":
/*!****************************************************!*\
  !*** ./assets/image/saas/testimonial/client-1.jpg ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/client-1-0da7cdff0ca8f46b2849b32a760c8121.jpg";

/***/ }),

/***/ "./assets/image/saas/vendor-logos.png":
/*!********************************************!*\
  !*** ./assets/image/saas/vendor-logos.png ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALgAAAA/CAYAAABThgKnAAAdMElEQVR4nO2deXwcV5Xvv+dW9aLWatmSd9mSHcexsZ19I2SBJICzQMgykxgShu0xw/CZ9yAEGJbwIGGYgQwwhCWEADOQDIRtSABnccAQJ3FibMe748SybMeLZFvWLvVSdeaP6m5Vt7ql7pasLPbv8+lP36q6de653eeeOvecc2+JqnICr2/c88K+vNcE6E/EiasSEHBFETHgglGDGgUFRTFADBcEbAOqBsuRAKJzxTDfUVmo0KTKNITpChNRCQExI9qhyD4DByyhOSEVW09v//K2hR137YhbNQOuBFGnB0SwVHHsMiBBgDJQF7EjuAEXNIxgo7GDuBLArl4C5Jdhe4x/yxM4LiATgEtUWZoQOQ/kJHU1kFFFMwuuMgV0vgM4CgnjcjC4wF0AzeL2PSfGXQ6sUOTgcAJbLGyuetcIfQFwQdT7pMoA4iY7kLqmg9e8kb4A9BzQUxFdAEwGrUO0PNmJAdB2hAOgL4FuQHgWdM3gj6NJHlLHWeWc14bB/WsLq3cCOSCzDeYTilztODIj/f+UAMuN0ho6x/RYk+dWJFrnorGbwBxWrEdR6ysgm8eC47HW4BXAu4HzQE4FXeydTkmhemVNndJKkDrQk4GLvWsKwk5gPbAGeAB4eYz5PIECIYAKC101/+TCdYpMQEsX7EG6Dn2mnv2Bszkl8TAOAO4kUXcZOO+ynO6HXBP8BkZWozICtfwwo+JyEKcAXwCaUfkucDOw2GMsyVz276FkXfN3QuYA1wH/CrIL+C5w5hjxegIFQACFyQ7ytQQ8q+gHFZ0wduaDR6fFvhR3yDW3TNzo31iJnlUkOu4DZy5SmqiOQsAVYAaeht0KcrunjWGoYCeP0yPRdz19LU8ZbFQ+jKfN/wycUzrPJ1AoFC5MiP7ZVf04SvmxaMPSKAfNEnpNRR5BVEvd/vdpouMv6va/M1NuCsMoBFzuQNkGcmMOofTXyyr7BFuzr/nK2fS8QXMhsBq4F5hcOu8nkA8CQVW500FWACcf07Y0QadOYZd1yQi2cmKqRg/8Rgba7wWnuhixLUXAL0DZCHwGpGKo5k0ep7W4ZGn0XEKey1TJokdG+QMgO/Ds/RMYM0iZq9avXeWfgcCI1UcNRV2H7bI0aYOPUDvW/QHp3fsYOPUqhWnyIgVcPwLyJMgi7zifYKeq+8up+uSwubNp5dLs2SYOVcBPgG8X14cTyIOZjsjvFK4Yl9ZEvH/c6aOVkzkq00b2eAioGz1b+/esEGdgcSF2eTECfj8qd+e3p4cxRXIOBH+5EHs8iaF1/wFYWUQ/TiALgkwXMY+o8ubxbFcB3DhdiWp2JM4qTBgFcHoXSbz3EZBFnpBr3k+hAv6fwE2DXCVbGqKt8wlo6tj/nXVuRHt8GBrKRSBPA9UF9ue4guDm/BhcErgRR+SnwILx5MlRJeo4xBMJasMWkek3oMYq+H6FqSZ29OfEOqeIVY2YipyfQvzg94Pc5Pmuk84jZTCgo5LyaTNYh5Q/GxBwFRIx6O+F6IBXRsEIhENQVgahkHec0UaynG4nVWaQdvpAz8PzsrwJ6C74lzoO4OZSYwLqajCa0Add5eJx4UOVhCqWGCaEAsyojtA4vZZZNVWUBZZw+Kmvoe3rkULkXACn/xTt2viHoF39FiOBo+RwONrDWyn6U9CbBjWm3weafc53bAy4Lhw+BL3dELChsgqmN0BdPVRUetVjUTjSBof2w+E2GOgFy0D9FAiXgZsYHDCDUu2V0wKfMSCWgD4DvKGAn+i4QdTJPYVzVW539dja3I4qjiqCUBm0aSoPs6CmnKmREEGTKXvh+quJH14PhSpyAU30nhbvWPetcNWb3p0rsmrn9yvqP4Isy9TWZGlo36RRkoIdj0PrPkgk4LQz4IILoXEOTJ8JDbMhGBraVNsB2NMMB/bChudg1WOwrwXqp0JVNbjO0DYzhDzVWwWRhd7APOFhScF1h/7HLvJGVD9xLNpzkpraiFATsJlZHqapooyGijDldn7pDU+7gd7mr6GJ3sLd3QJOrG1ZNPrSQyY840HcROZlveL6XLedCro+nV+SzgfJVU4KmGU8QY3H4PQz4ap3wNuvKpDLLLy4BX57Pzz1uCf0DY1g20lB9+e7ZPGSPqcAHwR+MIT2cZiL8p3NezKOFepjok+5MHes2vDMD69cGwrQWBGmsTLMjEgZZVbhvoyja69mYN/DSNFJJNIRrJh/vmWXb0MHTZV8At4M2pgpSNnl5LERz5R4cQfMmwef/DSc98ZiucuNtv3wva/AQw/AxIlQNwUScTIGnteLQd4yhJ4GYG8GzeNQwO/empnKk0DvctT92GjppoRaBMpti+llIU6qijC3KlKUUPvRt+c7dD7/keIFXMEEqn4lZfOuQwdNMhsdwsjnEbcx7b3IMIGzJpaWge4u2LsHlt0E//QxqKoqpV+5UT8NPv8fcO4l8O0vwq4XYPY8cBK+R1heUwXQ+4DLx46h1yYSMviHqzLfVf6+VFqueiYIQEXAYnrEE+pZ5WVUBgr3guRDaNJbMaEImugr3EwBz5eR6H5XPHbgYjdQtdKbcMoQG3wi6GczvBN+b8hgFiAYG44egaNH4fYvwI03jbpzeXH5NbDwdPj0+2DnVph9EjjxTE+K35szKOSXgV4OPHbsmHstwDfxEvk4Slkxd6eEWlHKLIuGsjCLaitoiISpGAOh9sOKzCFQfSbRQ38pzJvih6rYbu8/a2D2ypRHxc5yjPwIJJAhyNneEhWwBLp74MhR+MqXYenSUXSpQEyfBfcthw9dCdvXw5xTfOaKz52YUQbgZ0DtsWfw1QsnkbJJZSZGbijkHlchoZ4WLLcNU8tCzKmM0FhZxoTgsY3ih+qvJNr2l+JvFDDxjku0e+v5WGVPo4rxRRonozI4K8yXEYhAwoHdu+H2z4+PcKcQCMI3H4QZTbBvN1gWGU+gIVFOgeTqk/Fj8tUI7/cQkU/jpTjkqSVYxkbFImwJC6vLuWL6RG6ZM5XrZ0/h9IlVx1y4AUKTr0aCwWyPX0FQsHFjt2NHwI5kCPg/DFbzC3byOFW2LNixE957M1w7wmqgY4GqGrjjXujrgZ5uPD++fzBmGW7e4Lwzo85xBiMGI6YKY4b8YYJgjI1lbFx1aO3YzUQ9zM1NU7m6oZ7FtZVUj4NQ+2GXzyNQfabfGVIc3L4LJdHfKI6LQQVUwsBtuUPmvmOxoLUV5s6F224tvQejxcmL4dZ/g0MHPVs7O5Q/JGOR84Axcu289uAaF9fopaqaTDEWjFhYxsbRBF29B2g5+Cxbdi1ne8vjbN/7HFXBsbWti4MQmfmB0m9XDVsSfIddNjM9ybwFJZy2Z/02eHryBsQT0B+F798BgfEd1UNw/fth+YOwaztMmQGaWiua1x5fBjz1CnD6ikNwAfsKEQtBcDROX6yD9t7ddPcfZGCgm4QTBxfCoTC7ug6z8+hB5tZOK6m9RDzBxmc3snXtFvp6+ggEbKY2TGPROYuZ3ji9IBrBSZdjhSpx493FP3gFEomOK1RnfCPlbbwgfSUj9wPSYXDLwN6X4fzzYNHCIltMYt1fYcN6L3yvrjdIZjbAJW+FSKR4esv+ET793syeDcldSUdej9slb4ZgwFHn/L7EEXrih+iJtjEQ7yKRiCMq2KEglhvAdVzUdYnpABvaWkoS8DUr1/DL7/+Clu27SMQTiBFUFRGhoqqC2SfP5rLr38o5bzkH287v7LbC0wnUnMdA62PFe1MAnK7TNL53YkqDnwFkugSzc0wc9TT4DdcU39jmTfDD78NTT3rCHQp4ZBMx73v2t+HGW+CG9xRH9y1XwfmXwuY1MGnKSKH8s0CnAfuL78BrG3t7np8Tc3vnDjjdqLoIBhMIEMz1FFbFuBG29LdyTTLcXiieenQV3/zUN0AgGAoiRnAdFxHBCljE43G2rtvK808/z7Ufuo73/N+bh6UXmnodAwdL9PCqM1GEU22UOQineGdT5okOLR86DOecBZe8qbiGfvbfcMf/B9uChpkQmOElYokv4th+CG7/BPx5BXzzPi8sXyguvQaeWgF1U5OBzKxBmpGVKEvJFb5/naMrenABgi1ivE19hoMIActiX/9RDvR3MD0yoaA2ogNRfv2DXyECwXAIx3GYNW8Wk6bU0dPZw/6WfRw9fBQ7ECBSGWHx2YtHpBmcdCkmVF5cbkoKChYsskEuGtHvLQpd3XDJhcU18stfwp13QP1kqKkBdTwHq48JAGrroHYirPoTfHgZ/ODnhbdx0kKomuAld1mpZ5kvUJVuSAC9iONQwI2xFmoRPjdB6E/E2NC+p2ABb9m+i/0t+wmEgkT7o1zx7itZ9tFl2EkPTNu+VlY+tJLf/fRh3nbj21ly/qkj0rTLGgnWvpGBg6WZKW6s6w0GxLNN075ufzl57KqXr900u3Dqzc3w+dthYh1MqPW0tv83zrWcbd4CT8jv/rfC25n3BjhpEXR2DPLs70uaPnCMF9G+itFU7A0GYVP73pErJtHZ3omTSO5u4rrMW3JyWrgB6qdP5oa//xu++uBdXPuB6wqmG5r8jpL84QjgJpoMMG+oYPj83ohne1fXwLQphTfwne96psaECV5gKEUr3wLklHkxbwHc9x3YsK7AjggsPBW6OjN7l+E6TLc7hokyxaGm6dwP1TSd+3jyc8Y4N1/0bDFgLJq722jubiuofllFBDGCiBAIBvjND37F6hWr6enqyag3efpkQuEcKdN5EJ5yHXb51NKE3O2fZKMyNSNRyT+5TNngfQPQMA0aZhRGePMWWPkXz0Pi5rDnM9yQDE4MXYVQGBwHVj4GS04vrL2GuR5BFy+7kRxtem0dk/09CsQE4FJfeRyhBf5xgxAR+pwoz7S9SFNl/Yj1G09uZNKUSRxpPUIwFGTPS3v499vuon5aPY3zG5m3ZB5Lzl1Cw0mziuLDBOsJ1r+dvl0/LDrDUHBrDFA7NBKYFeyJRqG+zpsoFoLn1kBPH9j+WXoOuhnnkmVHobIa9hX+eKR+qrcCKB30yW4nXS7BF/nah5Y4oAJisa1jP3F35E0dKqoreOf7rsFJOAz0DWAHbELhIEfaDrN6xTP8+Ks/4rPv/Qzf+sx/sOfFPSPS8yNcf2VJQWhVJ2xAyodGAlPlpBaMO1BRhPLr6vFW7ig5cloYpJsuZ3FfVgEH93urgwpBRRXYQU/Ac5paaR5e4ejUK4bCbQIfLGOxv7+Dnd2tBdW/7NrL+eQ3P8XJp83HSTj09fThJlxCZSEiFREcx2Hlw3/i9vd/juefXl8wH3bthViRySWYKWIZUnmFObduSB67UNzecH5/NPmFOd+qfGMgFvdSYgvqRyofxdeOvzzY/vGZjAIF/pCZECDuJnj+yO6C7znzorP44n1f4nP33M5NH72JBWd4i/X7e/tBobyynL6ePu750vdoP9ReEE0rMJHgxIv96xgKhLo2pJbA5Fg44FXy5MItYvgEghBLLhjOuG24VABfuwNRqJ0EoQLTlgf6wXEZTLzKQxct6Y9+HaCDEre6s5NmSkJd7AKVnIiw4PQFLDh9Add+8Dp2bW9h3ZNreeTBR+jr7iUYDnJo/yF2bHiBcy89ryCaobor6N9ThPsYQMyAlxuZL4fDPwEsBk2NyUHhC5dn+NrTHGS2marT2w3TZhbedscRGBjwPWX8/KdoK4gMFN+Z4lDTdG4TkGsd4KW+8vV5PCm/6Ghe3TzWPAmyT70tqouGbSxe7mtnd/ch5lQNP0a6O7p4actLnPZGv3NAaJzfSOP8RiprKrn3zu8TjoQB6GzvKpiP0KTLsMpqcGMdhdvjYjrtFBPD5HAwdII4At58EcydA4cPw6SJpPer8A+YnBFTwFjQ3QunFLHzw749ycUPJinIfv797WjPMFTGCk3AV0ao86E859cCYy7gKuwvyc1GykxxWHO4eUQB/8nXf8Jjv3iEq255B9e8713U1mWuM+nt6s04jlQUPuc3oSmE6pcysPeBtB7L2yU7+XFDR2yfdiN925A1jkVq8VAIPvh38NGPw8TaLE2cT/jwvDS7d8E5b4SlVxfe3gtbocw3Cc5naiHjIeBHgRU5zjcxGHBZm6yX696xh7JrNLcHjMVfD+/i6obTidhD56uu6/LLe3/JH//nCSqqKnnkv5fz15VrOHnJfGY0zSQYCrCvZT/PPrGaUDKMX1Fdwdw3zCmOj6m30Lr9AcTyzKDUPlEiitggQZA4yJ5q3HXT0JZTWgY1+JAcDp8NO8T1VgCuWgrLH4Mn/gTz55HOXvdra7/wWTYcaoVYDL7wZW+3q0JwqBU2r4fqiZn00vQz8lFaiutE8ehoXr0WuCz7fE3TuZ9kULN/qqN5da5BcEyg6JbRzK4tMRwe6ObFrlaW1DYMpa8K6mKMIRaNESoL0Xmkk6ceWYW6LgoYYwiFQyhKX3cf1/+fG5jaUFz8KTjhfLrdmcS69mLbYIKKFfJWUNoHyrE2NSDrZkPLJLQriDW1covJENzM3Vt95RJ/nm9+Fc46EzZu8bwiqZ2MshckWBbs2Q2dXfDv34I5RWzXsX0zHNiX9IP7eM69oedxmQ+u3j7upa6PAcBB2Xw0d2zCsixu+PDf8omv38bJp83HdZXoQBRQjG1hJeMn/X39uK5y9S3v4Kr3FPGETsIOVFA96804QdCgYrVHCDw9h+A9F2F/+WrMf10AW6dB3EIiCbCjm3w2OPiSkpKHyUd9qcM/EIAffx+++nX4yQPexj2V5VBe5kUco/3Q2ws9Xd5A+Mzn4A2Limtj7WrP9k55bPLZ9t5T6g8l9uQ1DSOyQ6BFS8hJSSFgDJuPvkzUiROycocTzrr4bM66+Gx2bNrBptUb2btzL91HO3FdpawiQuP8Rs648AyaTinONPGj2nobXX9+knBzA4GdU5HOclBBAwm0LJauJyJdxtX1dkbSXT57fDRa3Lbg07d6mYgrn4S2g7A/uQPWpFqYMgVOmgM3LRvU8IVi3x546BcweXpW7kmS99SXZ57sALaV1onXNixXB1zhWaR0AbfForW/k13dh5hfM7xpMW/RPOYtmldqU0PgdPTSv2obXT9fxcBfdlDdfjEqBg04aCiH51cVCQc2mgkVB7MmmWlvQ5Y9PgZcnnu29wHPpZdIQEXF6Gje+y1oP+Jt6OkkBvswxL2pgKwaXWOvXcRswaj+QZQbR0Mnrg4bj+4ZUcDHAom2TvpXbaPn92sZePZF4i2tqKOYsiCEDQz3TggFiQQfIWCRY5KZquT3YWcHbEaJcHj0NFp2wqO/g4amZJAn6+kzZMMifbh0W+u1DdsVQB5V3A6gplQ6AbHY0L6Xd846k6AZ+3cIu9E4fY9voPtXz9C3ajvO/nbUdZFgAAmHCg/JGEkQT/zGPdSVWnTst1P8drj/+1UkHLEo3PoRL5krtc0ykBk4yjjehcr/jDebWVgLfCpZHnNf93Aw3n93SJE/uGjJW5DZxmJ/31G2dOzjtNrisgLzwe2LEl3bTM8j6+h7YiPRrS9DzIFwAImEipc6BQmY5xKWbMN1sjbAH7RXyanVXy24619gy2ZYvNgzdfC7NMU3VtNa/HOvFKspJN2C4+Ya9MMZdKB8CeVdQMmPUEddnm17aVQC7nb10b96B70rNtL3xEbiLx3EjcaRoI0EbW/NbokQUAlad1jieReyIpnZ9jijn2SONe77HvzXfTB/oW8hBUP99hkRU4pMYnh9Qd20gG8Xkd/hvWS3JASMxY6ug/TEo1QECk9S1ITDwLpmeh5aQ89vnyOxqw037iAhT6hNcAxMHlUI2s+ZivDylPjaQ96UkNNkeZXgnm/Dffd4G+pblud29E+G08joy0dREjmoHT/wbWWsyr8a1Xdqia9xt8RwJNrDto59nFU3vFPGHYh55sfydfT/eQvRLXtx+6JIKICEg5iitgAdGSICIetfEo6T/vu9Tg55HcgoQ/VjjZ4e+PrX4IH/hNmzIVKRtLuzfN0ZWlxAdDvI3a8Y368SWJlbZP9Vce8HvaVUeqrK+vaWvALev+Ylun/xNH0rNxN/8YAn1MEAErIxlWMs1YNMQTj4R6u28rfooLIbHMUZ/nDItMd55RT5+vXw5S/BxufhlAVeXDb1zpkML0myvj9rUfngqF7m/DrBEP0k5oui7tsGt3IrDgFj8WLnQQZwCWNQoGvbbgYe30ji8U30P/siTmevp6mDNqbq2C+kEohalaHPequ6MgQ8l2mSbY8nSRQCVdjRDE0No9ve7YUX4Ec/gpV/8ppetMTLGHR9TxavQYaYU572/trx7Pv2Q50hUfpmlA9h+G0p9CwxHHb6WLN+DTNW7OHl3z9N9+Zd1HXBhEAEDQfGRajTUEUnlN3qlgWe8V5zMyirmZPMEe3xAiACP34Qnv4rfPjdMG8OnL6IgpyYe1+GLVtg3fPw6CNw5LC3WVA4lPSWkMMMSZXBZ4+vA7mtcKZf33DiQ4MiAg9JQH4oIu8rhaYJBvjdU09wwW1PYIIBTFkQq6oCES+hatzgTSwf15rI3Qkz1Jz2TTRy2d+kkpSKa7S+DjbvgNvvgqpymD/X+5zUCFPqobrSqxeLQWubJ9g7dsDmrdDW6pkhdXVw0jzP1k4FcnKbIVkeE20HzkFlHH/lVzdCeV6wqi4fcy1dpHBWsTRNzKFjST0Di6ZQ29yNa6zx97N5ex7utqdUvV/sgPd0z2LCHiLQafhNldRxEZgyCWbN8ELoL+2C9Zs8r0dZCFKvvVAn+WLYBETCUFMFs2YN8uO4mX5576ahfA766/tRORvk+PaaZCFi8pqKnXHXvXLAOH9UtKgdVcVVYpVB2s6awuQXukgEJRVQGh8oiG0dtKZWL5Wa8r35llQO9YPnNVWKZSA5MIwFtbVQO8Gj5TpkvJHWYlCIM97HmcszkmJFcrHVDVwAurN4Zl/nGCaJLYhpi6lzoyM8KjC1mMeeuErrGfUsfnAnFjK+S7pVe6xIcJk1qWqruq731M8Br+cZGjr1uM8+LqZxf33JLBvLW9xgWd4nYx2lj8m8201IjjL7UU4DNhbB5QmQ/mk3CbwdZHMx91oxh8MLaumZWUUwAaIyLta3GLPfCtjXCPzRF8TKCTOsAGecK2Z4SqaA5hRM/0Dy85Arapp1f+ZAWAOcApzQ3CUi+TdvsFQvB9YV+k+Lo/TXBGk7dRKBuDtOBoq2mEjwMrHMikJGU3KfhWxXYL7vYnnJvldyX/ML9hBtnUOwB9MH7gTOAyl8efYJDAM54KpepvCTgv9xF/aeU4+xLS+SeAx1uDGy3ASsi1XYWvA9pHd7yp5MZpsqxcIvsDnKuQQ3zceI2v5plCuBzzJsYvAJFA2l3YGbFW6UAhZB2zGHfadO5OicGgKxUa2Ky8cPQBTLfFQDZqmI7C5mEBmQWMaZXGbJqEL12cLrL+exuXPd5x0fRfl/eC+U+v0omDqBEaDwM1EuFJGfD/cAF0fpqwmy+/zJ2PGx195im8dMyL5ULe72RygLhQEe8JHzvnIKdJE2eE6TInltRA09RPNvBP4OaAS+UQQjJzAKCLJZkL8V5FJBlpPh/hqEFVd2nV1HPBIYEwtFBMTIKitgXWvK7LdiSo9IG5RbQXzLpcfK/s7lhRlRQ/sFeyvKD/B2iVoC/BjwbwJ+AuMEgScElgIXC7JckD7/dSvu0npSJe2zK7DjozJTEiI8KcpVlmXeJEZ+PdrxYgM9wBkg3wU9D/DCjBnJVqMQcv8uU34Ht6ogJED6Ue1B6AB2gTwD+kdgU8m9OoFjhSeNy5MKc9XiSpClqJ4qrtbFIhY7z57I9G1dECyMWFIqOhA2isujcZyHxTKbgo6MRuoy29AS7JoTeG3h1qfuH/Z6j0ZRUSwVYuqiRjCArYKmXiig4KJYrvfWTddSBMGBuoDL4ljYLJqxtXPhzR9f3yhKnStUAxGS+Z8qDACdghxRtEVEtuI6m3DdDQSs/SYBMXUgYBFyBA1Y3lvaAgYcxXEcDN7yOw3ZmKiLBC2kqW7Yvv0v689zrhpTPd0AAAAASUVORK5CYII="

/***/ }),

/***/ "./assets/image/saas/visitor_bg.png":
/*!******************************************!*\
  !*** ./assets/image/saas/visitor_bg.png ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/visitor_bg-9288fa7e875e8850b7e0b31eb3a6ffc3.png";

/***/ }),

/***/ "./components/Accordion/accordion.style.js":
/*!*************************************************!*\
  !*** ./components/Accordion/accordion.style.js ***!
  \*************************************************/
/*! exports provided: AccordionWrapper, AccordionItemWrapper, OpenIcon, CloseIcon, AccordionTitleWrapper, AccordionBodyWrapper, IconWrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccordionWrapper", function() { return AccordionWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccordionItemWrapper", function() { return AccordionItemWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpenIcon", function() { return OpenIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CloseIcon", function() { return CloseIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccordionTitleWrapper", function() { return AccordionTitleWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccordionBodyWrapper", function() { return AccordionBodyWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconWrapper", function() { return IconWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_accessible_accordion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-accessible-accordion */ "react-accessible-accordion");
/* harmony import */ var react_accessible_accordion__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_1__);


var fadeIn = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["keyframes"])(["0%{opacity:0;}100%{opacity:1;}"]);
var AccordionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_1__["Accordion"]).withConfig({
  displayName: "accordionstyle__AccordionWrapper",
  componentId: "sc-1wmvwvu-0"
})([""]);
var AccordionItemWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_1__["AccordionItem"]).withConfig({
  displayName: "accordionstyle__AccordionItemWrapper",
  componentId: "sc-1wmvwvu-1"
})([""]);
var OpenIcon = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "accordionstyle__OpenIcon",
  componentId: "sc-1wmvwvu-2"
})([""]);
var CloseIcon = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "accordionstyle__CloseIcon",
  componentId: "sc-1wmvwvu-3"
})(["opacity:0;"]);
var AccordionTitleWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_1__["AccordionItemTitle"]).withConfig({
  displayName: "accordionstyle__AccordionTitleWrapper",
  componentId: "sc-1wmvwvu-4"
})(["display:flex;align-items:center;cursor:pointer;position:relative;&[aria-selected='false']{", "{opacity:0;}", "{opacity:1;}}&:focus{outline:none;}*{flex-grow:1;}"], OpenIcon, CloseIcon);
var AccordionBodyWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_1__["AccordionItemBody"]).withConfig({
  displayName: "accordionstyle__AccordionBodyWrapper",
  componentId: "sc-1wmvwvu-5"
})(["animation:0.35s ", " ease-in;&.accordion__body--hidden{animation:0.35s ", " ease-in;}"], fadeIn, fadeIn);
var IconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "accordionstyle__IconWrapper",
  componentId: "sc-1wmvwvu-6"
})(["margin-left:30px;width:40px;position:relative;", ",", "{position:absolute;top:50%;right:0;transform:translateY(-50%);transition:0.25s ease-in-out;}"], OpenIcon, CloseIcon);

/***/ }),

/***/ "./components/Accordion/index.js":
/*!***************************************!*\
  !*** ./components/Accordion/index.js ***!
  \***************************************/
/*! exports provided: Accordion, AccordionItem, AccordionTitle, AccordionBody, IconWrapper, OpenIcon, CloseIcon */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Accordion", function() { return Accordion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccordionItem", function() { return AccordionItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccordionTitle", function() { return AccordionTitle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccordionBody", function() { return AccordionBody; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _accordion_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./accordion.style */ "./components/Accordion/accordion.style.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IconWrapper", function() { return _accordion_style__WEBPACK_IMPORTED_MODULE_2__["IconWrapper"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "OpenIcon", function() { return _accordion_style__WEBPACK_IMPORTED_MODULE_2__["OpenIcon"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CloseIcon", function() { return _accordion_style__WEBPACK_IMPORTED_MODULE_2__["CloseIcon"]; });

/* harmony import */ var react_accessible_accordion_dist_fancy_example_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-accessible-accordion/dist/fancy-example.css */ "../../node_modules/react-accessible-accordion/dist/fancy-example.css");
/* harmony import */ var react_accessible_accordion_dist_fancy_example_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_accessible_accordion_dist_fancy_example_css__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\Accordion\\index.js";





var Accordion = function Accordion(_ref) {
  var className = _ref.className,
      children = _ref.children;
  // Add all classs to an array
  var addAllClasses = ['reusecore__accordion']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_accordion_style__WEBPACK_IMPORTED_MODULE_2__["AccordionWrapper"], {
    className: addAllClasses.join(' '),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }, children);
};

var AccordionItem = function AccordionItem(_ref2) {
  var className = _ref2.className,
      children = _ref2.children,
      expanded = _ref2.expanded;
  // Add all classs to an array
  var addAllClasses = ['accordion__item']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_accordion_style__WEBPACK_IMPORTED_MODULE_2__["AccordionItemWrapper"], {
    className: addAllClasses.join(' '),
    expanded: expanded,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    },
    __self: this
  }, children);
};

var AccordionTitle = function AccordionTitle(_ref3) {
  var className = _ref3.className,
      children = _ref3.children;
  // Add all classs to an array
  var addAllClasses = ['accordion__header']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_accordion_style__WEBPACK_IMPORTED_MODULE_2__["AccordionTitleWrapper"], {
    className: addAllClasses.join(' '),
    hideBodyClassName: "hidden",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }, children);
};

var AccordionBody = function AccordionBody(_ref4) {
  var className = _ref4.className,
      children = _ref4.children;
  // Add all classs to an array
  var addAllClasses = ['accordion__body']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_accordion_style__WEBPACK_IMPORTED_MODULE_2__["AccordionBodyWrapper"], {
    className: addAllClasses.join(' '),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 78
    },
    __self: this
  }, children);
};

Accordion.propTypes = {
  /** ClassName of the Accordion. Default class is reusecore__accordion*/
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Used to render any component */
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element
};
AccordionItem.propTypes = {
  /** ClassName of the AccordionItem. Default class is accordion__item */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Used to render any component */
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element
};
AccordionTitle.propTypes = {
  /** ClassName of the AccordionTitle. Default class is accordion__header */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Used to render any component */
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element
};
AccordionBody.propTypes = {
  /** ClassName of the AccordionBody. Default class is accordion__body */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Used to render any component */
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element
};


/***/ }),

/***/ "./components/FeatureBlock/featureBlock.style.js":
/*!*******************************************************!*\
  !*** ./components/FeatureBlock/featureBlock.style.js ***!
  \*******************************************************/
/*! exports provided: IconWrapper, ContentWrapper, ButtonWrapper, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconWrapper", function() { return IconWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentWrapper", function() { return ContentWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonWrapper", function() { return ButtonWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);

 // FeatureBlock wrapper style

var FeatureBlockWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureBlockstyle__FeatureBlockWrapper",
  componentId: "sc-1qxqvjs-0"
})(["&.icon_left{display:flex;align-items:flex-start;}&.icon_right{display:flex;align-items:flex-start;flex-direction:row-reverse;.content__wrapper{text-align:right;}}", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexWrap"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexDirection"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"], styled_system__WEBPACK_IMPORTED_MODULE_1__["position"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderColor"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"], styled_system__WEBPACK_IMPORTED_MODULE_1__["overflow"]); // Icon wrapper style

var IconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureBlockstyle__IconWrapper",
  componentId: "sc-1qxqvjs-1"
})(["", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"], styled_system__WEBPACK_IMPORTED_MODULE_1__["position"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderColor"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"], styled_system__WEBPACK_IMPORTED_MODULE_1__["overflow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["fontSize"]); // Content wrapper style

var ContentWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureBlockstyle__ContentWrapper",
  componentId: "sc-1qxqvjs-2"
})(["", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["textAlign"]); // Button wrapper style

var ButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "featureBlockstyle__ButtonWrapper",
  componentId: "sc-1qxqvjs-3"
})(["", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexDirection"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"]);

/* harmony default export */ __webpack_exports__["default"] = (FeatureBlockWrapper);

/***/ }),

/***/ "./components/FeatureBlock/index.js":
/*!******************************************!*\
  !*** ./components/FeatureBlock/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _featureBlock_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./featureBlock.style */ "./components/FeatureBlock/featureBlock.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\FeatureBlock\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var FeatureBlock = function FeatureBlock(_ref) {
  var className = _ref.className,
      icon = _ref.icon,
      title = _ref.title,
      button = _ref.button,
      description = _ref.description,
      iconPosition = _ref.iconPosition,
      additionalContent = _ref.additionalContent,
      wrapperStyle = _ref.wrapperStyle,
      iconStyle = _ref.iconStyle,
      contentStyle = _ref.contentStyle,
      btnWrapperStyle = _ref.btnWrapperStyle,
      props = _objectWithoutProperties(_ref, ["className", "icon", "title", "button", "description", "iconPosition", "additionalContent", "wrapperStyle", "iconStyle", "contentStyle", "btnWrapperStyle"]);

  // Add all classs to an array
  var addAllClasses = ['feature__block']; // Add icon position class

  if (iconPosition) {
    addAllClasses.push("icon_".concat(iconPosition));
  } // className prop checking


  if (className) {
    addAllClasses.push(className);
  } // check icon value and add


  var Icon = icon && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureBlock_style__WEBPACK_IMPORTED_MODULE_2__["IconWrapper"], _extends({
    className: "icon__wrapper"
  }, iconStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    },
    __self: this
  }), icon);
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureBlock_style__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: addAllClasses.join(' ')
  }, wrapperStyle, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }), Icon, title || description || button ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureBlock_style__WEBPACK_IMPORTED_MODULE_2__["ContentWrapper"], _extends({
    className: "content__wrapper"
  }, contentStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  }), title, description, button && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureBlock_style__WEBPACK_IMPORTED_MODULE_2__["ButtonWrapper"], _extends({
    className: "button__wrapper"
  }, btnWrapperStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    },
    __self: this
  }), button)), additionalContent) : '');
};

FeatureBlock.propTypes = {
  /** ClassName of the FeatureBlock */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** title prop contain a react component. You can use our Heading component from reusecore */
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** description prop contain a react component. You can use our Text component from reusecore */
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** button prop contain a react component. You can use our Button component from reusecore */
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** Set icon position of the FeatureBlock */
  iconPosition: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['top', 'left', 'right']),

  /** wrapperStyle prop contain these style system props:  display, flexWrap, width, height, alignItems,
   * justifyContent, position, overflow, space, color, borders, borderColor, boxShadow and borderRadius. */
  wrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** iconStyle prop contain these style system props: display, width, height, alignItems, justifyContent,
   * position, space, fontSize, color, borders, overflow, borderColor, boxShadow and borderRadius. */
  iconStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** contentStyle prop contain these style system props: width, textAlign and space. */
  contentStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** btnWrapperStyle prop contain these style system props: display, space, alignItems,
   * flexDirection and justifyContent. */
  btnWrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
FeatureBlock.defaultProps = {
  iconPosition: 'top'
};
/* harmony default export */ __webpack_exports__["default"] = (FeatureBlock);

/***/ }),

/***/ "./components/GlideCarousel/glide.style.js":
/*!*************************************************!*\
  !*** ./components/GlideCarousel/glide.style.js ***!
  \*************************************************/
/*! exports provided: GlideSlideWrapper, ButtonControlWrapper, ButtonWrapper, BulletControlWrapper, BulletButton, DefaultBtn, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlideSlideWrapper", function() { return GlideSlideWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonControlWrapper", function() { return ButtonControlWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonWrapper", function() { return ButtonWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulletControlWrapper", function() { return BulletControlWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulletButton", function() { return BulletButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DefaultBtn", function() { return DefaultBtn; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);

 // Glide wrapper style

var GlideWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "glidestyle__GlideWrapper",
  componentId: "sc-13h91ak-0"
})(["", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"]); // Glide slide wrapper style

var GlideSlideWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.li.withConfig({
  displayName: "glidestyle__GlideSlideWrapper",
  componentId: "sc-13h91ak-1"
})(["", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"]); // Button wrapper style

var ButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "glidestyle__ButtonWrapper",
  componentId: "sc-13h91ak-2"
})(["display:inline-block;", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"], styled_system__WEBPACK_IMPORTED_MODULE_1__["position"], styled_system__WEBPACK_IMPORTED_MODULE_1__["top"], styled_system__WEBPACK_IMPORTED_MODULE_1__["left"], styled_system__WEBPACK_IMPORTED_MODULE_1__["right"], styled_system__WEBPACK_IMPORTED_MODULE_1__["bottom"]); // ButtonControlWrapper style

var ButtonControlWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "glidestyle__ButtonControlWrapper",
  componentId: "sc-13h91ak-3"
})(["", " ", " ", " ", " ", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"], styled_system__WEBPACK_IMPORTED_MODULE_1__["position"], styled_system__WEBPACK_IMPORTED_MODULE_1__["top"], styled_system__WEBPACK_IMPORTED_MODULE_1__["left"], styled_system__WEBPACK_IMPORTED_MODULE_1__["right"], styled_system__WEBPACK_IMPORTED_MODULE_1__["bottom"]); // BulletControlWrapper style

var BulletControlWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "glidestyle__BulletControlWrapper",
  componentId: "sc-13h91ak-4"
})(["", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["alignItems"], styled_system__WEBPACK_IMPORTED_MODULE_1__["justifyContent"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexWrap"]); // BulletButton style

var BulletButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "glidestyle__BulletButton",
  componentId: "sc-13h91ak-5"
})(["cursor:pointer;width:10px;height:10px;margin:4px;border:0;padding:0;outline:none;border-radius:50%;background-color:#D6D6D6;&:hover,&.glide__bullet--active{background-color:#869791;}", " ", " ", " ", " ", " ", " ", " ", ""], styled_system__WEBPACK_IMPORTED_MODULE_1__["display"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borders"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"]); // default button style

var DefaultBtn = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "glidestyle__DefaultBtn",
  componentId: "sc-13h91ak-6"
})(["cursor:pointer;margin:10px 3px;"]);

/* harmony default export */ __webpack_exports__["default"] = (GlideWrapper);

/***/ }),

/***/ "./components/GlideCarousel/glideSlide.js":
/*!************************************************!*\
  !*** ./components/GlideCarousel/glideSlide.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _glide_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./glide.style */ "./components/GlideCarousel/glide.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\GlideCarousel\\glideSlide.js";


 // Glide Slide wrapper component

var GlideSlide = function GlideSlide(_ref) {
  var children = _ref.children;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_2__["GlideSlideWrapper"], {
    className: "glide__slide",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 8
    },
    __self: this
  }, children);
};

GlideSlide.propTypes = {
  /** Children. */
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element
};
/* harmony default export */ __webpack_exports__["default"] = (GlideSlide);

/***/ }),

/***/ "./components/GlideCarousel/index.js":
/*!*******************************************!*\
  !*** ./components/GlideCarousel/index.js ***!
  \*******************************************/
/*! exports provided: GlideSlide, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlideSlide", function() { return GlideSlide; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _glidejs_glide__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @glidejs/glide */ "@glidejs/glide");
/* harmony import */ var _glidejs_glide__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_glidejs_glide__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _glidejs_glide_dist_css_glide_core_min_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @glidejs/glide/dist/css/glide.core.min.css */ "../../node_modules/@glidejs/glide/dist/css/glide.core.min.css");
/* harmony import */ var _glidejs_glide_dist_css_glide_core_min_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_glidejs_glide_dist_css_glide_core_min_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _glide_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./glide.style */ "./components/GlideCarousel/glide.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\GlideCarousel\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







var GlideCarousel = function GlideCarousel(_ref) {
  var className = _ref.className,
      children = _ref.children,
      options = _ref.options,
      controls = _ref.controls,
      prevButton = _ref.prevButton,
      nextButton = _ref.nextButton,
      prevWrapper = _ref.prevWrapper,
      nextWrapper = _ref.nextWrapper,
      bullets = _ref.bullets,
      numberOfBullets = _ref.numberOfBullets,
      buttonWrapperStyle = _ref.buttonWrapperStyle,
      bulletWrapperStyle = _ref.bulletWrapperStyle,
      bulletButtonStyle = _ref.bulletButtonStyle,
      carouselSelector = _ref.carouselSelector;
  // Add all classs to an array
  var addAllClasses = ['glide']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  } // number of bullets loop


  var totalBullets = [];

  for (var i = 0; i < numberOfBullets; i++) {
    totalBullets.push(i);
  } // Load glide


  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(function () {
    var glide = new _glidejs_glide__WEBPACK_IMPORTED_MODULE_2___default.a(carouselSelector ? "#".concat(carouselSelector) : '#glide', _objectSpread({}, options));
    glide.mount();
  });
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_4__["default"], {
    className: addAllClasses.join(' '),
    id: carouselSelector || 'glide',
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "glide__track",
    "data-glide-el": "track",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("ul", {
    className: "glide__slides",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    },
    __self: this
  }, children)), controls && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_4__["ButtonControlWrapper"], _extends({
    className: "glide__controls",
    "data-glide-el": "controls"
  }, buttonWrapperStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_4__["ButtonWrapper"], _extends({}, prevWrapper, {
    className: "glide__prev--area",
    "data-glide-dir": "<",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    },
    __self: this
  }), prevButton ? prevButton : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_4__["DefaultBtn"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 75
    },
    __self: this
  }, "Prev")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_4__["ButtonWrapper"], _extends({}, nextWrapper, {
    className: "glide__next--area",
    "data-glide-dir": ">",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77
    },
    __self: this
  }), nextButton ? nextButton : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_4__["DefaultBtn"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 82
    },
    __self: this
  }, "Next"))), bullets && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_4__["BulletControlWrapper"], _extends({
    className: "glide__bullets",
    "data-glide-el": "controls[nav]"
  }, bulletWrapperStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 89
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 94
    },
    __self: this
  }, totalBullets.map(function (index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_glide_style__WEBPACK_IMPORTED_MODULE_4__["BulletButton"], _extends({
      key: index,
      className: "glide__bullet",
      "data-glide-dir": "=".concat(index)
    }, bulletButtonStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 96
      },
      __self: this
    }));
  }))));
};

GlideCarousel.propTypes = {
  /** className of the GlideCarousel. */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Children. */
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element,

  /** You can add your custom glid options using this prop. */
  options: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Hide || show controls nav. */
  controls: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** Hide || show bullets nav. */
  bullets: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,

  /** This prop only take your slider / carousel / testimonials data length. */
  numberOfBullets: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,

  /** bulletWrapperStyle is a bullet control wrapper style object prop.
   * It's contain display, space, alignItems,
   * justifyContent and flexWrap style-system prop.
   */
  bulletWrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** buttonWrapperStyle is a button control wrapper style object prop.
   * It's contain same as buttonWrapperStyle style-system prop and
   * position, left, right, top and bottom.
   */
  buttonWrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** prevWrapper is a previous button wrapper style object prop.
   * It's contain display, space, bg, borders, boxShadow, borderRadius,
   * position, top, left, right and bottom style-system prop.
   */
  prevWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** nextWrapper is a next button wrapper style object prop.
   * It's contain same as prevWrapper style-system prop.
   */
  nextWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Set previous button for glide carousel. */
  prevButton: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object]),

  /** Set next button for glide carousel. */
  nextButton: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object]),

  /** bulletButtonStyle is a bullet button style object prop.
   * It's contain  display, width, height, space,
   * bg, borders, boxShadow and borderRadius style-system prop.
   */
  bulletButtonStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // GlideCarousel default props

GlideCarousel.defaultProps = {
  controls: true,
  bullets: false
};

/* harmony default export */ __webpack_exports__["default"] = (GlideCarousel);

/***/ }),

/***/ "./components/HamburgMenu/hamburgMenu.style.js":
/*!*****************************************************!*\
  !*** ./components/HamburgMenu/hamburgMenu.style.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);


var HamburgMenuWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "hamburgMenustyle__HamburgMenuWrapper",
  componentId: "sc-11i4t5v-0"
})(["border:0;background:transparent;width:44px;height:30px;cursor:pointer;", " ", " ", " ", " ", " ", " ", " > span{display:block;width:100%;height:2px;margin:4px 0;float:right;background-color:", ";transition:all 0.3s ease;&:first-child{margin-top:0;}&:last-child{width:calc(100% - 10px);margin-bottom:0;}}&:focus,&:hover{outline:none;> span{&:last-child{width:100%;}}}&:focus{> span{&:first-child{transform:rotate(45deg);transform-origin:8px 50%;}&:nth-child(2){display:none;}&:last-child{width:100%;transform:rotate(-45deg);transform-origin:9px 50%;}}}"], styled_system__WEBPACK_IMPORTED_MODULE_1__["width"], styled_system__WEBPACK_IMPORTED_MODULE_1__["height"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["border"], styled_system__WEBPACK_IMPORTED_MODULE_1__["boxShadow"], styled_system__WEBPACK_IMPORTED_MODULE_1__["borderRadius"], function (props) {
  return props.barColor ? props.barColor : '#10ac84';
});
HamburgMenuWrapper.displayName = 'HamburgMenuWrapper';
/* harmony default export */ __webpack_exports__["default"] = (HamburgMenuWrapper);

/***/ }),

/***/ "./components/HamburgMenu/index.js":
/*!*****************************************!*\
  !*** ./components/HamburgMenu/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hamburgMenu_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hamburgMenu.style */ "./components/HamburgMenu/hamburgMenu.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\HamburgMenu\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var HamburgMenu = function HamburgMenu(_ref) {
  var className = _ref.className,
      wrapperStyle = _ref.wrapperStyle,
      barColor = _ref.barColor,
      props = _objectWithoutProperties(_ref, ["className", "wrapperStyle", "barColor"]);

  // Add all classs to an array
  var addAllClasses = ['hamburgMenu__bar']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_hamburgMenu_style__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: addAllClasses.join(' ')
  }, wrapperStyle, {
    barColor: barColor,
    "aria-label": "hamburgMenu"
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }));
};

HamburgMenu.propTypes = {
  /** ClassName of the Hamburg menu. */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** barColor allow to change hambrug menu's bar color. */
  barColor: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** wrapperStyle prop allow to change Hamburg menu bg color, width, height, space, boxShadow, border and borderRadius.*/
  wrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
/* harmony default export */ __webpack_exports__["default"] = (HamburgMenu);

/***/ }),

/***/ "./components/ScrollSpyMenu/index.js":
/*!*******************************************!*\
  !*** ./components/ScrollSpyMenu/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_scrollspy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-scrollspy */ "react-scrollspy");
/* harmony import */ var react_scrollspy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_scrollspy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-anchor-link-smooth-scroll */ "react-anchor-link-smooth-scroll");
/* harmony import */ var react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../contexts/DrawerContext */ "./contexts/DrawerContext.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\ScrollSpyMenu\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var ScrollSpyMenu = function ScrollSpyMenu(_ref) {
  var className = _ref.className,
      menuItems = _ref.menuItems,
      drawerClose = _ref.drawerClose,
      props = _objectWithoutProperties(_ref, ["className", "menuItems", "drawerClose"]);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(_contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_4__["DrawerContext"]),
      dispatch = _useContext.dispatch; // empty array for scrollspy items


  var scrollItems = []; // convert menu path to scrollspy items

  menuItems.forEach(function (item) {
    scrollItems.push(item.path.slice(1));
  }); // Add all classs to an array

  var addAllClasses = ['scrollspy__menu']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  } // Close drawer when click on menu item


  var toggleDrawer = function toggleDrawer() {
    dispatch({
      type: 'TOGGLE'
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_scrollspy__WEBPACK_IMPORTED_MODULE_2___default.a, _extends({
    items: scrollItems,
    className: addAllClasses.join(' '),
    drawerClose: drawerClose
  }, props, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    },
    __self: this
  }), menuItems.map(function (menu, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", {
      key: "menu-item-".concat(index),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41
      },
      __self: this
    }, drawerClose ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3___default.a, {
      href: menu.path,
      offset: menu.offset,
      onClick: toggleDrawer,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 43
      },
      __self: this
    }, menu.label) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_3___default.a, {
      href: menu.path,
      offset: menu.offset,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 51
      },
      __self: this
    }, menu.label));
  }));
};

ScrollSpyMenu.propTypes = {
  /** className of the ScrollSpyMenu. */
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** menuItems is an array of object prop which contain your menu
   * data.
   */
  menuItems: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array.isRequired,

  /** Class name that apply to the navigation element paired with the content element in viewport. */
  currentClassName: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Class name that apply to the navigation elements that have been scrolled past [optional]. */
  scrolledPastClassName: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** HTML tag for Scrollspy component if you want to use other than <ul/> [optional]. */
  componentTag: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /** Style attribute to be passed to the generated <ul/> element [optional]. */
  style: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,

  /** Offset value that adjusts to determine the elements are in the viewport [optional]. */
  offset: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,

  /** Name of the element of scrollable container that can be used with querySelector [optional]. */
  rootEl: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,

  /**
   * Function to be executed when the active item has been updated [optional].
   */
  onUpdate: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};
ScrollSpyMenu.defaultProps = {
  componentTag: 'ul',
  currentClassName: 'is-current'
};
/* harmony default export */ __webpack_exports__["default"] = (ScrollSpyMenu);

/***/ }),

/***/ "./components/UI/Container/index.js":
/*!******************************************!*\
  !*** ./components/UI/Container/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./style */ "./components/UI/Container/style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\components\\UI\\Container\\index.js";



var Container = function Container(_ref) {
  var children = _ref.children,
      className = _ref.className,
      fullWidth = _ref.fullWidth,
      noGutter = _ref.noGutter;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_style__WEBPACK_IMPORTED_MODULE_1__["default"], {
    className: className,
    fullWidth: fullWidth,
    noGutter: noGutter,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    },
    __self: this
  }, children);
};

/* harmony default export */ __webpack_exports__["default"] = (Container);

/***/ }),

/***/ "./components/UI/Container/style.js":
/*!******************************************!*\
  !*** ./components/UI/Container/style.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var ContainerWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "style__ContainerWrapper",
  componentId: "posx22-0"
})(["margin-left:auto;margin-right:auto;", ";", ";@media (min-width:768px){max-width:750px;width:100%;}@media (min-width:992px){max-width:970px;width:100%;}@media (min-width:1200px){max-width:1170px;width:100%;}"], function (props) {
  return props.fullWidth && Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["css"])(["width:100%;max-width:none !important;"]);
}, function (props) {
  return props.noGutter && Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["css"])(["padding-left:0;padding-right:0;"]) || Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["css"])(["padding-left:30px;padding-right:30px;"]);
});
/* harmony default export */ __webpack_exports__["default"] = (ContainerWrapper);

/***/ }),

/***/ "./containers/Saas/BannerSection/bannerSection.style.js":
/*!**************************************************************!*\
  !*** ./containers/Saas/BannerSection/bannerSection.style.js ***!
  \**************************************************************/
/*! exports provided: DiscountWrapper, DiscountLabel, BannerObject, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountWrapper", function() { return DiscountWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountLabel", function() { return DiscountLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BannerObject", function() { return BannerObject; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_image_saas_saas_banner_jpg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../assets/image/saas/saas-banner.jpg */ "./assets/image/saas/saas-banner.jpg");
/* harmony import */ var _assets_image_saas_saas_banner_jpg__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_saas_banner_jpg__WEBPACK_IMPORTED_MODULE_2__);



var BannerWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "bannerSectionstyle__BannerWrapper",
  componentId: "sc-1o0fgpf-0"
})(["padding-top:210px;padding-bottom:160px;background-image:url(", ");background-size:cover;background-position:center;background-repeat:no-repeat;background-attachment:fixed;min-height:100vh;position:relative;overflow:hidden;@media (max-width:990px){padding-top:180px;padding-bottom:60px;min-height:auto;}@media (max-width:767px){padding-top:130px;padding-bottom:20px;min-height:auto;}@media only screen and (max-width:480px){background:none;}.particle{position:absolute;width:50%;height:100%;top:0;left:0;overflow:hidden;@media (max-width:767px){display:none;}@media only screen and (max-width:480px){width:100%;}}.row{position:relative;z-index:1;}.button__wrapper{margin-top:40px;@media (max-width:767px){margin-bottom:30px;}.reusecore__button{&.outlined{border-color:rgba(82,104,219,0.2);}}}"], _assets_image_saas_saas_banner_jpg__WEBPACK_IMPORTED_MODULE_2___default.a);
var BannerObject = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "bannerSectionstyle__BannerObject",
  componentId: "sc-1o0fgpf-1"
})(["position:absolute;width:50%;height:100%;top:0;right:0;display:flex;align-items:center;@media (max-width:767px){display:none;}.objectWrapper{margin-left:auto;position:relative;.dashboardWrapper{position:absolute;top:0;right:0;.chatObject{position:absolute;top:20px;left:120px;}}}"]);
var DiscountLabel = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "bannerSectionstyle__DiscountLabel",
  componentId: "sc-1o0fgpf-2"
})(["display:inline-block;border-radius:4em;border:1px solid ", ";padding:7px 25px;box-shadow:0px 7px 25px 0px rgba(22,53,76,0.05);margin-bottom:30px;background-color:", ";@media (max-width:767px){padding:7px 15px;}"], Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.lightBorder', '#f1f4f6'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'));

/* harmony default export */ __webpack_exports__["default"] = (BannerWrapper);

/***/ }),

/***/ "./containers/Saas/BannerSection/index.js":
/*!************************************************!*\
  !*** ./containers/Saas/BannerSection/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _Particle__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Particle */ "./containers/Saas/Particle/index.js");
/* harmony import */ var _bannerSection_style__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./bannerSection.style */ "./containers/Saas/BannerSection/bannerSection.style.js");
/* harmony import */ var _assets_image_saas_banner_bannerObject1_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../assets/image/saas/banner/bannerObject1.png */ "./assets/image/saas/banner/bannerObject1.png");
/* harmony import */ var _assets_image_saas_banner_bannerObject1_png__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_banner_bannerObject1_png__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_image_saas_banner_bannerObject2_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../assets/image/saas/banner/bannerObject2.png */ "./assets/image/saas/banner/bannerObject2.png");
/* harmony import */ var _assets_image_saas_banner_bannerObject2_png__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_banner_bannerObject2_png__WEBPACK_IMPORTED_MODULE_12__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\BannerSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }















var BannerSection = function BannerSection(_ref) {
  var row = _ref.row,
      col = _ref.col,
      title = _ref.title,
      btnStyle = _ref.btnStyle,
      description = _ref.description,
      discountText = _ref.discountText,
      discountAmount = _ref.discountAmount,
      outlineBtnStyle = _ref.outlineBtnStyle;

  var ButtonGroup = function ButtonGroup() {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 30
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({
      title: "FREE TRAIL"
    }, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 31
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({
      className: "outlined",
      title: "EXPLORE MORE",
      variant: "outlined"
    }, outlineBtnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32
      },
      __self: this
    })));
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_bannerSection_style__WEBPACK_IMPORTED_MODULE_10__["default"], {
    id: "banner_section",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Particle__WEBPACK_IMPORTED_MODULE_9__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: "col"
  }, col, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_bannerSection_style__WEBPACK_IMPORTED_MODULE_10__["DiscountLabel"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    content: "25% Discount"
  }, discountAmount, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    content: "on every first project "
  }, discountText, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_7__["default"], {
    title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
      content: "Ultimate Platform\r to monitor your best\r workflow."
    }, title, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 52
      },
      __self: this
    })),
    description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
      content: "We help to create SaaS product that are innovative, differentiated with a superb User Experience, fully accessible through mobile devices. SaaS products are changing the world ."
    }, description, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 60
      },
      __self: this
    })),
    button: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ButtonGroup, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 65
      },
      __self: this
    }),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    },
    __self: this
  })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_bannerSection_style__WEBPACK_IMPORTED_MODULE_10__["BannerObject"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "objectWrapper",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__["default"], {
    src: _assets_image_saas_banner_bannerObject1_png__WEBPACK_IMPORTED_MODULE_11___default.a,
    alt: "BannerObject1",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 72
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "dashboardWrapper",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 73
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_4__["default"], {
    src: _assets_image_saas_banner_bannerObject2_png__WEBPACK_IMPORTED_MODULE_12___default.a,
    alt: "BannerObject2",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 74
    },
    __self: this
  })))));
};

BannerSection.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  btnStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  contentStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  discountText: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  discountAmount: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  outlineBtnStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
BannerSection.defaultProps = {
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px',
    alignItems: 'center'
  },
  col: {
    pr: '15px',
    pl: '15px',
    width: [1, '70%', '50%', '45%']
  },
  title: {
    fontSize: ['22px', '34px', '30px', '55px'],
    fontWeight: '700',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: ['20px', '25px'],
    lineHeight: '1.5'
  },
  description: {
    fontSize: '16px',
    color: '#343d48cc',
    lineHeight: '1.75',
    mb: '0'
  },
  btnStyle: {
    minWidth: ['120px', '120px', '120px', '156px'],
    fontSize: ['13px', '14px'],
    fontWeight: '500',
    colors: 'primaryWithBg'
  },
  outlineBtnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500',
    color: '#5167db',
    ml: '18px'
  },
  discountAmount: {
    fontSize: '14px',
    color: '#eb4d4b',
    mb: 0,
    as: 'span',
    mr: '0.4em',
    fontWeight: 700
  },
  discountText: {
    fontSize: ['13px', '14px'],
    color: '#0f2137',
    mb: 0,
    as: 'span',
    fontWeight: 500
  }
};
/* harmony default export */ __webpack_exports__["default"] = (BannerSection);

/***/ }),

/***/ "./containers/Saas/FaqSection/faqSection.style.js":
/*!********************************************************!*\
  !*** ./containers/Saas/FaqSection/faqSection.style.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var FaqSectionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "faqSectionstyle__FaqSectionWrapper",
  componentId: "sc-11c94tg-0"
})(["padding:80px 0;background:#fafbff;.reusecore__accordion{max-width:820px;margin:0 auto;border-bottom:1px solid #ebebeb;.accordion__item{border-top:0;border-bottom:1px solid #ebebeb;&:last-child{border-bottom:0;}.accordion__header{padding:20px 30px;}.accordion__body{padding:5px 30px 20px;}}}"]);
/* harmony default export */ __webpack_exports__["default"] = (FaqSectionWrapper);

/***/ }),

/***/ "./containers/Saas/FaqSection/index.js":
/*!*********************************************!*\
  !*** ./containers/Saas/FaqSection/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _components_Accordion__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../components/Accordion */ "./components/Accordion/index.js");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-icons-kit */ "react-icons-kit");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_icons_kit_entypo_plus__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-icons-kit/entypo/plus */ "react-icons-kit/entypo/plus");
/* harmony import */ var react_icons_kit_entypo_plus__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_entypo_plus__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_kit_entypo_minus__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-icons-kit/entypo/minus */ "react-icons-kit/entypo/minus");
/* harmony import */ var react_icons_kit_entypo_minus__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_entypo_minus__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _faqSection_style__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./faqSection.style */ "./containers/Saas/FaqSection/faqSection.style.js");
/* harmony import */ var _data_Saas__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../data/Saas */ "./data/Saas/index.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\FaqSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
















var FaqSection = function FaqSection(_ref) {
  var sectionHeader = _ref.sectionHeader,
      sectionTitle = _ref.sectionTitle,
      sectionSubTitle = _ref.sectionSubTitle,
      titleStyle = _ref.titleStyle,
      descriptionStyle = _ref.descriptionStyle,
      buttonWrapper = _ref.buttonWrapper,
      button = _ref.button;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_faqSection_style__WEBPACK_IMPORTED_MODULE_12__["default"], {
    id: "faq_section",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, sectionHeader, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, sectionTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "row",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Accordion__WEBPACK_IMPORTED_MODULE_8__["Accordion"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    },
    __self: this
  }, _data_Saas__WEBPACK_IMPORTED_MODULE_13__["Faq"].map(function (faqItem, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Accordion__WEBPACK_IMPORTED_MODULE_8__["AccordionItem"], {
      key: index,
      expanded: faqItem.expend,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 45
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 46
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Accordion__WEBPACK_IMPORTED_MODULE_8__["AccordionTitle"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 47
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 48
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
      content: faqItem.title
    }, titleStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Accordion__WEBPACK_IMPORTED_MODULE_8__["IconWrapper"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Accordion__WEBPACK_IMPORTED_MODULE_8__["OpenIcon"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 51
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_kit__WEBPACK_IMPORTED_MODULE_9__["Icon"], {
      icon: react_icons_kit_entypo_minus__WEBPACK_IMPORTED_MODULE_11__["minus"],
      size: 18,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 52
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Accordion__WEBPACK_IMPORTED_MODULE_8__["CloseIcon"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 54
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_kit__WEBPACK_IMPORTED_MODULE_9__["Icon"], {
      icon: react_icons_kit_entypo_plus__WEBPACK_IMPORTED_MODULE_10__["plus"],
      size: 18,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 55
      },
      __self: this
    }))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Accordion__WEBPACK_IMPORTED_MODULE_8__["AccordionBody"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 60
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
      content: faqItem.description
    }, descriptionStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 61
      },
      __self: this
    })))));
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, buttonWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: "#",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 72
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 73
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, button, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 74
    },
    __self: this
  }))))))));
}; // FaqSection style props


FaqSection.propTypes = {
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  buttonWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // FaqSection default style

FaqSection.defaultProps = {
  // section header default style
  sectionHeader: {
    mb: '56px'
  },
  // sub section default style
  sectionSubTitle: {
    content: 'FREQUENTLY ASKED QUESTIONS',
    as: 'span',
    display: 'block',
    textAlign: 'center',
    fontSize: '14px',
    letterSpacing: '0.15em',
    fontWeight: '700',
    color: '#5268db',
    mb: '5px'
  },
  // section title default style
  sectionTitle: {
    content: 'Want to ask something about us ?',
    textAlign: 'center',
    fontSize: ['20px', '24px'],
    fontWeight: '400',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '0'
  },
  // accordion title default style
  titleStyle: {
    fontSize: ['16px', '19px'],
    fontWeight: '400',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '0'
  },
  // accordion description default style
  descriptionStyle: {
    fontSize: '15px',
    color: '#5d646d',
    lineHeight: '1.75',
    mb: '0',
    fontWeight: '400'
  },
  buttonWrapper: {
    mt: "".concat(11),
    flexBox: true,
    justifyContent: 'center'
  },
  button: {
    title: 'EXPLORE FORUM',
    type: 'button',
    fontSize: "".concat(2),
    fontWeight: '600',
    borderRadius: '4px',
    pl: '22px',
    pr: '22px',
    colors: 'primary',
    height: "".concat(4)
  }
};
/* harmony default export */ __webpack_exports__["default"] = (FaqSection);

/***/ }),

/***/ "./containers/Saas/FeatureSection/featureSection.style.js":
/*!****************************************************************!*\
  !*** ./containers/Saas/FeatureSection/featureSection.style.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var FeatureSectionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "featureSectionstyle__FeatureSectionWrapper",
  componentId: "sc-136n006-0"
})(["padding:80px 0 180px 0;@media (max-width:990px){padding:60px 0 60px 0;}@media (max-width:767px){padding:60px 0 30px 0;}.feature__block{position:relative;height:100%;transition:box-shadow 0.3s ease;@media (max-width:500px){padding:30px 0;}.icon__wrapper{position:relative;border-bottom-left-radius:6px;overflow:hidden;background:linear-gradient( -60deg,rgba(241,39,17,0.7),rgba(245,175,25,0.7) );.flaticon-flask{&:before{margin-left:8px;}}&:before,&:after{content:'';width:28px;height:calc(100% + 30px);position:absolute;}&:before{transform:rotate(45deg);background-color:rgba(255,255,255,0.15);}&:after{transform:rotate(-45deg);background-color:rgba(0,0,0,0.05);}}&:hover{", "}}.row{> .col{&:nth-child(-n + 3){}&:nth-child(3n + 3),&:last-child{}&:nth-child(1){.feature__block{.icon__wrapper{background:linear-gradient( -60deg,rgba(236,0,140,0.75),rgba(255,103,103,0.75) );}}}&:nth-child(2){.feature__block{.icon__wrapper{background:linear-gradient( -60deg,rgba(110,72,170,0.75),rgba(192,91,210,0.75) );}}}&:nth-child(3){.feature__block{.icon__wrapper{background:linear-gradient( -60deg,rgba(241,39,17,0.7),rgba(245,175,25,0.7) );}}}&:nth-child(4){.feature__block{.icon__wrapper{background:linear-gradient( -60deg,rgba(47,128,237,0.75),rgba(86,204,242,0.75) );}}}&:nth-child(5){.feature__block{.icon__wrapper{background:linear-gradient( -60deg,rgba(50,207,167,0.75),rgba(150,201,61,0.75) );}}}}}"], ''
/* box-shadow: 0 40px 90px -30px rgba(39, 79, 117, 0.2); */
);
/* harmony default export */ __webpack_exports__["default"] = (FeatureSectionWrapper);

/***/ }),

/***/ "./containers/Saas/FeatureSection/index.js":
/*!*************************************************!*\
  !*** ./containers/Saas/FeatureSection/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _data_Saas__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../data/Saas */ "./data/Saas/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _featureSection_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./featureSection.style */ "./containers/Saas/FeatureSection/featureSection.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\FeatureSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }











var FeatureSection = function FeatureSection(_ref) {
  var row = _ref.row,
      col = _ref.col,
      sectionHeader = _ref.sectionHeader,
      sectionTitle = _ref.sectionTitle,
      sectionSubTitle = _ref.sectionSubTitle,
      featureTitle = _ref.featureTitle,
      featureDescription = _ref.featureDescription,
      iconStyle = _ref.iconStyle,
      contentStyle = _ref.contentStyle,
      blockWrapperStyle = _ref.blockWrapperStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_featureSection_style__WEBPACK_IMPORTED_MODULE_8__["default"], {
    id: "service_section",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, sectionHeader, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    content: "OUR SERVICES"
  }, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    content: "Featured Service that We Provide"
  }, sectionTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    },
    __self: this
  }), _data_Saas__WEBPACK_IMPORTED_MODULE_6__["Features"].map(function (feature, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
      className: "col"
    }, col, {
      key: index,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 35
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_5__["default"], {
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
        className: feature.icon,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 37
        },
        __self: this
      }),
      wrapperStyle: blockWrapperStyle,
      iconStyle: iconStyle,
      contentStyle: contentStyle,
      title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
        content: feature.title
      }, featureTitle, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 41
        },
        __self: this
      })),
      description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
        content: feature.description
      }, featureDescription, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 43
        },
        __self: this
      })),
      className: "saasFeature",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36
      },
      __self: this
    }));
  }))));
}; // FeatureSection style props


FeatureSection.propTypes = {
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  featureTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  featureDescription: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // FeatureSection default style

FeatureSection.defaultProps = {
  // section header default style
  sectionHeader: {
    mb: ['40px', '40px', '40px', '80px']
  },
  // sub section default style
  sectionSubTitle: {
    as: 'span',
    display: 'block',
    textAlign: 'center',
    fontSize: '14px',
    letterSpacing: '0.15em',
    fontWeight: '700',
    color: '#5268db',
    mb: '10px'
  },
  // section title default style
  sectionTitle: {
    textAlign: 'center',
    fontSize: ['20px', '24px'],
    fontWeight: '500',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '0'
  },
  // feature row default style
  row: {
    flexBox: true,
    flexWrap: 'wrap'
  },
  // feature col default style
  col: {
    width: [1, 1 / 2, 1 / 3, 1 / 3]
  },
  // feature block wrapper default style
  blockWrapperStyle: {
    p: ['30px', '20px', '20px', '20px']
  },
  // feature icon default style
  iconStyle: {
    width: ['70px', '75px', '75px', '84px'],
    height: ['70px', '75px', '75px', '84px'],
    borderRadius: '50%',
    bg: '#93d26e',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: ['32px', '36px'],
    color: '#ffffff',
    overflow: 'hidden',
    mb: ['20px', '20px', '20px', '30px'],
    borderBottomLeftRadius: '50%'
  },
  // feature content default style
  contentStyle: {
    textAlign: 'left'
  },
  // feature title default style
  featureTitle: {
    fontSize: ['18px', '20px'],
    fontWeight: '400',
    color: '#0f2137',
    lineHeight: '1.5',
    mb: ['10px', '10px', '10px', '20px'],
    letterSpacing: '-0.020em'
  },
  // feature description default style
  featureDescription: {
    fontSize: '15px',
    lineHeight: '1.75',
    color: '#343d4ccc'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (FeatureSection);

/***/ }),

/***/ "./containers/Saas/Footer/footer.style.js":
/*!************************************************!*\
  !*** ./containers/Saas/Footer/footer.style.js ***!
  \************************************************/
/*! exports provided: List, ListItem, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "List", function() { return List; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListItem", function() { return ListItem; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_image_hosting_footer_bg_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../assets/image/hosting/footer-bg.png */ "./assets/image/hosting/footer-bg.png");
/* harmony import */ var _assets_image_hosting_footer_bg_png__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_footer_bg_png__WEBPACK_IMPORTED_MODULE_1__);


var FooterWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.footer.withConfig({
  displayName: "footerstyle__FooterWrapper",
  componentId: "iwpnlt-0"
})(["position:relative;background-color:#f9fbfd;overflow:hidden;background:linear-gradient(to bottom,#f7f8fd 0%,#fafbff 100%);@media (min-width:576px){padding-top:130px;&:before{content:'';position:absolute;width:104%;padding-bottom:104%;border-top-right-radius:11%;top:14%;left:0;pointer-events:none;background-color:#fff;transform:rotate(-6deg);@media (max-width:767px){padding-bottom:150%;}}}.footer_container{background-repeat:no-repeat;background-position:center 50px;padding-top:80px;padding-bottom:80px;position:relative;@media (min-width:576px){background-image:url(", ");}@media (max-width:990px){padding-bottom:20px;}}"], _assets_image_hosting_footer_bg_png__WEBPACK_IMPORTED_MODULE_1___default.a);
var List = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.ul.withConfig({
  displayName: "footerstyle__List",
  componentId: "iwpnlt-1"
})([""]);
var ListItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.li.withConfig({
  displayName: "footerstyle__ListItem",
  componentId: "iwpnlt-2"
})(["a{color:rgba(52,61,72,0.8);font-size:14px;line-height:36px;transition:all 0.2s ease;&:hover,&:focus{outline:0;text-decoration:none;color:#343d48;}}"]);

/* harmony default export */ __webpack_exports__["default"] = (FooterWrapper);

/***/ }),

/***/ "./containers/Saas/Footer/index.js":
/*!*****************************************!*\
  !*** ./containers/Saas/Footer/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_UI_Logo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/UI/Logo */ "../../node_modules/reusecore/src/elements/UI/Logo/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _footer_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./footer.style */ "./containers/Saas/Footer/footer.style.js");
/* harmony import */ var _assets_image_saas_logo_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../assets/image/saas/logo.png */ "./assets/image/saas/logo.png");
/* harmony import */ var _assets_image_saas_logo_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_logo_png__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _data_Saas__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../data/Saas */ "./data/Saas/index.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\Footer\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }













var Footer = function Footer(_ref) {
  var row = _ref.row,
      col = _ref.col,
      colOne = _ref.colOne,
      colTwo = _ref.colTwo,
      titleStyle = _ref.titleStyle,
      logoStyle = _ref.logoStyle,
      textStyle = _ref.textStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_footer_style__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    className: "footer_container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, colOne, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_UI_Logo__WEBPACK_IMPORTED_MODULE_6__["default"], {
    href: "#",
    logoSrc: _assets_image_saas_logo_png__WEBPACK_IMPORTED_MODULE_9___default.a,
    title: "Hosting",
    logoStyle: logoStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    content: "RedQ.Inc"
  }, textStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    content: "+97 0267 5923"
  }, textStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, colTwo, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  }), _data_Saas__WEBPACK_IMPORTED_MODULE_10__["Footer_Data"].map(function (widget, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
      className: "col"
    }, col, {
      key: "footer-widget-".concat(index),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
      content: widget.title
    }, titleStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 42
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_footer_style__WEBPACK_IMPORTED_MODULE_8__["List"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 43
      },
      __self: this
    }, widget.menuItems.map(function (item, index) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_footer_style__WEBPACK_IMPORTED_MODULE_8__["ListItem"], {
        key: "footer-list-item-".concat(index),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 45
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: item.url,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 46
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
        className: "ListItem",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 47
        },
        __self: this
      }, item.text)));
    })));
  })))));
}; // Footer style props


Footer.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  colOne: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  colTwo: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  titleStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  textStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  logoStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // Footer default style

Footer.defaultProps = {
  // Footer row default style
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px'
  },
  // Footer col one style
  colOne: {
    width: [1, '35%', '35%', '23%'],
    mt: [0, '13px'],
    mb: ['30px', 0],
    pl: ['15px', 0],
    pr: ['15px', '15px', 0]
  },
  // Footer col two style
  colTwo: {
    width: ['100%', '65%', '65%', '77%'],
    flexBox: true,
    flexWrap: 'wrap'
  },
  // Footer col default style
  col: {
    width: ['100%', '50%', '50%', '25%'],
    pl: '15px',
    pr: '15px',
    mb: '30px'
  },
  // widget title default style
  titleStyle: {
    color: '#343d48',
    fontSize: '16px',
    fontWeight: '700',
    mb: '30px'
  },
  // Default logo size
  logoStyle: {
    width: '100px',
    mb: '15px'
  },
  // widget text default style
  textStyle: {
    color: '#0f2137',
    fontSize: '16px',
    mb: '10px'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (Footer);

/***/ }),

/***/ "./containers/Saas/Navbar/index.js":
/*!*****************************************!*\
  !*** ./containers/Saas/Navbar/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Navbar */ "../../node_modules/reusecore/src/elements/Navbar/index.js");
/* harmony import */ var reusecore_src_elements_Drawer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Drawer */ "../../node_modules/reusecore/src/elements/Drawer/index.js");
/* harmony import */ var reusecore_src_elements_UI_Logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/UI/Logo */ "../../node_modules/reusecore/src/elements/UI/Logo/index.js");
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var _components_HamburgMenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../components/HamburgMenu */ "./components/HamburgMenu/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../contexts/DrawerContext */ "./contexts/DrawerContext.js");
/* harmony import */ var _data_Saas__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../data/Saas */ "./data/Saas/index.js");
/* harmony import */ var _components_ScrollSpyMenu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/ScrollSpyMenu */ "./components/ScrollSpyMenu/index.js");
/* harmony import */ var _assets_image_saas_logo_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../assets/image/saas/logo.png */ "./assets/image/saas/logo.png");
/* harmony import */ var _assets_image_saas_logo_png__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_logo_png__WEBPACK_IMPORTED_MODULE_11__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\Navbar\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }














var Navbar = function Navbar(_ref) {
  var navbarStyle = _ref.navbarStyle,
      logoStyle = _ref.logoStyle,
      row = _ref.row,
      menuWrapper = _ref.menuWrapper;

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(_contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_8__["DrawerContext"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch; // Toggle drawer


  var toggleHandler = function toggleHandler() {
    dispatch({
      type: 'TOGGLE'
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Navbar__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, navbarStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_UI_Logo__WEBPACK_IMPORTED_MODULE_4__["default"], {
    href: "#",
    logoSrc: _assets_image_saas_logo_png__WEBPACK_IMPORTED_MODULE_11___default.a,
    title: "Agency",
    logoStyle: logoStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, menuWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_ScrollSpyMenu__WEBPACK_IMPORTED_MODULE_10__["default"], {
    className: "main_menu",
    menuItems: _data_Saas__WEBPACK_IMPORTED_MODULE_9__["MENU_ITEMS"],
    offset: -70,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Drawer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    width: "420px",
    placement: "right",
    drawerHandler: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_HamburgMenu__WEBPACK_IMPORTED_MODULE_6__["default"], {
      barColor: "#eb4d4b",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 45
      },
      __self: this
    }),
    open: state.isOpen,
    toggleHandler: toggleHandler,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_ScrollSpyMenu__WEBPACK_IMPORTED_MODULE_10__["default"], {
    className: "mobile_menu",
    menuItems: _data_Saas__WEBPACK_IMPORTED_MODULE_9__["MENU_ITEMS"],
    drawerClose: true,
    offset: -100,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  }))))));
};

Navbar.propTypes = {
  navbarStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  logoStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  menuWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
Navbar.defaultProps = {
  navbarStyle: {
    className: 'hosting_navbar',
    minHeight: '70px',
    display: 'block'
  },
  row: {
    flexBox: true,
    alignItems: 'center',
    justifyContent: ['space-between', 'space-between', 'space-between', 'flex-start'],
    width: '100%'
  },
  logoStyle: {
    maxWidth: '130px',
    mr: [0, 0, 0, '166px']
  },
  button: {
    type: 'button',
    fontSize: '13px',
    fontWeight: '600',
    color: 'white',
    borderRadius: '4px',
    pl: '15px',
    pr: '15px',
    colors: 'primaryWithBg',
    minHeight: 'auto',
    height: "".concat(1)
  },
  menuWrapper: {
    flexBox: true,
    alignItems: 'center'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (Navbar);

/***/ }),

/***/ "./containers/Saas/Particle/index.js":
/*!*******************************************!*\
  !*** ./containers/Saas/Particle/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_particles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-particles-js */ "react-particles-js");
/* harmony import */ var react_particles_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_particles_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_image_saas_particles_particle_1_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../assets/image/saas/particles/particle-1.png */ "./assets/image/saas/particles/particle-1.png");
/* harmony import */ var _assets_image_saas_particles_particle_1_png__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_particles_particle_1_png__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_image_saas_particles_particle_2_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../assets/image/saas/particles/particle-2.png */ "./assets/image/saas/particles/particle-2.png");
/* harmony import */ var _assets_image_saas_particles_particle_2_png__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_particles_particle_2_png__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _assets_image_saas_particles_particle_3_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../assets/image/saas/particles/particle-3.png */ "./assets/image/saas/particles/particle-3.png");
/* harmony import */ var _assets_image_saas_particles_particle_3_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_particles_particle_3_png__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_image_saas_particles_particle_4_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../assets/image/saas/particles/particle-4.png */ "./assets/image/saas/particles/particle-4.png");
/* harmony import */ var _assets_image_saas_particles_particle_4_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_particles_particle_4_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_image_saas_particles_particle_5_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../assets/image/saas/particles/particle-5.png */ "./assets/image/saas/particles/particle-5.png");
/* harmony import */ var _assets_image_saas_particles_particle_5_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_particles_particle_5_png__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_image_saas_particles_particle_6_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../assets/image/saas/particles/particle-6.png */ "./assets/image/saas/particles/particle-6.png");
/* harmony import */ var _assets_image_saas_particles_particle_6_png__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_particles_particle_6_png__WEBPACK_IMPORTED_MODULE_7__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\Particle\\index.js";









var ParticlesComponent = function ParticlesComponent() {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_particles_js__WEBPACK_IMPORTED_MODULE_1___default.a, {
    className: "particle",
    params: {
      particles: {
        number: {
          value: 6,
          density: {
            enable: true,
            value_area: 800
          }
        },
        shape: {
          type: ['images'],
          images: [{
            src: "".concat(_assets_image_saas_particles_particle_1_png__WEBPACK_IMPORTED_MODULE_2___default.a),
            width: 25,
            height: 25
          }, {
            src: "".concat(_assets_image_saas_particles_particle_2_png__WEBPACK_IMPORTED_MODULE_3___default.a),
            width: 18,
            height: 18
          }, {
            src: "".concat(_assets_image_saas_particles_particle_3_png__WEBPACK_IMPORTED_MODULE_4___default.a),
            width: 32,
            height: 32
          }, {
            src: "".concat(_assets_image_saas_particles_particle_4_png__WEBPACK_IMPORTED_MODULE_5___default.a),
            width: 41,
            height: 41
          }, {
            src: "".concat(_assets_image_saas_particles_particle_5_png__WEBPACK_IMPORTED_MODULE_6___default.a),
            width: 22,
            height: 22
          }, {
            src: "".concat(_assets_image_saas_particles_particle_6_png__WEBPACK_IMPORTED_MODULE_7___default.a),
            width: 22,
            height: 22
          }]
        },
        opacity: {
          value: 0.17626369048095938,
          random: true,
          anim: {
            enable: false,
            speed: 1,
            opacity_min: 0.1,
            sync: false
          }
        },
        size: {
          value: 10,
          random: false
        },
        line_linked: {
          enable: false
        },
        move: {
          enable: true,
          speed: 1.5,
          direction: 'none',
          random: false,
          straight: false,
          bounce: true,
          attract: {
            enable: true,
            rotateX: 100,
            rotateY: 400
          }
        }
      },
      retina_detect: true
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    },
    __self: this
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (ParticlesComponent);

/***/ }),

/***/ "./containers/Saas/PartnerSection/index.js":
/*!*************************************************!*\
  !*** ./containers/Saas/PartnerSection/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _assets_image_saas_partner_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../assets/image/saas/partner.png */ "./assets/image/saas/partner.png");
/* harmony import */ var _assets_image_saas_partner_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_partner_png__WEBPACK_IMPORTED_MODULE_9__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\PartnerSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }












var PartnerSection = function PartnerSection(_ref) {
  var sectionWrapper = _ref.sectionWrapper,
      row = _ref.row,
      col = _ref.col,
      title = _ref.title,
      description = _ref.description,
      button = _ref.button,
      textArea = _ref.textArea,
      imageArea = _ref.imageArea;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, sectionWrapper, {
    className: "partner_section",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, col, imageArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_7__["default"], {
    src: _assets_image_saas_partner_png__WEBPACK_IMPORTED_MODULE_9___default.a,
    alt: "Domain Image",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, col, textArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, title, {
    content: "Meet our business partner who work behind the scene",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, description, {
    content: "You can trust us for any kind of services and some of the world class companies have also trusted us.So have faith and keep in touch with us .",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: "#",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, button, {
    title: "LEARN MORE",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  })))))))));
};

PartnerSection.propTypes = {
  sectionWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  textArea: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  imageArea: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
PartnerSection.defaultProps = {
  sectionWrapper: {
    as: 'section',
    pt: ['60px', '80px', '80px', '120px'],
    pb: ['60px', '80px', '80px', '120px']
  },
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px',
    alignItems: 'center'
  },
  imageAreaRow: {
    flexDirection: 'row-reverse'
  },
  col: {
    pr: '15px',
    pl: '15px'
  },
  textArea: {
    width: ['100%', '100%', '55%', '50%', '42%']
  },
  imageArea: {
    width: ['100%', '100%', '45%', '50%', '58%'],
    mb: ['40px', '40px', '0', '0', '0']
  },
  title: {
    fontSize: ['26px', '30px', '30px', '48px', '48px'],
    fontWeight: '400',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '15px',
    lineHeight: '1.5'
  },
  description: {
    fontSize: '16px',
    color: '#343d48cc',
    lineHeight: '1.75',
    mb: '33px'
  },
  button: {
    type: 'button',
    fontSize: '14px',
    fontWeight: '600',
    color: '#fff',
    borderRadius: '4px',
    pl: '22px',
    pr: '22px',
    colors: 'primaryWithBg'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (PartnerSection);

/***/ }),

/***/ "./containers/Saas/PricingSection/index.js":
/*!*************************************************!*\
  !*** ./containers/Saas/PricingSection/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons-kit */ "react-icons-kit");
/* harmony import */ var react_icons_kit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _components_GlideCarousel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../components/GlideCarousel */ "./components/GlideCarousel/index.js");
/* harmony import */ var _components_GlideCarousel_glideSlide__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/GlideCarousel/glideSlide */ "./components/GlideCarousel/glideSlide.js");
/* harmony import */ var _data_Hosting_data__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../data/Hosting/data */ "./data/Hosting/data.js");
/* harmony import */ var _pricing_style__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pricing.style */ "./containers/Saas/PricingSection/pricing.style.js");
/* harmony import */ var react_icons_kit_icomoon_checkmark__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-icons-kit/icomoon/checkmark */ "react-icons-kit/icomoon/checkmark");
/* harmony import */ var react_icons_kit_icomoon_checkmark__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_icons_kit_icomoon_checkmark__WEBPACK_IMPORTED_MODULE_13__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\PricingSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
















var PricingSection = function PricingSection(_ref) {
  var sectionWrapper = _ref.sectionWrapper,
      row = _ref.row,
      col = _ref.col,
      secTitleWrapper = _ref.secTitleWrapper,
      secHeading = _ref.secHeading,
      secText = _ref.secText,
      nameStyle = _ref.nameStyle,
      descriptionStyle = _ref.descriptionStyle,
      priceStyle = _ref.priceStyle,
      priceLabelStyle = _ref.priceLabelStyle,
      buttonStyle = _ref.buttonStyle,
      buttonFillStyle = _ref.buttonFillStyle,
      listContentStyle = _ref.listContentStyle;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    data: _data_Hosting_data__WEBPACK_IMPORTED_MODULE_11__["MONTHLY_PRICING_TABLE"],
    active: true
  }),
      _useState2 = _slicedToArray(_useState, 2),
      state = _useState2[0],
      setState = _useState2[1];

  var data = state.data;
  var activeStatus = state.active;
  var pricingCarouselOptions = {
    type: 'slider',
    perView: 3,
    gap: 30,
    bound: true,
    breakpoints: {
      1199: {
        perView: 2,
        type: 'carousel',
        peek: {
          before: 100,
          after: 100
        }
      },
      990: {
        type: 'carousel',
        perView: 1,
        peek: {
          before: 160,
          after: 160
        }
      },
      767: {
        type: 'carousel',
        perView: 1,
        peek: {
          before: 80,
          after: 80
        }
      },
      575: {
        type: 'carousel',
        perView: 1,
        gap: 15,
        peek: {
          before: 20,
          after: 20
        }
      }
    }
  };
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, sectionWrapper, {
    id: "pricing_section",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, secTitleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 97
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, secText, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 98
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, secHeading, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 99
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_pricing_style__WEBPACK_IMPORTED_MODULE_12__["PricingButtonWrapper"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 100
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
    title: "Monthly Plan",
    className: activeStatus ? 'active-item' : '',
    onClick: function onClick() {
      return setState({
        data: _data_Hosting_data__WEBPACK_IMPORTED_MODULE_11__["MONTHLY_PRICING_TABLE"],
        active: true
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 101
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
    title: "Annual Plan",
    className: activeStatus === false ? 'active-item' : '',
    onClick: function onClick() {
      return setState({
        data: _data_Hosting_data__WEBPACK_IMPORTED_MODULE_11__["YEARLY_PRICING_TABLE"],
        active: false
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 108
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 117
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_GlideCarousel__WEBPACK_IMPORTED_MODULE_9__["default"], {
    carouselSelector: "pricing-carousel",
    options: pricingCarouselOptions,
    controls: false,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 118
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, data.map(function (pricingTable, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_GlideCarousel_glideSlide__WEBPACK_IMPORTED_MODULE_10__["default"], {
      key: "pricing-table-".concat(index),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 125
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_pricing_style__WEBPACK_IMPORTED_MODULE_12__["default"], {
      freePlan: pricingTable.freePlan,
      className: "pricing_table",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 126
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_pricing_style__WEBPACK_IMPORTED_MODULE_12__["PricingHead"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 130
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({
      content: pricingTable.name
    }, nameStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 131
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
      content: pricingTable.description
    }, descriptionStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 132
      },
      __self: this
    }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_pricing_style__WEBPACK_IMPORTED_MODULE_12__["PricingPrice"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 137
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
      content: pricingTable.price
    }, priceStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 138
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
      content: pricingTable.priceLabel
    }, priceLabelStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 139
      },
      __self: this
    }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_pricing_style__WEBPACK_IMPORTED_MODULE_12__["PricingButton"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 144
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: pricingTable.url,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 145
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 146
      },
      __self: this
    }, pricingTable.freePlan ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({
      title: pricingTable.buttonLabel
    }, buttonStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 148
      },
      __self: this
    })) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({
      title: pricingTable.buttonLabel
    }, buttonFillStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 153
      },
      __self: this
    }))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_pricing_style__WEBPACK_IMPORTED_MODULE_12__["PricingList"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 161
      },
      __self: this
    }, pricingTable.listItems.map(function (item, index) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_pricing_style__WEBPACK_IMPORTED_MODULE_12__["ListItem"], {
        key: "pricing-table-list-".concat(index),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 163
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_kit__WEBPACK_IMPORTED_MODULE_3___default.a, {
        icon: react_icons_kit_icomoon_checkmark__WEBPACK_IMPORTED_MODULE_13__["checkmark"],
        className: "price_list_icon",
        size: 13,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 164
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
        content: item.content
      }, listContentStyle, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 169
        },
        __self: this
      })));
    }))));
  }))))));
};

PricingSection.propTypes = {
  sectionWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  secTitleWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  secHeading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  secText: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  nameStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  descriptionStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  priceStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  priceLabelStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  listContentStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
PricingSection.defaultProps = {
  sectionWrapper: {
    as: 'section',
    pt: ['60px', '80px', '80px', '80px', '120px'],
    pb: ['20px', '20px', '20px', '80px']
  },
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px',
    alignItems: 'center'
  },
  secTitleWrapper: {
    mb: ['50px', '75px']
  },
  secText: {
    content: 'PRICING PLAN',
    as: 'span',
    display: 'block',
    textAlign: 'center',
    fontSize: '14px',
    letterSpacing: '0.15em',
    fontWeight: '700',
    color: '#5268db',
    mb: '10px'
  },
  secHeading: {
    content: 'What’s our monthly pricing subscription',
    textAlign: 'center',
    fontSize: ['20px', '24px'],
    fontWeight: '500',
    color: 'headingColor',
    letterSpacing: '-0.025em',
    mb: '0'
  },
  col: {
    width: [1, 1 / 2, 1 / 2, 1 / 3],
    pr: '15px',
    pl: '15px'
  },
  nameStyle: {
    fontSize: ['20px', '20px', '22px', '22px', '22px'],
    fontWeight: '500',
    color: 'headingColor',
    letterSpacing: '-0.025em',
    textAlign: 'center',
    mb: '12px'
  },
  descriptionStyle: {
    fontSize: ['15px', '16px', '16px', '16px', '16px'],
    color: 'textColor',
    lineHeight: '1.75',
    textAlign: 'center',
    mb: '0'
  },
  priceStyle: {
    as: 'span',
    display: 'block',
    fontSize: ['36px', '36px', '40px', '40px', '40px'],
    color: 'headingColor',
    textAlign: 'center',
    mb: '5px',
    letterSpacing: '-0.025em'
  },
  priceLabelStyle: {
    fontSize: ['13px', '14px', '14px', '14px', '14px'],
    color: 'textColor',
    lineHeight: '1.75',
    textAlign: 'center',
    mb: '0'
  },
  buttonStyle: {
    type: 'button',
    fontSize: '14px',
    fontWeight: '600',
    borderRadius: '4px',
    pl: '10px',
    pr: '10px',
    colors: 'primary',
    width: '222px',
    maxWidth: '100%'
  },
  buttonFillStyle: {
    type: 'button',
    fontSize: '14px',
    fontWeight: '600',
    color: 'white',
    borderRadius: '4px',
    pl: '10px',
    pr: '10px',
    colors: 'primaryWithBg',
    width: '200px',
    maxWidth: '100%'
  },
  listContentStyle: {
    fontSize: ['15px', '16px', '16px', '16px', '16px'],
    color: 'textColor',
    mb: '0'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (PricingSection);

/***/ }),

/***/ "./containers/Saas/PricingSection/pricing.style.js":
/*!*********************************************************!*\
  !*** ./containers/Saas/PricingSection/pricing.style.js ***!
  \*********************************************************/
/*! exports provided: PricingHead, PricingPrice, PricingButton, PricingList, ListItem, SwitchWrapper, PricingButtonWrapper, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PricingHead", function() { return PricingHead; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PricingPrice", function() { return PricingPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PricingButton", function() { return PricingButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PricingList", function() { return PricingList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListItem", function() { return ListItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SwitchWrapper", function() { return SwitchWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PricingButtonWrapper", function() { return PricingButtonWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);


var PricingTable = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "pricingstyle__PricingTable",
  componentId: "sc-18jqgq5-0"
})(["border:1px solid #f2f4f7;border-radius:5px;padding:60px 45px;border-radius:5px;margin-bottom:30px;@media (max-width:767px){padding:45px 35px;}"]);
var PricingHead = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "pricingstyle__PricingHead",
  componentId: "sc-18jqgq5-1"
})(["margin-bottom:40px;"]);
var PricingPrice = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "pricingstyle__PricingPrice",
  componentId: "sc-18jqgq5-2"
})(["margin-bottom:30px;"]);
var PricingButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "pricingstyle__PricingButton",
  componentId: "sc-18jqgq5-3"
})(["text-align:center;margin-bottom:55px;"]);
var PricingList = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "pricingstyle__PricingList",
  componentId: "sc-18jqgq5-4"
})([""]);
var ListItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "pricingstyle__ListItem",
  componentId: "sc-18jqgq5-5"
})(["display:flex;margin-bottom:19px;&:last-child{margin-bottom:0;}.price_list_icon{color:#18d379;margin-right:10px;}"]);
var SwitchWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "pricingstyle__SwitchWrapper",
  componentId: "sc-18jqgq5-6"
})(["text-align:center;margin-top:20px;.reusecore__switch{.reusecore__field-label{font-size:16px;font-weight:400;color:#5c636c;cursor:pointer;}input[type='checkbox']{&:checked{+ div{width:40px !important;background-color:", ";> div{left:17px !important;}}}+ div{background-color:#f0f0f0;background-color:#f0f0f0;border:0;width:40px;height:25px;> div{background-color:#fff;box-shadow:0px 2px 3px 0.24px rgba(31,64,104,0.25);width:21px;height:21px;top:2px;left:2px;}}}}"], Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary'));
var PricingButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "pricingstyle__PricingButtonWrapper",
  componentId: "sc-18jqgq5-7"
})(["text-align:center;margin-top:30px;.reusecore__button{font-size:16px;font-weight:400;color:#6f7a87;background:#fff;height:50px;width:165px;border:1px solid #e4e9ee;&:nth-child(1){border-top-left-radius:5px;border-top-right-radius:0;border-bottom-right-radius:0;border-bottom-left-radius:5px;border-right-color:transparent;}&:nth-child(2){border-top-left-radius:0;border-top-right-radius:5px;border-bottom-right-radius:5px;border-bottom-left-radius:0;border-left-color:transparent;}&.active-item{color:#5167db;border-color:#5167db;}@media (max-width:575px){font-size:14px;height:44px;width:120px;padding:0 5px;}}"]);

/* harmony default export */ __webpack_exports__["default"] = (PricingTable);

/***/ }),

/***/ "./containers/Saas/ServiceSection/index.js":
/*!*************************************************!*\
  !*** ./containers/Saas/ServiceSection/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _data_Saas__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../data/Saas */ "./data/Saas/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _service_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./service.style */ "./containers/Saas/ServiceSection/service.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\ServiceSection\\index.js";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }











var ServiceSection = function ServiceSection(_ref) {
  var row = _ref.row,
      col = _ref.col,
      sectionHeader = _ref.sectionHeader,
      sectionTitle = _ref.sectionTitle,
      sectionSubTitle = _ref.sectionSubTitle,
      featureTitle = _ref.featureTitle,
      featureDescription = _ref.featureDescription,
      iconStyle = _ref.iconStyle,
      contentStyle = _ref.contentStyle,
      blockWrapperStyle = _ref.blockWrapperStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_service_style__WEBPACK_IMPORTED_MODULE_8__["default"], {
    id: "feature_section",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, sectionHeader, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
    content: "OUR FEATURES"
  }, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
    content: "Why you should choose our Saas"
  }, sectionTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    className: "row"
  }, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }), _data_Saas__WEBPACK_IMPORTED_MODULE_6__["Service"].map(function (feature, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
      className: "col"
    }, col, {
      key: index,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_5__["default"], {
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
        className: feature.icon,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 34
        },
        __self: this
      }),
      wrapperStyle: blockWrapperStyle,
      iconStyle: iconStyle,
      contentStyle: contentStyle,
      title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
        content: feature.title
      }, featureTitle, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        },
        __self: this
      })),
      description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
        content: feature.description
      }, featureDescription, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 40
        },
        __self: this
      })),
      className: "saasService",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33
      },
      __self: this
    }));
  }))));
}; // ServiceSection style props


ServiceSection.propTypes = {
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  featureTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  featureDescription: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // ServiceSection default style

ServiceSection.defaultProps = {
  // section header default style
  sectionHeader: {
    mb: ['50px', '50px', '50px', '80px']
  },
  // sub section default style
  sectionSubTitle: {
    as: 'span',
    display: 'block',
    textAlign: 'center',
    fontSize: '14px',
    letterSpacing: '0.15em',
    fontWeight: '700',
    color: '#5268db',
    mb: '10px'
  },
  // section title default style
  sectionTitle: {
    textAlign: 'center',
    fontSize: ['20px', '24px'],
    fontWeight: '500',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '0'
  },
  // feature row default style
  row: {
    flexBox: true,
    flexWrap: 'wrap'
  },
  // feature col default style
  col: {
    width: [1, 1 / 2, 1 / 2, 1 / 3]
  },
  // feature block wrapper default style
  blockWrapperStyle: {
    p: ['30px', '20px', '20px', '20px']
  },
  // feature icon default style
  iconStyle: {
    width: ['70px', '80px'],
    height: ['70px', '80px'],
    borderRadius: '50%',
    bg: '#93d26e',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: ['32px', '36px'],
    color: '#ffffff',
    overflow: 'hidden',
    mb: '30px',
    borderBottomLeftRadius: '50%'
  },
  // feature content default style
  contentStyle: {
    textAlign: 'left',
    mt: '-5px'
  },
  // feature title default style
  featureTitle: _defineProperty({
    fontSize: ['18px', '20px'],
    fontWeight: '400',
    color: '#0f2137',
    lineHeight: '1.5',
    mb: '20px',
    letterSpacing: '-0.020em'
  }, "mb", '10px'),
  // feature description default style
  featureDescription: {
    fontSize: '15px',
    lineHeight: '1.75',
    color: '#343d4ccc'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (ServiceSection);

/***/ }),

/***/ "./containers/Saas/ServiceSection/service.style.js":
/*!*********************************************************!*\
  !*** ./containers/Saas/ServiceSection/service.style.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var ServiceSectionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "servicestyle__ServiceSectionWrapper",
  componentId: "sc-1if930n-0"
})(["padding:80px 0 40px;@media (max-width:990px){padding:60px 0 0 0;}.feature__block{position:relative;height:100%;transition:box-shadow 0.3s ease;display:flex;@media (max-width:500px){padding:30px 0;}.icon__wrapper{position:relative;border-bottom-right-radius:6px;flex-shrink:0;margin-right:22px;background:#fff5f6;.flaticon-flask{&:before{margin-left:8px;}}}&:hover{", "}}.row{> .col{&:nth-child(-n + 3){}&:nth-child(3n + 3),&:last-child{}&:nth-child(1){.feature__block{.icon__wrapper{background:#fff5f6;color:#f55767;}}}&:nth-child(2){.feature__block{.icon__wrapper{background:#ebfff2;color:#29c05e;}}}&:nth-child(3){.feature__block{.icon__wrapper{background:#f1faff;color:#2595d4;}}}&:nth-child(4){.feature__block{.icon__wrapper{background:#fffae8;color:#e9b600;}}}&:nth-child(5){.feature__block{.icon__wrapper{background:#f5eeff;color:#a55cef;}}}&:nth-child(6){.feature__block{.icon__wrapper{background:#ffecfa;color:#e764a5;}}}}}"], ''
/* box-shadow: 0 40px 90px -30px rgba(39, 79, 117, 0.2); */
);
/* harmony default export */ __webpack_exports__["default"] = (ServiceSectionWrapper);

/***/ }),

/***/ "./containers/Saas/TestimonialSection/index.js":
/*!*****************************************************!*\
  !*** ./containers/Saas/TestimonialSection/index.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _data_Saas__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../data/Saas */ "./data/Saas/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _components_GlideCarousel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../components/GlideCarousel */ "./components/GlideCarousel/index.js");
/* harmony import */ var _components_GlideCarousel_glideSlide__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../components/GlideCarousel/glideSlide */ "./components/GlideCarousel/glideSlide.js");
/* harmony import */ var _testimonialSection_style__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./testimonialSection.style */ "./containers/Saas/TestimonialSection/testimonialSection.style.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\TestimonialSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }













var TestimonialSection = function TestimonialSection(_ref) {
  var sectionSubTitle = _ref.sectionSubTitle,
      btnWrapperStyle = _ref.btnWrapperStyle,
      commentStyle = _ref.commentStyle,
      nameStyle = _ref.nameStyle,
      btnStyle = _ref.btnStyle,
      designationStyle = _ref.designationStyle;
  // Glide js options
  var glideOptions = {
    type: 'carousel',
    autoplay: 4000,
    perView: 1
  };
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_testimonialSection_style__WEBPACK_IMPORTED_MODULE_10__["default"], {
    id: "testimonial_section",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
    content: "CLIENT COMMENTS"
  }, sectionSubTitle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_GlideCarousel__WEBPACK_IMPORTED_MODULE_8__["default"], {
    options: glideOptions,
    buttonWrapperStyle: btnWrapperStyle,
    nextButton: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
        className: "flaticon-right-arrow",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 42
        },
        __self: this
      }),
      variant: "textButton"
    }, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41
      },
      __self: this
    })),
    prevButton: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
        className: "flaticon-left-arrow",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 49
        },
        __self: this
      }),
      variant: "textButton"
    }, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 48
      },
      __self: this
    })),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  }, _data_Saas__WEBPACK_IMPORTED_MODULE_6__["Testimonial"].map(function (item, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_GlideCarousel_glideSlide__WEBPACK_IMPORTED_MODULE_9__["default"], {
      key: index,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 57
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 58
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_testimonialSection_style__WEBPACK_IMPORTED_MODULE_10__["TextWrapper"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 59
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
      className: "flaticon-quote",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 60
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
      content: item.comment
    }, commentStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 61
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_testimonialSection_style__WEBPACK_IMPORTED_MODULE_10__["ClientName"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 62
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
      content: item.name
    }, nameStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 63
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({
      content: item.designation
    }, designationStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 64
      },
      __self: this
    })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_testimonialSection_style__WEBPACK_IMPORTED_MODULE_10__["ImageWrapper"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 70
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_testimonialSection_style__WEBPACK_IMPORTED_MODULE_10__["RoundWrapper"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 71
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_5__["default"], {
      src: item.avatar_url,
      alt: "Client Image",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 72
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_4__["default"], {
      variant: "fab",
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", {
        className: item.social_icon,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 76
        },
        __self: this
      }),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 74
      },
      __self: this
    }))));
  })))));
}; // TestimonialSection style props


TestimonialSection.propTypes = {
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  btnStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  btnWrapperStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  nameStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  commentStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  designationStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
}; // TestimonialSection default style

TestimonialSection.defaultProps = {
  // sub section default style
  sectionSubTitle: {
    as: 'span',
    display: 'block',
    fontSize: '14px',
    letterSpacing: '0.15em',
    fontWeight: '700',
    color: '#5268db',
    mb: '20px',
    ml: 'auto',
    mr: 'auto',
    pl: '12px',
    maxWidth: '954px'
  },
  // client comment style
  commentStyle: {
    color: '#0f2137',
    fontWeight: '400',
    fontSize: ['22px', '22px', '22px', '30px'],
    lineHeight: '1.72',
    mb: '47px'
  },
  // client name style
  nameStyle: {
    as: 'h3',
    color: '#343d48',
    fontWeight: '500',
    fontSize: '16px',
    lineHeight: '30px',
    mb: 0
  },
  // client designation style
  designationStyle: {
    as: 'h5',
    color: 'rgba(52, 61, 72, 0.8)',
    fontWeight: '400',
    fontSize: '16px',
    lineHeight: '30px',
    mb: 0,
    ml: ['0', '10px']
  },
  // glide slider nav controls style
  btnWrapperStyle: {
    position: 'absolute',
    bottom: '62px',
    left: '12px'
  },
  // next / prev btn style
  btnStyle: {
    minWidth: 'auto',
    minHeight: 'auto',
    mr: '13px',
    fontSize: '16px',
    color: '#343d484d'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (TestimonialSection);

/***/ }),

/***/ "./containers/Saas/TestimonialSection/testimonialSection.style.js":
/*!************************************************************************!*\
  !*** ./containers/Saas/TestimonialSection/testimonialSection.style.js ***!
  \************************************************************************/
/*! exports provided: TextWrapper, ImageWrapper, ClientName, RoundWrapper, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TextWrapper", function() { return TextWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageWrapper", function() { return ImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientName", function() { return ClientName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RoundWrapper", function() { return RoundWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);


var TestimonialSectionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "testimonialSectionstyle__TestimonialSectionWrapper",
  componentId: "gwil2k-0"
})(["padding:80px 0 120px;overflow:hidden;@media (max-width:990px){padding-bottom:80px;}@media (max-width:767px){padding-top:40px;}.glide{max-width:954px;margin:0 auto;.glide__slide{display:flex;margin-bottom:40px;@media only screen and (max-width:991px){padding-top:30px;}@media only screen and (max-width:680px){flex-direction:column-reverse;}}.glide__controls{position:relative;bottom:0;.reusecore__button{&:hover{color:", ";}}}}"], Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.quoteText', '#343d48'));
var TextWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "testimonialSectionstyle__TextWrapper",
  componentId: "gwil2k-1"
})(["max-width:540px;margin-right:auto;position:relative;padding-left:12px;margin-right:30px;p{text-indent:27px;margin-bottom:25px;}i{color:rgba(52,61,72,0.2);font-size:20px;position:absolute;top:0;left:12px;z-index:-1;}"]);
var ImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "testimonialSectionstyle__ImageWrapper",
  componentId: "gwil2k-2"
})(["width:256px;height:256px;position:relative;@media only screen and (max-width:680px){margin-bottom:40px;}.reusecore__button{position:absolute;z-index:2;bottom:0;left:20px;width:65px;height:65px;font-size:26px;background-color:rgb(220,57,95);box-shadow:0px 10px 28.2px 1.8px rgba(23,65,104,0.2);}"]);
var RoundWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "testimonialSectionstyle__RoundWrapper",
  componentId: "gwil2k-3"
})(["width:256px;height:256px;border-radius:50%;box-sizing:border-box;border-bottom-right-radius:10px;background:rgb(232,230,192);background:radial-gradient( circle,rgba(232,230,192,1) 0%,rgba(199,195,134,1) 100% );overflow:hidden;"]);
var ClientName = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "testimonialSectionstyle__ClientName",
  componentId: "gwil2k-4"
})(["display:flex;align-items:center;@media (max-width:575px){flex-direction:column;align-items:inherit;}"]);

/* harmony default export */ __webpack_exports__["default"] = (TestimonialSectionWrapper);

/***/ }),

/***/ "./containers/Saas/TimelineSection/index.js":
/*!**************************************************!*\
  !*** ./containers/Saas/TimelineSection/index.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-reveal/Fade */ "react-reveal/Fade");
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_reveal_Slide__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-reveal/Slide */ "react-reveal/Slide");
/* harmony import */ var react_reveal_Slide__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Slide__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _timeline_style__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./timeline.style */ "./containers/Saas/TimelineSection/timeline.style.js");
/* harmony import */ var _data_Saas__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../data/Saas */ "./data/Saas/index.js");
/* harmony import */ var _assets_image_saas_illustration_png__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../assets/image/saas/illustration.png */ "./assets/image/saas/illustration.png");
/* harmony import */ var _assets_image_saas_illustration_png__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_illustration_png__WEBPACK_IMPORTED_MODULE_13__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\TimelineSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
















var TimelineSection = function TimelineSection(_ref) {
  var sectionWrapper = _ref.sectionWrapper,
      sectionHeader = _ref.sectionHeader,
      sectionTitle = _ref.sectionTitle,
      sectionSubTitle = _ref.sectionSubTitle,
      row = _ref.row,
      col = _ref.col,
      button = _ref.button,
      textArea = _ref.textArea,
      imageArea = _ref.imageArea,
      imageTwo = _ref.imageTwo,
      buttonWrapper = _ref.buttonWrapper,
      indexStyle = _ref.indexStyle,
      timelineTitle = _ref.timelineTitle,
      timelineDescription = _ref.timelineDescription;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, sectionWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_10__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, sectionHeader, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, sectionSubTitle, {
    content: "WORKING STEP",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({}, sectionTitle, {
    content: "How Pestro work behind the scenes",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, col, imageArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default.a, {
    bottom: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_9__["default"], _extends({}, imageTwo, {
    src: _assets_image_saas_illustration_png__WEBPACK_IMPORTED_MODULE_13___default.a,
    alt: "Illustration",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, col, textArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_timeline_style__WEBPACK_IMPORTED_MODULE_11__["TimelineWrapper"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }, _data_Saas__WEBPACK_IMPORTED_MODULE_12__["Timeline"].map(function (item, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_timeline_style__WEBPACK_IMPORTED_MODULE_11__["TimelineItem"], {
      key: "timeline-item-".concat(index),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 61
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_timeline_style__WEBPACK_IMPORTED_MODULE_11__["TimelineIndex"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 62
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_timeline_style__WEBPACK_IMPORTED_MODULE_11__["Hidden"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 63
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Slide__WEBPACK_IMPORTED_MODULE_4___default.a, {
      bottom: true,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 64
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({
      as: "span",
      content: item.index || "0".concat(index + 1)
    }, indexStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 65
      },
      __self: this
    }))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_timeline_style__WEBPACK_IMPORTED_MODULE_11__["TimelineContent"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 73
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_timeline_style__WEBPACK_IMPORTED_MODULE_11__["Hidden"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 74
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Slide__WEBPACK_IMPORTED_MODULE_4___default.a, {
      bottom: true,
      delay: 100,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 75
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({
      as: "h2",
      content: item.title
    }, timelineTitle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 76
      },
      __self: this
    })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_timeline_style__WEBPACK_IMPORTED_MODULE_11__["Hidden"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 83
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Slide__WEBPACK_IMPORTED_MODULE_4___default.a, {
      bottom: true,
      delay: 200,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 84
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({
      content: item.description
    }, timelineDescription, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 85
      },
      __self: this
    }))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_timeline_style__WEBPACK_IMPORTED_MODULE_11__["TimelineDot"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 92
      },
      __self: this
    }));
  })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, buttonWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 98
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: "#",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 99
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 100
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_8__["default"], _extends({}, button, {
    title: "HIRE FOR PROJECT",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 101
    },
    __self: this
  })))))));
};

TimelineSection.propTypes = {
  sectionWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionHeader: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  sectionSubTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  col: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  textArea: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  imageArea: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  imageTwo: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  buttonWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  indexStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  timelineTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  timelineDescription: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
TimelineSection.defaultProps = {
  sectionWrapper: {
    as: 'section',
    pt: ['60px', '80px', '80px', '80px'],
    pb: ['60px', '80px', '80px', '80px']
  },
  // section header default style
  sectionHeader: {
    mb: '56px'
  },
  // sub section default style
  sectionSubTitle: {
    as: 'span',
    display: 'block',
    textAlign: 'center',
    fontSize: '14px',
    letterSpacing: '0.15em',
    fontWeight: '700',
    color: '#5268db',
    mb: '10px'
  },
  // section title default style
  sectionTitle: {
    textAlign: 'center',
    fontSize: ['20px', '24px'],
    fontWeight: '500',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '0'
  },
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    ml: '-15px',
    mr: '-15px',
    alignItems: 'center'
  },
  imageAreaRow: {
    flexDirection: 'row-reverse'
  },
  col: {
    pr: '15px',
    pl: '15px'
  },
  textArea: {
    width: ['100%', '100%', '55%', '50%', '55%'],
    mb: ['40px', '40px', '0', '0', '0']
  },
  imageArea: {
    width: ['100%', '100%', '45%', '50%', '45%'],
    mb: ['30px', '40px', '40px', '0', '0']
  },
  title: {
    fontSize: ['30px', '38px', '38px', '48px', '48px'],
    fontWeight: '300',
    color: 'headingColor',
    letterSpacing: '-0.025em',
    mb: '15px'
  },
  description: {
    fontSize: '16px',
    color: 'textColor',
    lineHeight: '1.75',
    mb: '33px'
  },
  buttonWrapper: {
    mt: ['25px', '50px'],
    flexBox: true,
    justifyContent: 'center'
  },
  button: {
    type: 'button',
    fontSize: '14px',
    fontWeight: '600',
    borderRadius: '4px',
    pl: '22px',
    pr: '22px',
    colors: 'primaryWithBg',
    height: '46px'
  },
  imageOne: {
    mb: '40px',
    ml: 'auto',
    mr: 'auto'
  },
  imageTwo: {
    ml: 'auto',
    mr: 'auto'
  },
  indexStyle: {
    fontSize: ['36px', '42px', '52px', '56px', '72px'],
    fontWeight: '300',
    color: '#eaebec',
    display: 'block',
    lineHeight: '1',
    mb: '0'
  },
  timelineTitle: {
    fontSize: ['16px', '17px', '18px', '18px', '20px'],
    fontWeight: '500',
    color: '#0f2137',
    letterSpacing: '-0.025em',
    mb: '13px'
  },
  timelineDescription: {
    fontSize: ['14px', '15px', '15px', '15px', '16px'],
    lineHeight: '2',
    color: '#5d646d',
    mb: '0'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (TimelineSection);

/***/ }),

/***/ "./containers/Saas/TimelineSection/timeline.style.js":
/*!***********************************************************!*\
  !*** ./containers/Saas/TimelineSection/timeline.style.js ***!
  \***********************************************************/
/*! exports provided: TimelineWrapper, TimelineDot, TimelineItem, TimelineIndex, TimelineContent, Hidden */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TimelineWrapper", function() { return TimelineWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TimelineDot", function() { return TimelineDot; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TimelineItem", function() { return TimelineItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TimelineIndex", function() { return TimelineIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TimelineContent", function() { return TimelineContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Hidden", function() { return Hidden; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var TimelineWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "timelinestyle__TimelineWrapper",
  componentId: "sc-133ix1s-0"
})([""]);
var TimelineDot = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "timelinestyle__TimelineDot",
  componentId: "sc-133ix1s-1"
})(["width:20px;height:20px;border-radius:50%;position:absolute;top:50%;left:0;box-shadow:0px 3px 8.46px 0.54px rgba(23,65,104,0.2);z-index:1;background:#fff;transform:translateY(-50%);&:after{content:'';position:absolute;width:12px;height:12px;border-radius:50%;top:50%;left:50%;transform:translate(-50%,-50%);background:#ebedf5;transition:0.25s ease-in-out;}@media (max-width:480px){width:16px;height:16px;&:after{width:10px;height:10px;}}"]);
var TimelineItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "timelinestyle__TimelineItem",
  componentId: "sc-133ix1s-2"
})(["position:relative;display:flex;align-items:center;margin-bottom:90px;padding-left:50px;&:first-child{&:before{display:none;}}&:last-child{margin-bottom:0;&:after{display:none;}}&:hover{", "{&:after{background:#5268db;}}}&:after,&:before{content:'';position:absolute;height:calc(50% + 45px);width:2px;background:#f0f0f1;left:9px;@media (max-width:480px){left:7px;}}&:before{bottom:50%;}&:after{top:50%;}@media (max-width:990px){margin-bottom:60px;}@media (max-width:480px){padding-left:30px;}"], TimelineDot);
var TimelineIndex = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "timelinestyle__TimelineIndex",
  componentId: "sc-133ix1s-3"
})([""]);
var TimelineContent = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "timelinestyle__TimelineContent",
  componentId: "sc-133ix1s-4"
})(["margin-left:30px;@media (max-width:480px){margin-left:20px;}"]);
var Hidden = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "timelinestyle__Hidden",
  componentId: "sc-133ix1s-5"
})(["overflow:hidden;"]);

/***/ }),

/***/ "./containers/Saas/TrialSection/index.js":
/*!***********************************************!*\
  !*** ./containers/Saas/TrialSection/index.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _saas_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../saas.style */ "./containers/Saas/saas.style.js");
/* harmony import */ var _assets_image_saas_vendor_logos_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../assets/image/saas/vendor-logos.png */ "./assets/image/saas/vendor-logos.png");
/* harmony import */ var _assets_image_saas_vendor_logos_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_vendor_logos_png__WEBPACK_IMPORTED_MODULE_9__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\TrialSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }












var TrialSection = function TrialSection(_ref) {
  var sectionWrapper = _ref.sectionWrapper,
      row = _ref.row,
      title = _ref.title,
      description = _ref.description,
      textArea = _ref.textArea,
      imageArea = _ref.imageArea,
      ImageOne = _ref.ImageOne,
      btnStyle = _ref.btnStyle,
      outlineBtnStyle = _ref.outlineBtnStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, sectionWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, imageArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({}, ImageOne, {
    src: _assets_image_saas_vendor_logos_png__WEBPACK_IMPORTED_MODULE_9___default.a,
    alt: "VendorLogos",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, textArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, title, {
    content: "Start your 30 days free trials today!",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({}, description, {
    content: "We have provided 30 Days Money Back Guarantee in case of dissatisfaction with our product. We care for our customers and their values.",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_saas_style__WEBPACK_IMPORTED_MODULE_8__["ButtonGroup"], {
    className: "button_group",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
    title: "WORK HISTORY"
  }, btnStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({
    title: "Login with Email",
    variant: "textButton"
  }, outlineBtnStyle, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    },
    __self: this
  })))))));
};

TrialSection.propTypes = {
  sectionWrapper: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  row: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  button: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  imageArea: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  ImageOne: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
TrialSection.defaultProps = {
  sectionWrapper: {
    as: 'section',
    className: 'trial-section',
    pt: ['20px', '40px', '60px', '80px'],
    pb: ['0px', '0px', '0px', '80px']
  },
  row: {
    flexBox: true,
    flexWrap: 'wrap',
    flexDirection: 'column',
    alignItems: 'center'
  },
  textArea: {
    width: ['100%', '100%', '80%', '43%']
  },
  imageArea: {
    width: ['100%', '100%', '43%'],
    mb: ['35px', '35px', '40px', '40px']
  },
  title: {
    fontSize: ['32px', '32px', '36px', '42px', '48px'],
    fontWeight: '400',
    color: 'headingColor',
    letterSpacing: '-0.025em',
    mb: '28px',
    textAlign: 'center',
    lineHeight: '1.25'
  },
  description: {
    fontSize: ['15px', '15px', '16px', '16px', '16px'],
    color: 'textColor',
    lineHeight: '2.1',
    textAlign: 'center',
    mb: ['35px', '35px', '40px', '60px']
  },
  ImageOne: {
    ml: 'auto',
    mr: 'auto'
  },
  btnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500',
    colors: 'primaryWithBg'
  },
  outlineBtnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500',
    color: '#0f2137'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (TrialSection);

/***/ }),

/***/ "./containers/Saas/VisitorSection/index.js":
/*!*************************************************!*\
  !*** ./containers/Saas/VisitorSection/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-reveal/Fade */ "react-reveal/Fade");
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_reveal_Zoom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-reveal/Zoom */ "react-reveal/Zoom");
/* harmony import */ var react_reveal_Zoom__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Zoom__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! reusecore/src/elements/Box */ "../../node_modules/reusecore/src/elements/Box/index.js");
/* harmony import */ var reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reusecore/src/elements/Text */ "../../node_modules/reusecore/src/elements/Text/index.js");
/* harmony import */ var reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! reusecore/src/elements/Heading */ "../../node_modules/reusecore/src/elements/Heading/index.js");
/* harmony import */ var reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reusecore/src/elements/Button */ "../../node_modules/reusecore/src/elements/Button/index.js");
/* harmony import */ var reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reusecore/src/elements/Card */ "../../node_modules/reusecore/src/elements/Card/index.js");
/* harmony import */ var reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reusecore/src/elements/Image */ "../../node_modules/reusecore/src/elements/Image/index.js");
/* harmony import */ var _components_FeatureBlock__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/FeatureBlock */ "./components/FeatureBlock/index.js");
/* harmony import */ var _components_UI_Container__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/UI/Container */ "./components/UI/Container/index.js");
/* harmony import */ var _visitor_style__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./visitor.style */ "./containers/Saas/VisitorSection/visitor.style.js");
/* harmony import */ var _assets_image_saas_saasvisitor1_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../assets/image/saas/saasvisitor1.png */ "./assets/image/saas/saasvisitor1.png");
/* harmony import */ var _assets_image_saas_saasvisitor1_png__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_saasvisitor1_png__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_image_saas_visitor_bg_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../assets/image/saas/visitor_bg.png */ "./assets/image/saas/visitor_bg.png");
/* harmony import */ var _assets_image_saas_visitor_bg_png__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_visitor_bg_png__WEBPACK_IMPORTED_MODULE_15__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\containers\\Saas\\VisitorSection\\index.js";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }


















var VisitorSection = function VisitorSection(_ref) {
  var title = _ref.title,
      description = _ref.description,
      textArea = _ref.textArea,
      imageWrapper = _ref.imageWrapper,
      btnStyle = _ref.btnStyle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_visitor_style__WEBPACK_IMPORTED_MODULE_13__["default"], {
    id: "visitorSection",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_visitor_style__WEBPACK_IMPORTED_MODULE_13__["SectionObject"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_9__["default"], _extends({
    className: "objectWrapper"
  }, imageWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Zoom__WEBPACK_IMPORTED_MODULE_4___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_10__["default"], {
    src: _assets_image_saas_visitor_bg_png__WEBPACK_IMPORTED_MODULE_15___default.a,
    alt: "BgImage",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Card__WEBPACK_IMPORTED_MODULE_9__["default"], _extends({
    className: "dashboardWrapper"
  }, imageWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_3___default.a, {
    left: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Image__WEBPACK_IMPORTED_MODULE_10__["default"], {
    src: _assets_image_saas_saasvisitor1_png__WEBPACK_IMPORTED_MODULE_14___default.a,
    alt: "VisitorDashboard1",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    __self: this
  }))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_UI_Container__WEBPACK_IMPORTED_MODULE_12__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Box__WEBPACK_IMPORTED_MODULE_5__["default"], _extends({}, textArea, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FeatureBlock__WEBPACK_IMPORTED_MODULE_11__["default"], {
    title: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Heading__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({
      content: "Make your website growth with next level visitors"
    }, title, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 44
      },
      __self: this
    })),
    description: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Text__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({
      content: "For Enhanced performance we use LiteSpeed Web Server, HTTP/2, PHP7. We make your website faster, which will help you to increase search ranking!."
    }, description, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50
      },
      __self: this
    })),
    button: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "#",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 56
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 57
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reusecore_src_elements_Button__WEBPACK_IMPORTED_MODULE_8__["default"], _extends({
      title: "HOW IT WORKS"
    }, btnStyle, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 58
      },
      __self: this
    })))),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  }))));
};

VisitorSection.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  btnStyle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};
VisitorSection.defaultProps = {
  textArea: {
    width: ['100%', '100%', '45%'],
    ml: [0, 0, '58%']
  },
  imageWrapper: {
    boxShadow: 'none'
  },
  title: {
    fontSize: ['20px', '26px', '26px', '36px', '48px'],
    fontWeight: '400',
    color: '#0f2137',
    letterSpacing: '-0.010em',
    mb: '20px',
    maxWidth: ['100%', '100%', '100%', '440px', '440px'],
    lineHeight: '1.5'
  },
  description: {
    fontSize: '16px',
    color: '#343d48cc',
    lineHeight: '1.75',
    mb: '33px',
    maxWidth: ['100%', '100%', '100%', '440px', '440px']
  },
  btnStyle: {
    minWidth: '156px',
    fontSize: '14px',
    fontWeight: '500',
    color: '#fff',
    borderRadius: '4px',
    pl: '22px',
    pr: '22px',
    colors: 'primaryWithBg'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (VisitorSection);

/***/ }),

/***/ "./containers/Saas/VisitorSection/visitor.style.js":
/*!*********************************************************!*\
  !*** ./containers/Saas/VisitorSection/visitor.style.js ***!
  \*********************************************************/
/*! exports provided: SectionObject, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SectionObject", function() { return SectionObject; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

var VisitorSectionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.section.withConfig({
  displayName: "visitorstyle__VisitorSectionWrapper",
  componentId: "knykp2-0"
})(["min-height:630px;display:flex;align-items:center;margin-bottom:40px;position:relative;@media only screen and (max-width:1200px){min-height:500px;margin-bottom:45px;}@media only screen and (max-width:991px){min-height:370px;margin-bottom:40px;}@media (max-width:767px){min-height:auto;display:block;}"]);
var SectionObject = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "visitorstyle__SectionObject",
  componentId: "knykp2-1"
})(["position:absolute;width:55%;height:100%;top:0;left:0;display:flex;align-items:center;justify-content:flex-end;@media (max-width:767px){width:100%;position:relative;height:auto;top:auto;left:auto;}img{max-width:93%;height:auto;}.objectWrapper{margin-right:auto;position:relative;.dashboardWrapper{position:absolute;top:4vw;left:0;}}"]);

/* harmony default export */ __webpack_exports__["default"] = (VisitorSectionWrapper);

/***/ }),

/***/ "./containers/Saas/saas.style.js":
/*!***************************************!*\
  !*** ./containers/Saas/saas.style.js ***!
  \***************************************/
/*! exports provided: GlobalStyle, ContentWrapper, ButtonGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlobalStyle", function() { return GlobalStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentWrapper", function() { return ContentWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonGroup", function() { return ButtonGroup; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_image_saas_map_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../assets/image/saas/map.png */ "./assets/image/saas/map.png");
/* harmony import */ var _assets_image_saas_map_png__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_map_png__WEBPACK_IMPORTED_MODULE_2__);
function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  body{\n    font-family: 'Roboto', sans-serif;\n  }\n\n  h1,\n  h2,\n  h3,\n  h4,\n  h5,\n  h6 {\n    font-family: 'Roboto', sans-serif;\n  }\n\n  section {\n    position: relative;\n  }\n\n  .drawer-content-wrapper{\n    @media (max-width: 767px) {\n      width: 300px!important;\n    }\n    .drawer-content {\n      padding: 60px;    \n      display: flex;\n      flex-direction: column;\n      justify-content: space-between;\n      @media (max-width: 767px) {\n        padding: 50px 40px 30px 40px;\n      }\n      .mobile_menu {\n        margin-bottom: 40px;\n        flex-grow: 1;\n        @media (max-width: 767px) {\n          margin-bottom: 30px;\n        }\n        li{\n          margin-bottom: 35px;\n          @media (max-width: 767px) {\n            margin-bottom: 25px;\n          }\n          a{\n            font-size: 20px;\n            font-weight: 400;\n            color: #343d48;\n            position: relative;\n            transition: 0.15s ease-in-out;\n            @media (max-width: 767px) {\n              font-size: 18px;\n            }\n            &:hover {\n              color: #eb4d4b;\n            }\n            &:before{\n              content: '';\n              width: 7px;\n              height: 7px;\n              background: #eb4d4b;\n              border-radius: 50%;\n              position: absolute;\n              top: 50%;\n              left: -15px;\n              transform: translateY(-50%);\n              opacity: 0;\n            }\n          }\n          &.is-current {\n            a {\n              color: #eb4d4b;\n              &:before{\n                opacity: 1;\n              }\n            }\n          }\n        }\n      }\n      .navbar_drawer_button button{\n        width: 100%;\n      }\n    }\n\n    .reusecore-drawer__close{\n      width: 34px;\n      height: 34px;\n      position: absolute;\n      top: 20px;\n      right: 20px;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      cursor: pointer;\n      @media (max-width: 767px) {\n        top: 15px;\n        right: 15px;\n      }\n      &:before{\n        content: '\f10b';\n        font-family: Flaticon;\n        font-size: 26px;\n        color: #eb4d4b;\n        transform: rotate(45deg);\n        display: block;\n      }\n    }\n  }\n\n  /* Modal default style */\n  button.modalCloseBtn {\n    color: ", ";\n\n    &.alt {\n      background-color: ", ";\n      box-shadow: 0px 9px 20px -5px rgba(82, 104, 219, 0.57);\n    }   \n  }\n"], ["\n  body{\n    font-family: 'Roboto', sans-serif;\n  }\n\n  h1,\n  h2,\n  h3,\n  h4,\n  h5,\n  h6 {\n    font-family: 'Roboto', sans-serif;\n  }\n\n  section {\n    position: relative;\n  }\n\n  .drawer-content-wrapper{\n    @media (max-width: 767px) {\n      width: 300px!important;\n    }\n    .drawer-content {\n      padding: 60px;    \n      display: flex;\n      flex-direction: column;\n      justify-content: space-between;\n      @media (max-width: 767px) {\n        padding: 50px 40px 30px 40px;\n      }\n      .mobile_menu {\n        margin-bottom: 40px;\n        flex-grow: 1;\n        @media (max-width: 767px) {\n          margin-bottom: 30px;\n        }\n        li{\n          margin-bottom: 35px;\n          @media (max-width: 767px) {\n            margin-bottom: 25px;\n          }\n          a{\n            font-size: 20px;\n            font-weight: 400;\n            color: #343d48;\n            position: relative;\n            transition: 0.15s ease-in-out;\n            @media (max-width: 767px) {\n              font-size: 18px;\n            }\n            &:hover {\n              color: #eb4d4b;\n            }\n            &:before{\n              content: '';\n              width: 7px;\n              height: 7px;\n              background: #eb4d4b;\n              border-radius: 50%;\n              position: absolute;\n              top: 50%;\n              left: -15px;\n              transform: translateY(-50%);\n              opacity: 0;\n            }\n          }\n          &.is-current {\n            a {\n              color: #eb4d4b;\n              &:before{\n                opacity: 1;\n              }\n            }\n          }\n        }\n      }\n      .navbar_drawer_button button{\n        width: 100%;\n      }\n    }\n\n    .reusecore-drawer__close{\n      width: 34px;\n      height: 34px;\n      position: absolute;\n      top: 20px;\n      right: 20px;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      cursor: pointer;\n      @media (max-width: 767px) {\n        top: 15px;\n        right: 15px;\n      }\n      &:before{\n        content: '\\f10b';\n        font-family: Flaticon;\n        font-size: 26px;\n        color: #eb4d4b;\n        transform: rotate(45deg);\n        display: block;\n      }\n    }\n  }\n\n  /* Modal default style */\n  button.modalCloseBtn {\n    color: ", ";\n\n    &.alt {\n      background-color: ", ";\n      box-shadow: 0px 9px 20px -5px rgba(82, 104, 219, 0.57);\n    }   \n  }\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var GlobalStyle = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["createGlobalStyle"])(_templateObject(), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary', '#5268db'));
var ContentWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "saasstyle__ContentWrapper",
  componentId: "d1gmi1-0"
})(["position:relative;overflow:hidden;a:-webkit-any-link{text-decoration:none;}.sticky-nav-active{.hosting_navbar{background:#fff;box-shadow:0 0 20px rgba(0,0,0,0.15);padding:15px 0;}}.hosting_navbar{position:fixed;top:0;left:0;width:100%;transition:0.35s ease-in-out;padding:30px 0;.main_menu{margin-right:40px;li{display:inline-block;padding-left:13px;padding-right:13px;&:first-child{padding-left:0;}&:last-child{padding-right:0;}&.is-current{a{color:#eb4d4b;}}a{padding:5px;font-size:16px;font-weight:400;color:#343d48;transition:0.15s ease-in-out;&:hover{color:#eb4d4b;}}}@media (max-width:990px){display:none;}}.navbar_button{@media (max-width:990px){display:none;}}.reusecore-drawer__handler{@media (min-width:991px){display:none !important;}.hamburgMenu__bar{> span{}}}}.trial-section{background:linear-gradient(to bottom,#fafbff 0%,#f7f8fd 100%);.button_group{text-align:center;}}.partner_section{background-color:#fafbff;background-image:url(", ");background-repeat:no-repeat;background-position:25% center;}@media (max-width:990px){.glide__slide--active .pricing_table{box-shadow:0px 0px 30px rgba(0,0,0,0.05);border:0;}}"], _assets_image_saas_map_png__WEBPACK_IMPORTED_MODULE_2___default.a);
var ButtonGroup = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "saasstyle__ButtonGroup",
  componentId: "d1gmi1-1"
})([""]);

/***/ }),

/***/ "./contexts/DrawerContext.js":
/*!***********************************!*\
  !*** ./contexts/DrawerContext.js ***!
  \***********************************/
/*! exports provided: DrawerContext, DrawerProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrawerContext", function() { return DrawerContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrawerProvider", function() { return DrawerProvider; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\contexts\\DrawerContext.js";

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var initialState = {
  isOpen: false
};

function reducer(state, action) {
  switch (action.type) {
    case 'TOGGLE':
      return _objectSpread({}, state, {
        isOpen: !state.isOpen
      });

    default:
      return state;
  }
}

var DrawerContext = react__WEBPACK_IMPORTED_MODULE_0___default.a.createContext({});
var DrawerProvider = function DrawerProvider(_ref) {
  var children = _ref.children;

  var _useReducer = Object(react__WEBPACK_IMPORTED_MODULE_0__["useReducer"])(reducer, initialState),
      _useReducer2 = _slicedToArray(_useReducer, 2),
      state = _useReducer2[0],
      dispatch = _useReducer2[1];

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(DrawerContext.Provider, {
    value: {
      state: state,
      dispatch: dispatch
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    },
    __self: this
  }, children);
};

/***/ }),

/***/ "./data/Hosting/data.js":
/*!******************************!*\
  !*** ./data/Hosting/data.js ***!
  \******************************/
/*! exports provided: FEATURES_DATA, FAQ_DATA, SERVICES_DATA, MENU_ITEMS, FOOTER_WIDGET, MONTHLY_PRICING_TABLE, YEARLY_PRICING_TABLE, TESTIMONIALS, DOMAIN_NAMES, DOMAIN_PRICE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FEATURES_DATA", function() { return FEATURES_DATA; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FAQ_DATA", function() { return FAQ_DATA; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SERVICES_DATA", function() { return SERVICES_DATA; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MENU_ITEMS", function() { return MENU_ITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FOOTER_WIDGET", function() { return FOOTER_WIDGET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MONTHLY_PRICING_TABLE", function() { return MONTHLY_PRICING_TABLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YEARLY_PRICING_TABLE", function() { return YEARLY_PRICING_TABLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TESTIMONIALS", function() { return TESTIMONIALS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOMAIN_NAMES", function() { return DOMAIN_NAMES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOMAIN_PRICE", function() { return DOMAIN_PRICE; });
/* harmony import */ var _images__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./images */ "./data/Hosting/images.js");
 // Feature Section Content

var FEATURES_DATA = [{
  title: 'Domain Registration & Web Hosting',
  description: 'We have support team for 24/7 operation. They provide help and ongoing assistance at any time.',
  icon: 'flaticon-trophy violate',
  animation: true
}, {
  title: 'Website Design & Development',
  description: 'Transferring from another host? Our expert support team is standing by to transfer your site.',
  icon: 'flaticon-startup yellow',
  animation: true
}, {
  title: 'Dedicated Server & Cloud Hosting',
  description: 'LiteSpeed Web Server is a high-performance HTTP server and known for its high performance.',
  icon: 'flaticon-creative green',
  animation: true
}]; // FAQ Section Content

var FAQ_DATA = [{
  id: 1,
  expend: true,
  title: 'How to contact with Customer Service?',
  description: 'Our Customer Experience Team is available 7 days a week and we offer 2 ways to get in contact.Email and Chat . We try to reply quickly, so you need not to wait too long for a response!. '
}, {
  id: 2,
  title: 'App installation failed, how to update system information?',
  description: 'Please read the documentation carefully . We also have some online  video tutorials regarding this issue . If the problem remains, Please Open a ticket in the support forum . '
}, {
  id: 3,
  title: 'Website reponse taking time, how to improve?',
  description: 'At first, Please check your internet connection . We also have some online  video tutorials regarding this issue . If the problem remains, Please Open a ticket in the support forum .'
}, {
  id: 4,
  title: 'New update fixed all bug and issues?',
  description: 'We are giving the update of this theme continuously . You will receive an email Notification when we push an update. Always try to be updated with us .'
}]; // Service Section Content

var SERVICES_DATA = [{
  title: 'Development Server ',
  description: 'Get Lightspeed Development Server for your website and fly in the web',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconOne"])
}, {
  title: 'Web Protection',
  description: 'Best Protection and some tools are provided with our Web servers .',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconTwo"])
}, {
  title: 'E-commerce Shop',
  description: 'You can build any kind of E-commerce Shop with payment security tools',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconThree"])
}, {
  title: 'Money Back Guarantee',
  description: 'We have provided 30 days money back guarantee for our customer',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconFour"])
}, {
  title: 'Client Satisfaction',
  description: 'Client Satisfaction is our first priority and We are best at it',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconFive"])
}, {
  title: '24/7 Online Support',
  description: 'A Dedicated support team is always ready to provide best support ',
  icon: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["IconSix"])
}];
var MENU_ITEMS = [{
  label: 'Home',
  path: '#banner_section',
  offset: '70'
}, {
  label: 'Feature',
  path: '#feature_section',
  offset: '70'
}, {
  label: 'Service',
  path: '#service_section',
  offset: '70'
}, {
  label: 'Testimonial',
  path: '#testimonial_section',
  offset: '70'
}, {
  label: 'FAQ',
  path: '#faq_section',
  offset: '70'
}, {
  label: 'Contact',
  path: '#contact_section',
  offset: '70'
}];
var FOOTER_WIDGET = [{
  title: 'About Us',
  menuItems: [{
    url: '#',
    text: 'Support Center'
  }, {
    url: '#',
    text: 'Customer Support'
  }, {
    url: '#',
    text: 'About Us'
  }, {
    url: '#',
    text: 'Copyright'
  }, {
    url: '#',
    text: 'Popular Campaign'
  }]
}, {
  title: 'Our Information',
  menuItems: [{
    url: '#',
    text: 'Return Policy'
  }, {
    url: '#',
    text: 'Privacy Policy'
  }, {
    url: '#',
    text: 'Terms & Conditions'
  }, {
    url: '#',
    text: 'Site Map'
  }, {
    url: '#',
    text: 'Store Hours'
  }]
}, {
  title: 'My Account',
  menuItems: [{
    url: '#',
    text: 'Press inquiries'
  }, {
    url: '#',
    text: 'Social media directories'
  }, {
    url: '#',
    text: 'Images & B-roll'
  }, {
    url: '#',
    text: 'Permissions'
  }, {
    url: '#',
    text: 'Speaker requests'
  }]
}, {
  title: 'Policy',
  menuItems: [{
    url: '#',
    text: 'Application security'
  }, {
    url: '#',
    text: 'Software principles'
  }, {
    url: '#',
    text: 'Unwanted software policy'
  }, {
    url: '#',
    text: 'Responsible supply chain'
  }]
}];
var MONTHLY_PRICING_TABLE = [{
  freePlan: true,
  name: 'Basic Account',
  description: 'For Small teams or group who need to build website ',
  price: '$0',
  priceLabel: 'Only for first month',
  buttonLabel: 'CREATE FREE ACCOUNT',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '1,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: 'eCommerce Store '
  }, {
    content: '30+ Webmaster Tools'
  }]
}, {
  name: 'Business Account',
  description: 'For Mediums teams or group who need to build website ',
  price: '$9.87',
  priceLabel: 'Per month & subscription yearly',
  buttonLabel: 'START FREE TRIAL',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '1,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: 'eCommerce Store '
  }, {
    content: '30+ Webmaster Tools'
  }]
}, {
  name: 'Premium Account',
  description: 'For Large teams or group who need to build website ',
  price: '$12.98',
  priceLabel: 'Per month & subscription yearly',
  buttonLabel: 'START FREE TRIAL',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '1,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: 'eCommerce Store '
  }, {
    content: '30+ Webmaster Tools'
  }]
}];
var YEARLY_PRICING_TABLE = [{
  freePlan: true,
  name: 'Basic Account',
  description: 'For a single client or team who need to build website ',
  price: '$0',
  priceLabel: 'Only for first month',
  buttonLabel: 'CREATE FREE ACCOUNT',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '1,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: 'eCommerce Store '
  }, {
    content: '30+ Webmaster Tools'
  }]
}, {
  name: 'Business Account',
  description: 'For Small teams or group who need to build website ',
  price: '$6.00',
  priceLabel: 'Per month & subscription yearly',
  buttonLabel: 'START FREE TRIAL',
  url: '#',
  listItems: [{
    content: 'Unlimited secure storage'
  }, {
    content: '2,000s of Templates Ready'
  }, {
    content: 'Blog Tools'
  }, {
    content: '24/7 phone support'
  }, {
    content: '50+ Webmaster Tools'
  }]
}, {
  name: 'Premium Account',
  description: 'For Large teams or group who need to build website ',
  price: '$9.99',
  priceLabel: 'Per month & subscription yearly',
  buttonLabel: 'START FREE TRIAL',
  url: '#',
  listItems: [{
    content: 'Drag & Drop Builder'
  }, {
    content: '3,000s of Templates Ready'
  }, {
    content: 'Advanced branding'
  }, {
    content: 'Knowledge base support'
  }, {
    content: '80+ Webmaster Tools'
  }]
}];
var TESTIMONIALS = [{
  review: 'Best working experience  with this amazing team & in future, we want to work together',
  name: 'Denny Hilguston',
  designation: 'CEO of Dell Co.',
  avatar: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["AuthorOne"])
}, {
  review: 'Impressed with master class support of the team and really look forward for the future.',
  name: 'Justin Albuz',
  designation: 'Co Founder of IBM',
  avatar: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["AuthorTwo"])
}, {
  review: 'I have bought more than 10 themes on ThemeForest, and this is the first one I review.',
  name: 'Milly Cristiana',
  designation: 'Manager of Hp co.',
  avatar: "".concat(_images__WEBPACK_IMPORTED_MODULE_0__["AuthorThree"])
}];
var DOMAIN_NAMES = [{
  label: '.com',
  value: 'com'
}, {
  label: '.net',
  value: 'net'
}, {
  label: '.org',
  value: 'org'
}, {
  label: '.co',
  value: 'co'
}, {
  label: '.edu',
  value: 'edu'
}, {
  label: '.me',
  value: 'me'
}];
var DOMAIN_PRICE = [{
  content: '.com $9.26'
}, {
  content: '.sg $7.91'
}, {
  content: '.space $12.54'
}, {
  content: '.info $9.13'
}, {
  content: '& much more',
  url: '#'
}];

/***/ }),

/***/ "./data/Hosting/images.js":
/*!********************************!*\
  !*** ./data/Hosting/images.js ***!
  \********************************/
/*! exports provided: IconOne, IconTwo, IconThree, IconFour, IconFive, IconSix, AuthorOne, AuthorTwo, AuthorThree */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _assets_image_hosting_icon1_svg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../assets/image/hosting/icon1.svg */ "./assets/image/hosting/icon1.svg");
/* harmony import */ var _assets_image_hosting_icon1_svg__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon1_svg__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconOne", function() { return _assets_image_hosting_icon1_svg__WEBPACK_IMPORTED_MODULE_0___default.a; });
/* harmony import */ var _assets_image_hosting_icon2_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../assets/image/hosting/icon2.svg */ "./assets/image/hosting/icon2.svg");
/* harmony import */ var _assets_image_hosting_icon2_svg__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon2_svg__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconTwo", function() { return _assets_image_hosting_icon2_svg__WEBPACK_IMPORTED_MODULE_1___default.a; });
/* harmony import */ var _assets_image_hosting_icon3_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../assets/image/hosting/icon3.svg */ "./assets/image/hosting/icon3.svg");
/* harmony import */ var _assets_image_hosting_icon3_svg__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon3_svg__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconThree", function() { return _assets_image_hosting_icon3_svg__WEBPACK_IMPORTED_MODULE_2___default.a; });
/* harmony import */ var _assets_image_hosting_icon4_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/image/hosting/icon4.svg */ "./assets/image/hosting/icon4.svg");
/* harmony import */ var _assets_image_hosting_icon4_svg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon4_svg__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconFour", function() { return _assets_image_hosting_icon4_svg__WEBPACK_IMPORTED_MODULE_3___default.a; });
/* harmony import */ var _assets_image_hosting_icon5_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../assets/image/hosting/icon5.svg */ "./assets/image/hosting/icon5.svg");
/* harmony import */ var _assets_image_hosting_icon5_svg__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon5_svg__WEBPACK_IMPORTED_MODULE_4__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconFive", function() { return _assets_image_hosting_icon5_svg__WEBPACK_IMPORTED_MODULE_4___default.a; });
/* harmony import */ var _assets_image_hosting_icon6_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../assets/image/hosting/icon6.svg */ "./assets/image/hosting/icon6.svg");
/* harmony import */ var _assets_image_hosting_icon6_svg__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_icon6_svg__WEBPACK_IMPORTED_MODULE_5__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "IconSix", function() { return _assets_image_hosting_icon6_svg__WEBPACK_IMPORTED_MODULE_5___default.a; });
/* harmony import */ var _assets_image_hosting_author_1_jpg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../assets/image/hosting/author-1.jpg */ "./assets/image/hosting/author-1.jpg");
/* harmony import */ var _assets_image_hosting_author_1_jpg__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_author_1_jpg__WEBPACK_IMPORTED_MODULE_6__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "AuthorOne", function() { return _assets_image_hosting_author_1_jpg__WEBPACK_IMPORTED_MODULE_6___default.a; });
/* harmony import */ var _assets_image_hosting_author_2_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../assets/image/hosting/author-2.jpg */ "./assets/image/hosting/author-2.jpg");
/* harmony import */ var _assets_image_hosting_author_2_jpg__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_author_2_jpg__WEBPACK_IMPORTED_MODULE_7__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "AuthorTwo", function() { return _assets_image_hosting_author_2_jpg__WEBPACK_IMPORTED_MODULE_7___default.a; });
/* harmony import */ var _assets_image_hosting_author_3_jpg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../assets/image/hosting/author-3.jpg */ "./assets/image/hosting/author-3.jpg");
/* harmony import */ var _assets_image_hosting_author_3_jpg__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_assets_image_hosting_author_3_jpg__WEBPACK_IMPORTED_MODULE_8__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "AuthorThree", function() { return _assets_image_hosting_author_3_jpg__WEBPACK_IMPORTED_MODULE_8___default.a; });
// Service Icons





 //Testimonial reviewers image






/***/ }),

/***/ "./data/Saas/index.js":
/*!****************************!*\
  !*** ./data/Saas/index.js ***!
  \****************************/
/*! exports provided: Faq, Features, Footer_Data, Service, Timeline, Testimonial, MENU_ITEMS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Faq", function() { return Faq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Features", function() { return Features; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Footer_Data", function() { return Footer_Data; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Service", function() { return Service; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Timeline", function() { return Timeline; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Testimonial", function() { return Testimonial; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MENU_ITEMS", function() { return MENU_ITEMS; });
/* harmony import */ var _assets_image_saas_testimonial_client_1_jpg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../assets/image/saas/testimonial/client-1.jpg */ "./assets/image/saas/testimonial/client-1.jpg");
/* harmony import */ var _assets_image_saas_testimonial_client_1_jpg__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_assets_image_saas_testimonial_client_1_jpg__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_image_agency_client_denny_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../assets/image/agency/client/denny.png */ "./assets/image/agency/client/denny.png");
/* harmony import */ var _assets_image_agency_client_denny_png__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_image_agency_client_denny_png__WEBPACK_IMPORTED_MODULE_1__);


var Faq = [{
  id: 1,
  expend: true,
  title: 'How to contact with Customer Service?',
  description: 'Our Customer Experience Team is available 7 days a week and we offer 2 ways to get in contact.Email and Chat . We try to reply quickly, so you need not to wait too long for a response!. '
}, {
  id: 2,
  title: 'App installation failed, how to update system information?',
  description: 'Please read the documentation carefully . We also have some online  video tutorials regarding this issue . If the problem remains, Please Open a ticket in the support forum . '
}, {
  id: 3,
  title: 'Website reponse taking time, how to improve?',
  description: 'At first, Please check your internet connection . We also have some online  video tutorials regarding this issue . If the problem remains, Please Open a ticket in the support forum .'
}, {
  id: 4,
  title: 'New update fixed all bug and issues?',
  description: 'We are giving the update of this theme continuously . You will receive an email Notification when we push an update. Always try to be updated with us .'
}, {
  id: 4,
  title: 'New update fixed all bug and issues?',
  description: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English."
}];
var Features = [{
  id: 1,
  icon: 'flaticon-creative',
  title: 'Powerful Features',
  description: 'Automate time consuming tasks like organising expenses ,tracking your time and following up with clients '
}, {
  id: 2,
  icon: 'flaticon-project',
  title: 'Easy Invoicing',
  description: 'Want to surprice your clients with professional looking invoices ? Then you are some clicks behind .'
}, {
  id: 3,
  icon: 'flaticon-flask',
  title: 'Easy To Use',
  description: 'Very Simple and intuitive. So you have to spend less time in paperwork and impress your customer with looks'
}];
var Footer_Data = [{
  title: 'About Us',
  menuItems: [{
    url: '#',
    text: 'Support Center'
  }, {
    url: '#',
    text: 'Customer Support'
  }, {
    url: '#',
    text: 'About Us'
  }, {
    url: '#',
    text: 'Copyright'
  }, {
    url: '#',
    text: 'Popular Campaign'
  }]
}, {
  title: 'Our Information',
  menuItems: [{
    url: '#',
    text: 'Return Policy'
  }, {
    url: '#',
    text: 'Privacy Policy'
  }, {
    url: '#',
    text: 'Terms & Conditions'
  }, {
    url: '#',
    text: 'Site Map'
  }, {
    url: '#',
    text: 'Store Hours'
  }]
}, {
  title: 'My Account',
  menuItems: [{
    url: '#',
    text: 'Press inquiries'
  }, {
    url: '#',
    text: 'Social media directories'
  }, {
    url: '#',
    text: 'Images & B-roll'
  }, {
    url: '#',
    text: 'Permissions'
  }, {
    url: '#',
    text: 'Speaker requests'
  }]
}, {
  title: 'Policy',
  menuItems: [{
    url: '#',
    text: 'Application security'
  }, {
    url: '#',
    text: 'Software principles'
  }, {
    url: '#',
    text: 'Unwanted software policy'
  }, {
    url: '#',
    text: 'Responsible supply chain'
  }]
}];
var Service = [{
  id: 1,
  icon: 'flaticon-project',
  title: 'App Development',
  description: 'We are specialized at custom Saas Application Development and special features .'
}, {
  id: 2,
  icon: 'flaticon-trophy',
  title: '10 Times Award',
  description: 'We are globally recognised for our services and won a lot of prices around the world .'
}, {
  id: 3,
  icon: 'flaticon-atom',
  title: 'Cloud Stroage',
  description: 'LiteSpeed Web Server known for its high performance and low resource consumption.'
}, {
  id: 4,
  icon: 'flaticon-design-tool',
  title: 'Client Satisfaction',
  description: 'Client Satisfaction is our first priority and We are best at it .Keep In Touch.'
}, {
  id: 5,
  icon: 'flaticon-creative',
  title: 'UX Planning',
  description: 'We provide the best UI/UX Design by following the latest trends of the market  .'
}, {
  id: 6,
  icon: 'flaticon-conversation',
  title: 'Customer Support',
  description: 'A Dedicated support team is always ready to provide best support to our customers.'
}];
var Timeline = [{
  title: 'Wireframing for project',
  description: 'We respect our customer opinions and deals with them with perfect wireframing.'
}, {
  title: 'UI/UX for project',
  description: 'We provide the best UI/UX Design by following the latest trends of the market .'
}, {
  title: 'Negotiation about project',
  description: 'After the negotiation is done , We start to build the project with latest technology .'
}];
var Testimonial = [{
  id: 1,
  name: 'Michal Andry',
  designation: 'Ceo of Invission Co.',
  comment: 'Love to work with this designer in every our future project to ensure we are going to build best prototyping features.',
  avatar_url: _assets_image_saas_testimonial_client_1_jpg__WEBPACK_IMPORTED_MODULE_0___default.a,
  social_icon: 'flaticon-instagram'
}, {
  id: 2,
  name: 'Roman Ul Oman',
  designation: 'Co-founder of QatarDiaries',
  comment: 'Impressed with master class support of the team and really look forward for the future. A true passionate team.',
  avatar_url: _assets_image_agency_client_denny_png__WEBPACK_IMPORTED_MODULE_1___default.a,
  social_icon: 'flaticon-twitter'
}];
var MENU_ITEMS = [{
  label: 'Home',
  path: '#banner_section',
  offset: '70'
}, {
  label: 'Service',
  path: '#service_section',
  offset: '70'
}, {
  label: 'Feature',
  path: '#feature_section',
  offset: '70'
}, {
  label: 'Pricing',
  path: '#pricing_section',
  offset: '70'
}, {
  label: 'Testimonial',
  path: '#testimonial_section',
  offset: '70'
}, {
  label: 'FAQ',
  path: '#faq_section',
  offset: '70'
}];

/***/ }),

/***/ "./pages/saas.js":
/*!***********************!*\
  !*** ./pages/saas.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_stickynode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-stickynode */ "react-stickynode");
/* harmony import */ var react_stickynode__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_stickynode__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _theme_saas__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../theme/saas */ "./theme/saas/index.js");
/* harmony import */ var _assets_css_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../assets/css/style */ "./assets/css/style.js");
/* harmony import */ var _containers_Saas_saas_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../containers/Saas/saas.style */ "./containers/Saas/saas.style.js");
/* harmony import */ var _containers_Saas_Navbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../containers/Saas/Navbar */ "./containers/Saas/Navbar/index.js");
/* harmony import */ var _containers_Saas_BannerSection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../containers/Saas/BannerSection */ "./containers/Saas/BannerSection/index.js");
/* harmony import */ var _containers_Saas_FeatureSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../containers/Saas/FeatureSection */ "./containers/Saas/FeatureSection/index.js");
/* harmony import */ var _containers_Saas_VisitorSection__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../containers/Saas/VisitorSection */ "./containers/Saas/VisitorSection/index.js");
/* harmony import */ var _containers_Saas_ServiceSection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../containers/Saas/ServiceSection */ "./containers/Saas/ServiceSection/index.js");
/* harmony import */ var _containers_Saas_FaqSection__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../containers/Saas/FaqSection */ "./containers/Saas/FaqSection/index.js");
/* harmony import */ var _containers_Saas_Footer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../containers/Saas/Footer */ "./containers/Saas/Footer/index.js");
/* harmony import */ var _containers_Saas_PricingSection__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../containers/Saas/PricingSection */ "./containers/Saas/PricingSection/index.js");
/* harmony import */ var _containers_Saas_TrialSection__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../containers/Saas/TrialSection */ "./containers/Saas/TrialSection/index.js");
/* harmony import */ var _containers_Saas_TimelineSection__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../containers/Saas/TimelineSection */ "./containers/Saas/TimelineSection/index.js");
/* harmony import */ var _containers_Saas_TestimonialSection__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../containers/Saas/TestimonialSection */ "./containers/Saas/TestimonialSection/index.js");
/* harmony import */ var _containers_Saas_PartnerSection__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../containers/Saas/PartnerSection */ "./containers/Saas/PartnerSection/index.js");
/* harmony import */ var _contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../contexts/DrawerContext */ "./contexts/DrawerContext.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\pages\\saas.js";




















console.log(_assets_css_style__WEBPACK_IMPORTED_MODULE_5__["ResetCSS"]);
/* harmony default export */ __webpack_exports__["default"] = (function () {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(styled_components__WEBPACK_IMPORTED_MODULE_3__["ThemeProvider"], {
    theme: _theme_saas__WEBPACK_IMPORTED_MODULE_4__["saasTheme"],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("title", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }, "Saas | A react next landing page"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "Description",
    content: "React next landing page",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "theme-color",
    content: "#ec5555",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "stylesheet",
    href: "/static/css/flaticon.css",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    href: "https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i",
    rel: "stylesheet",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_assets_css_style__WEBPACK_IMPORTED_MODULE_5__["ResetCSS"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_saas_style__WEBPACK_IMPORTED_MODULE_6__["GlobalStyle"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_saas_style__WEBPACK_IMPORTED_MODULE_6__["ContentWrapper"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_stickynode__WEBPACK_IMPORTED_MODULE_2___default.a, {
    top: 0,
    innerZ: 9999,
    activeClass: "sticky-nav-active",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_19__["DrawerProvider"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_Navbar__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_BannerSection__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_FeatureSection__WEBPACK_IMPORTED_MODULE_9__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_VisitorSection__WEBPACK_IMPORTED_MODULE_10__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_ServiceSection__WEBPACK_IMPORTED_MODULE_11__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_PricingSection__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_TestimonialSection__WEBPACK_IMPORTED_MODULE_17__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_PartnerSection__WEBPACK_IMPORTED_MODULE_18__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_TimelineSection__WEBPACK_IMPORTED_MODULE_16__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_FaqSection__WEBPACK_IMPORTED_MODULE_12__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_TrialSection__WEBPACK_IMPORTED_MODULE_15__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Saas_Footer__WEBPACK_IMPORTED_MODULE_13__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }))));
});

/***/ }),

/***/ "./theme/saas/colors.js":
/*!******************************!*\
  !*** ./theme/saas/colors.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var colors = {
  transparent: 'transparent',
  // 0
  black: '#000000',
  // 1
  white: '#ffffff',
  // 2
  headingColor: '#0f2137',
  textColor: '#5d646d',
  // 3
  labelColor: '#767676',
  // 4
  inactiveField: '#f2f2f2',
  // 5
  inactiveButton: '#b7dbdd',
  // 6
  inactiveIcon: '#EBEBEB',
  // 7
  primary: '#5268db',
  // 8
  primaryHover: '#5268db',
  // 9
  secondary: '#ff5b60',
  // 10
  secondaryHover: '#FF282F',
  // 11
  yellow: '#fdb32a',
  // 12
  yellowHover: '#F29E02',
  // 13
  primaryBoxShadow: ' 0px 9px 19.74px 1.26px rgba(82, 104, 219, 0.57) '
};
/* harmony default export */ __webpack_exports__["default"] = (colors);

/***/ }),

/***/ "./theme/saas/index.js":
/*!*****************************!*\
  !*** ./theme/saas/index.js ***!
  \*****************************/
/*! exports provided: saasTheme */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saasTheme", function() { return saasTheme; });
/* harmony import */ var _colors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./colors */ "./theme/saas/colors.js");

var saasTheme = {
  breakpoints: [575, 768, 990, 1440],
  space: [0, 5, 8, 10, 15, 20, 25, 30, 33, 35, 40, 50, 60, 70, 80, 85, 90, 100],
  fontSizes: [10, 12, 14, 15, 16, 18, 20, 22, 24, 36, 48, 80, 96],
  fontWeights: [100, 200, 300, 400, 500, 600, 700, 800, 900],
  lineHeights: {
    solid: 1,
    title: 1.25,
    copy: 1.5
  },
  letterSpacings: {
    normal: 'normal',
    tracked: '0.1em',
    tight: '-0.05em',
    mega: '0.25em'
  },
  borders: [0, '1px solid', '2px solid', '3px solid', '4px solid', '5px solid', '6px solid'],
  radius: [3, 4, 5, 10, 20, 30, 60, 120, '50%'],
  widths: [36, 40, 44, 48, 54, 70, 81, 128, 256],
  heights: [36, 40, 44, 46, 48, 54, 70, 81, 128],
  maxWidths: [16, 32, 64, 128, 256, 512, 768, 1024, 1536],
  colors: _colors__WEBPACK_IMPORTED_MODULE_0__["default"],
  colorStyles: {
    primary: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      border: '1px solid',
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].transparent,
      '&:hover': {
        color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primaryHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].transparent,
        boxShadow: '0px 9px 20px -5px rgba(82, 104, 219, 0.57)',
        backgroundImage: 'linear-gradient( 31deg, rgba(215,178,233, 0.4) 0%, rgba(83,105,220, 0.4) 100%)'
      }
    },
    secondary: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
      '&:hover': {
        color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover
      }
    },
    warning: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellow,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellow,
      '&:hover': {
        color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellowHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellowHover
      }
    },
    error: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
      '&:hover': {
        color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary
      }
    },
    primaryWithBg: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      backgroundImage: 'linear-gradient( 31deg, rgba(215,178,233, 0.4) 0%, rgba(83,105,220, 0.4) 100%)',
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primaryHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primaryHover,
        boxShadow: '0px 9px 20px -5px rgba(82, 104, 219, 0.57)'
      }
    },
    secondaryWithBg: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover
      }
    },
    warningWithBg: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellow,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellow,
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellowHover,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].yellowHover
      }
    },
    errorWithBg: {
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
      borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondaryHover,
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary,
        borderColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].secondary
      }
    },
    transparentBg: {
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white,
      '&:hover': {
        backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].white
      }
    }
  },
  buttonStyles: {
    textButton: {
      border: 0,
      color: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].primary,
      padding: 0,
      height: 'auto',
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].transparent
    },
    outlined: {
      borderWidth: '1px',
      borderStyle: 'solid',
      backgroundColor: _colors__WEBPACK_IMPORTED_MODULE_0__["default"].transparent
    },
    fab: {
      border: '0',
      width: '40px',
      height: '40px',
      padding: 0,
      borderRadius: '50%',
      justifyContent: 'center',
      'span.btn-icon': {
        paddingLeft: 0
      }
    },
    extendedFab: {
      border: '0',
      minWidth: '50px',
      height: '40px',
      borderRadius: '50px',
      justifyContent: 'center'
    }
  } // FlexBox: {
  //   backgroundColor: 'green'
  // }

};

/***/ }),

/***/ 6:
/*!*****************************!*\
  !*** multi ./pages/saas.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./pages/saas.js */"./pages/saas.js");


/***/ }),

/***/ "@glidejs/glide":
/*!*********************************!*\
  !*** external "@glidejs/glide" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@glidejs/glide");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/link":
/*!****************************!*\
  !*** external "next/link" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/link");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "rc-drawer":
/*!****************************!*\
  !*** external "rc-drawer" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rc-drawer");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-accessible-accordion":
/*!*********************************************!*\
  !*** external "react-accessible-accordion" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-accessible-accordion");

/***/ }),

/***/ "react-anchor-link-smooth-scroll":
/*!**************************************************!*\
  !*** external "react-anchor-link-smooth-scroll" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-anchor-link-smooth-scroll");

/***/ }),

/***/ "react-icons-kit":
/*!**********************************!*\
  !*** external "react-icons-kit" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit");

/***/ }),

/***/ "react-icons-kit/entypo/minus":
/*!***********************************************!*\
  !*** external "react-icons-kit/entypo/minus" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/entypo/minus");

/***/ }),

/***/ "react-icons-kit/entypo/plus":
/*!**********************************************!*\
  !*** external "react-icons-kit/entypo/plus" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/entypo/plus");

/***/ }),

/***/ "react-icons-kit/icomoon/checkmark":
/*!****************************************************!*\
  !*** external "react-icons-kit/icomoon/checkmark" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons-kit/icomoon/checkmark");

/***/ }),

/***/ "react-particles-js":
/*!*************************************!*\
  !*** external "react-particles-js" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-particles-js");

/***/ }),

/***/ "react-reveal/Fade":
/*!************************************!*\
  !*** external "react-reveal/Fade" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-reveal/Fade");

/***/ }),

/***/ "react-reveal/Slide":
/*!*************************************!*\
  !*** external "react-reveal/Slide" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-reveal/Slide");

/***/ }),

/***/ "react-reveal/Zoom":
/*!************************************!*\
  !*** external "react-reveal/Zoom" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-reveal/Zoom");

/***/ }),

/***/ "react-scrollspy":
/*!**********************************!*\
  !*** external "react-scrollspy" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-scrollspy");

/***/ }),

/***/ "react-stickynode":
/*!***********************************!*\
  !*** external "react-stickynode" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-stickynode");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),

/***/ "styled-system":
/*!********************************!*\
  !*** external "styled-system" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-system");

/***/ })

/******/ });
//# sourceMappingURL=saas.js.map