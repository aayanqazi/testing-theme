webpackHotUpdate("static\\development\\pages\\agency.js",{

/***/ "./pages/agency.js":
/*!*************************!*\
  !*** ./pages/agency.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "../../node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_stickynode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-stickynode */ "../../node_modules/react-stickynode/index.js");
/* harmony import */ var react_stickynode__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_stickynode__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "../../node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _theme_agency__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../theme/agency */ "./theme/agency/index.js");
/* harmony import */ var _assets_css_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../assets/css/style */ "./assets/css/style.js");
/* harmony import */ var _landing_containers_Agency_agency_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../landing/containers/Agency/agency.style */ "./containers/Agency/agency.style.js");
/* harmony import */ var _containers_Agency_Navbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../containers/Agency/Navbar */ "./containers/Agency/Navbar/index.js");
/* harmony import */ var _containers_Agency_BannerSection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../containers/Agency/BannerSection */ "./containers/Agency/BannerSection/index.js");
/* harmony import */ var _containers_Agency_FeatureSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../containers/Agency/FeatureSection */ "./containers/Agency/FeatureSection/index.js");
/* harmony import */ var _containers_Agency_AboutUsSection__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../containers/Agency/AboutUsSection */ "./containers/Agency/AboutUsSection/index.js");
/* harmony import */ var _containers_Agency_WorkHistory__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../containers/Agency/WorkHistory */ "./containers/Agency/WorkHistory/index.js");
/* harmony import */ var _containers_Agency_BlogSection__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../containers/Agency/BlogSection */ "./containers/Agency/BlogSection/index.js");
/* harmony import */ var _containers_Agency_TestimonialSection__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../containers/Agency/TestimonialSection */ "./containers/Agency/TestimonialSection/index.js");
/* harmony import */ var _containers_Agency_TeamSection__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../containers/Agency/TeamSection */ "./containers/Agency/TeamSection/index.js");
/* harmony import */ var _containers_Agency_VideoSection__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../containers/Agency/VideoSection */ "./containers/Agency/VideoSection/index.js");
/* harmony import */ var _containers_Agency_FaqSection__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../containers/Agency/FaqSection */ "./containers/Agency/FaqSection/index.js");
/* harmony import */ var _containers_Agency_NewsletterSection__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../containers/Agency/NewsletterSection */ "./containers/Agency/NewsletterSection/index.js");
/* harmony import */ var _containers_Agency_QualitySection__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../containers/Agency/QualitySection */ "./containers/Agency/QualitySection/index.js");
/* harmony import */ var _containers_Agency_Footer__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../containers/Agency/Footer */ "./containers/Agency/Footer/index.js");
/* harmony import */ var _contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../contexts/DrawerContext */ "./contexts/DrawerContext.js");
var _jsxFileName = "D:\\RedQ Projects\\Next Landing\\react-next-landing\\packages\\landing\\pages\\agency.js";





















/* harmony default export */ __webpack_exports__["default"] = (function () {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(styled_components__WEBPACK_IMPORTED_MODULE_3__["ThemeProvider"], {
    theme: _theme_agency__WEBPACK_IMPORTED_MODULE_4__["agencyTheme"],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("title", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    },
    __self: this
  }, "Agency | A react next landing page"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "Description",
    content: "React next landing page",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "theme-color",
    content: "#10ac84",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "stylesheet",
    href: "/static/css/flaticon.css",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    href: "https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i",
    rel: "stylesheet",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_assets_css_style__WEBPACK_IMPORTED_MODULE_5__["ResetCSS"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_landing_containers_Agency_agency_style__WEBPACK_IMPORTED_MODULE_6__["GlobalStyle"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_landing_containers_Agency_agency_style__WEBPACK_IMPORTED_MODULE_6__["AgencyWrapper"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_stickynode__WEBPACK_IMPORTED_MODULE_2___default.a, {
    top: 0,
    innerZ: 9999,
    activeClass: "sticky-nav-active",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_contexts_DrawerContext__WEBPACK_IMPORTED_MODULE_20__["DrawerProvider"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_Navbar__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_BannerSection__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_FeatureSection__WEBPACK_IMPORTED_MODULE_9__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_AboutUsSection__WEBPACK_IMPORTED_MODULE_10__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_WorkHistory__WEBPACK_IMPORTED_MODULE_11__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_BlogSection__WEBPACK_IMPORTED_MODULE_12__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_QualitySection__WEBPACK_IMPORTED_MODULE_18__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_VideoSection__WEBPACK_IMPORTED_MODULE_15__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_TestimonialSection__WEBPACK_IMPORTED_MODULE_13__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_TeamSection__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_FaqSection__WEBPACK_IMPORTED_MODULE_16__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_NewsletterSection__WEBPACK_IMPORTED_MODULE_17__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Agency_Footer__WEBPACK_IMPORTED_MODULE_19__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    },
    __self: this
  }))));
});
    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/agency")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/node_modules/webpack/buildin/harmony-module.js */ "../../node_modules/next/node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=agency.js.d703240a2ff5ceed932d.hot-update.js.map